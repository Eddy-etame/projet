<?php
namespace OAC\Services;

class LoggerService {
    private $log_dir;
    
    public function __construct($base_dir = null) {
        $this->log_dir = $base_dir ?? dirname(__DIR__, 2) . '/logs';
        if (!file_exists($this->log_dir)) {
            mkdir($this->log_dir, 0755, true);
        }
    }
    
    public function error($message, $data = []) {
        $this->log($message, $data, 'ERROR');
    }
    
    public function info($message, $data = []) {
        $this->log($message, $data, 'INFO');
    }
    
    public function warning($message, $data = []) {
        $this->log($message, $data, 'WARNING');
    }
    
    public function critical($message, $data = []) {
        $this->log($message, $data, 'CRITICAL');
        error_log("CRITICAL ERROR: $message");
    }
    
    private function log($message, $data = [], $level = 'ERROR') {
        $log_entry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'level' => $level,
            'message' => $message,
            'data' => $data,
            'user_id' => $_SESSION['user_id'] ?? 'not_logged_in',
            'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
            'url' => $_SERVER['REQUEST_URI'] ?? 'unknown'
        ];

        $log_file = $this->log_dir . '/' . date('Y-m-d') . '_' . strtolower($level) . '.log';
        $formatted_entry = json_encode($log_entry, JSON_PRETTY_PRINT) . "\n---\n";
        file_put_contents($log_file, $formatted_entry, FILE_APPEND);
    }
} 