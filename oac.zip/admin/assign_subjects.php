<?php
require_once '../auth/middleware.php';
$auth = new AuthMiddleware();
$auth->requireRole(1); // Only admin
require_once '../auth/db.php';

// Get teacher ID
$teacher_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
if (!$teacher_id) {
    header('Location: view_teachers.php');
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['subjects'])) {
    $subjects = $_POST['subjects'];
    // Remove all current assignments
    $conn->query("DELETE FROM Enseignant_Matiere WHERE id_enseignant = $teacher_id");
    // Assign new subjects
    $stmt = $conn->prepare("INSERT INTO Enseignant_Matiere (id_enseignant, id_matiere) VALUES (?, ?)");
    foreach ($subjects as $subject_id) {
        $stmt->bind_param('ii', $teacher_id, $subject_id);
        $stmt->execute();
    }
    $stmt->close();
    $success = 'Subjects assigned successfully!';
}

// Get teacher info
$teacher = $conn->query("SELECT nom, prenom FROM Enseignants WHERE id_utilisateur = $teacher_id")->fetch_assoc();
// Get all subjects
$subjects = $conn->query("SELECT id_matiere, nom_matiere FROM Matieres")->fetch_all(MYSQLI_ASSOC);
// Get assigned subjects
$assigned = $conn->query("SELECT id_matiere FROM Enseignant_Matiere WHERE id_enseignant = $teacher_id")->fetch_all(MYSQLI_ASSOC);
$assigned_ids = array_column($assigned, 'id_matiere');
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Assign Subjects to Teacher</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>
<body>
<div class="admin-dashboard">
    <h2>Assign Subjects to <?= htmlspecialchars($teacher['prenom'] . ' ' . $teacher['nom']) ?></h2>
    <?php if (!empty($success)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="post">
        <label for="subjects">Select Subjects:</label><br>
        <select name="subjects[]" id="subjects" multiple size="6" style="width:300px;">
            <?php foreach ($subjects as $subject): ?>
                <option value="<?= $subject['id_matiere'] ?>" <?= in_array($subject['id_matiere'], $assigned_ids) ? 'selected' : '' ?>>
                    <?= htmlspecialchars($subject['nom_matiere']) ?>
                </option>
            <?php endforeach; ?>
        </select><br><br>
        <button type="submit" class="btn btn-primary">Assign Subjects</button>
        <a href="view_teachers.php" class="btn btn-link">Back</a>
    </form>
</div>
</body>
</html>
