<?php
require_once '../auth/middleware.php';
$auth = new AuthMiddleware();
$auth->requireRole('admin');

// Handle form submission
$password_generated = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../auth/db.php';
    // Input validation: check for duplicate email
    $email = $_POST['email'];
    $check = $conn->prepare("SELECT id_utilisateur FROM Utilisateurs WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
        $error = "Cet email existe déjà. Veuillez en choisir un autre.";
        $check->close();
    } else {
        $check->close();
        $prenom = $_POST['prenom'];
        $nom = $_POST['nom'];
        $nom_utilisateur = $_POST['nom_utilisateur'];
        $password = bin2hex(random_bytes(4));
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $id_role = 2; // Teacher
        // Set must_change_password to 1
        $stmt = $conn->prepare("INSERT INTO Utilisateurs (id_role, email, mot_de_passe, nom, prenom, nom_utilisateur, must_change_password) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->bind_param("isssss", $id_role, $email, $hashed_password, $nom, $prenom, $nom_utilisateur);
        if ($stmt->execute()) {
            $id_utilisateur = $stmt->insert_id;
            $stmt2 = $conn->prepare("INSERT INTO Enseignants (id_utilisateur, nom, prenom, email, nom_utilisateur) VALUES (?, ?, ?, ?, ?)");
            $stmt2->bind_param("issss", $id_utilisateur, $nom, $prenom, $email, $nom_utilisateur);
            $stmt2->execute();
            $stmt2->close();
            $password_generated = $password;
        }
        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un Enseignant</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>
<body>
<div class="admin-dashboard">
    <h2>Ajouter un Enseignant</h2>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($password_generated): ?>
        <div class="alert alert-success">Compte créé ! Mot de passe initial : <b><?= htmlspecialchars($password_generated) ?></b></div>
    <?php endif; ?>
    <form method="post">
        <input type="text" name="nom_utilisateur" placeholder="Nom d'utilisateur" required><br>
        <input type="text" name="prenom" placeholder="Prénom" required><br>
        <input type="text" name="nom" placeholder="Nom" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <!-- Password is always randomly generated and shown after creation. -->
        <button type="submit">Créer le compte enseignant</button>
    </form>
    <a href="ADDashboard.php">Retour au tableau de bord</a>
</div>
</body>
</html>
