<?php
session_start();
require_once '../auth/auth.php';
require_once '../auth/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $role_id = 1; // Admin role

    if (empty($email) || empty($password)) {
        $error = 'Veuillez remplir tous les champs.';
    } else {
        $auth = new Auth(getDBConnection());
        if ($auth->login($email, $password, $role_id)) {
            header('Location: ADDashboard.php');
            exit();
        } else {
            $error = 'Identifiants invalides.';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>
<body>
    <div class="admin-login-container">
        <div class="admin-login-form">
            <h2>Administration Login</h2>
            <?php if ($error): ?>
                <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>
            <form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>">
                <div class="form-group">
                    <label for="email">Email:</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <div class="form-group">
                    <label for="password">Password:</label>
                    <input type="password" id="password" name="password" required>
                </div>
                <button type="submit" class="btn btn-primary">Login</button>
            </form>
            <div class="back-link">
                <a href="../index.php">Back to Home</a>
            </div>
        </div>
    </div>
</body>
</html>