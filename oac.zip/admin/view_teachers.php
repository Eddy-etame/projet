<?php
require_once '../auth/middleware.php';
$authMiddleware = new AuthMiddleware();
$authMiddleware->requireRole(1); // Only admin
require_once '../auth/Login.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Pagination logic
$perPage = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;
$totalQuery = $conn->query("SELECT COUNT(*) FROM Utilisateurs WHERE id_role = 2");
$totalRows = $totalQuery->fetch_row()[0];
$totalPages = ceil($totalRows / $perPage);
$result = $conn->query("SELECT id_utilisateur, nom, prenom, email FROM Utilisateurs WHERE id_role = 2 LIMIT $perPage OFFSET $offset");
$teachers = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Teachers</title>
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <link rel="stylesheet" href="../css/admin-dashboard.css">
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #2a5298; color: #fff; }
        tr:hover { background: #f0f6ff; }
        .action-btn { color: #fff; background: #fc5c7d; border: none; padding: 6px 12px; border-radius: 5px; cursor: pointer; margin-right: 5px; }
        .action-btn.edit { background: #38ef7d; }
        .pagination { margin-top: 20px; }
        .pagination a, .pagination span { 
            display: inline-block; 
            padding: 8px 12px; 
            margin: 0 4px; 
            text-decoration: none; 
            border: 1px solid #2a5298; 
            color: #2a5298; 
            border-radius: 5px; 
        }
        .pagination .active { background: #2a5298; color: #fff; }
    </style>
</head>
<body>
    <div class="admin-dashboard">
        <h1>All Teachers</h1>
        <table>
            <tr><th>Name</th><th>Email</th><th>Actions</th></tr>
            <?php foreach ($teachers as $teacher): ?>
            <tr>
                <td><?= htmlspecialchars($teacher['prenom'] . ' ' . $teacher['nom']) ?></td>
                <td><?= htmlspecialchars($teacher['email']) ?></td>
                <td>
                    <a href="edit_teacher.php?id=<?= $teacher['id_utilisateur'] ?>" class="action-btn edit">Edit</a>
                    <a href="delete_teacher.php?id=<?= $teacher['id_utilisateur'] ?>" class="action-btn">Delete</a>
                    <a href="assign_subjects.php?id=<?= $teacher['id_utilisateur'] ?>" class="action-btn" style="background:#ffd481;color:#222;">Assign Subjects</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        
        <!-- Pagination controls -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        
        <a href="ADDashboard.php" class="btn-link">Back to Dashboard</a>
    </div>
    <script>
    // Confirm delete dialog for all delete buttons
    const deleteLinks = document.querySelectorAll('a[href*="delete_teacher.php"]');
    deleteLinks.forEach(link => {
      link.addEventListener('click', function(e) {
        if(!confirm('Are you sure you want to delete this teacher? This action cannot be undone.')) {
          e.preventDefault();
        }
      });
    });
    </script>
</body>
</html>
