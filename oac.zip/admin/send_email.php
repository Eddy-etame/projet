<?php
require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Check if user is logged in and is an admin
$authMiddleware = new AuthMiddleware();
$authMiddleware->requireRole(1);

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed']);
    exit;
}

try {
    $data = json_decode(file_get_contents('php://input'), true);
    
    if (!isset($data['recipients']) || !isset($data['subject']) || !isset($data['message'])) {
        throw new Exception('Missing required fields');
    }
    
    $recipients = $data['recipients'];
    $subject = $data['subject'];
    $message = $data['message'];
    
    // Get email configuration from environment or config file
    $smtp_host = getenv('SMTP_HOST') ?: 'smtp.example.com';
    $smtp_port = getenv('SMTP_PORT') ?: 587;
    $smtp_user = getenv('SMTP_USER') ?: 'user@example.com';
    $smtp_pass = getenv('SMTP_PASS') ?: 'password';
    $smtp_from = getenv('SMTP_FROM') ?: 'noreply@oac.edu';
    $smtp_from_name = getenv('SMTP_FROM_NAME') ?: 'OAC Administration';
    
    // Initialize PHPMailer
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host = $smtp_host;
    $mail->SMTPAuth = true;
    $mail->Username = $smtp_user;
    $mail->Password = $smtp_pass;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = $smtp_port;
    $mail->CharSet = 'UTF-8';
    
    $mail->setFrom($smtp_from, $smtp_from_name);
    
    // Get recipient emails from database based on roles/groups
    $conn = getDBConnection();
    $role_ids = [];
    if (in_array('admin', $recipients)) $role_ids[] = 1;
    if (in_array('teacher', $recipients)) $role_ids[] = 2;
    if (in_array('student', $recipients)) $role_ids[] = 3;
    
    $placeholders = str_repeat('?,', count($role_ids) - 1) . '?';
    $stmt = $conn->prepare("
        SELECT u.email, u.nom, u.prenom 
        FROM Utilisateurs u
        JOIN Roles r ON u.id_role = r.id_role
        WHERE u.id_role IN ($placeholders)
    ");
    
    $stmt->bind_param(str_repeat('i', count($role_ids)), ...$role_ids);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $sent_count = 0;
    while ($row = $result->fetch_assoc()) {
        $mail->addBCC($row['email']);
        $sent_count++;
    }
    
    $mail->Subject = $subject;
    $mail->Body = $message;
    $mail->AltBody = strip_tags($message);
    
    // Send email
    if ($sent_count > 0) {
        $mail->send();
        
        // Log email sending
        $stmt = $conn->prepare("
            INSERT INTO EmailLogs (
                date_envoi, 
                sujet, 
                message, 
                nombre_destinataires, 
                id_utilisateur_envoi
            ) VALUES (NOW(), ?, ?, ?, ?)
        ");
        $stmt->bind_param(
            'ssii',
            $subject,
            $message,
            $sent_count,
            $_SESSION['user_id']
        );
        $stmt->execute();
        
        echo json_encode([
            'success' => true,
            'message' => "Email sent successfully to $sent_count recipients"
        ]);
    } else {
        throw new Exception('No valid recipients found');
    }
    
} catch (Exception $e) {
    error_log("Email sending error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'error' => true,
        'message' => 'Failed to send email: ' . $e->getMessage()
    ]);
} 