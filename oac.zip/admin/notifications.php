<?php
require_once '../auth/middleware.php';
$authMiddleware = new AuthMiddleware();
$authMiddleware->requireRole(1); // Only admin
require_once '../auth/db.php';

// Handle notification send
$success = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $message = $_POST['message'];
    $role_target = $_POST['role_target']; // 'student', 'teacher', 'all'
    $subject_id = !empty($_POST['id_matiere']) ? intval($_POST['id_matiere']) : null;
    $recipient_id = !empty($_POST['recipient_id']) ? intval($_POST['recipient_id']) : null;
    $sender_id = $_SESSION['user_id'];
    $stmt = $conn->prepare("INSERT INTO Notifications (sender_id, recipient_id, id_matiere, role_target, title, message) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param('iiisss', $sender_id, $recipient_id, $subject_id, $role_target, $title, $message);
    $stmt->execute();
    $stmt->close();
    $success = 'Notification sent!';
}
// Get all subjects
$subjects = $conn->query("SELECT id_matiere, nom_matiere FROM Matieres")->fetch_all(MYSQLI_ASSOC);
// Get all teachers and students
$teachers = $conn->query("SELECT id_utilisateur, nom, prenom FROM Utilisateurs WHERE id_role = 2")->fetch_all(MYSQLI_ASSOC);
$students = $conn->query("SELECT id_utilisateur, nom, prenom FROM Utilisateurs WHERE id_role = 3")->fetch_all(MYSQLI_ASSOC);
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Send Notification</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>
<body>
<div class="admin-dashboard">
    <h2>Send Notification</h2>
    <?php if ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
    <?php endif; ?>
    <form method="post">
        <label>Title:</label><br>
        <input type="text" name="title" required><br>
        <label>Message:</label><br>
        <textarea name="message" rows="4" required></textarea><br>
        <label>Target:</label><br>
        <select name="role_target" id="role_target" onchange="toggleTargetFields()" required>
            <option value="all">All</option>
            <option value="student">Student</option>
            <option value="teacher">Teacher</option>
        </select><br>
        <div id="student_select" style="display:none;">
            <label>Student:</label>
            <select name="recipient_id">
                <option value="">All Students</option>
                <?php foreach ($students as $s): ?>
                    <option value="<?= $s['id_utilisateur'] ?>"><?= htmlspecialchars($s['prenom'] . ' ' . $s['nom']) ?></option>
                <?php endforeach; ?>
            </select><br>
        </div>
        <div id="teacher_select" style="display:none;">
            <label>Teacher:</label>
            <select name="recipient_id">
                <option value="">All Teachers</option>
                <?php foreach ($teachers as $t): ?>
                    <option value="<?= $t['id_utilisateur'] ?>"><?= htmlspecialchars($t['prenom'] . ' ' . $t['nom']) ?></option>
                <?php endforeach; ?>
            </select><br>
        </div>
        <div id="subject_select" style="display:none;">
            <label>Subject (optional):</label>
            <select name="id_matiere">
                <option value="">None</option>
                <?php foreach ($subjects as $sub): ?>
                    <option value="<?= $sub['id_matiere'] ?>"><?= htmlspecialchars($sub['nom_matiere']) ?></option>
                <?php endforeach; ?>
            </select><br>
        </div>
        <button type="submit" class="btn btn-primary">Send Notification</button>
        <a href="ADDashboard.php" class="btn btn-link">Back</a>
    </form>
</div>
<script>
function toggleTargetFields() {
    var role = document.getElementById('role_target').value;
    document.getElementById('student_select').style.display = (role === 'student') ? '' : 'none';
    document.getElementById('teacher_select').style.display = (role === 'teacher') ? '' : 'none';
    document.getElementById('subject_select').style.display = (role !== 'all') ? '' : 'none';
}
</script>
</body>
</html>
