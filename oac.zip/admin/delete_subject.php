<?php
require_once '../auth/middleware.php';
$auth = new AuthMiddleware();
$auth->requireRole(1); // Only admin
require_once '../auth/db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $conn->prepare("DELETE FROM Matières WHERE id_matiere = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
}
$conn->close();
header('Location: view_subjects.php');
exit();
