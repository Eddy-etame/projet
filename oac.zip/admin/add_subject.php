<?php
require_once '../auth/middleware.php';
$authMiddleware = new AuthMiddleware();
$authMiddleware->requireRole(1); // Only admin

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
session_regenerate_id(true);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($_POST['subject_name']) && !empty($_POST['subject_code'])) {
    require_once '../auth/Login.php'; // Use your DB connection logic
    $subject_name = trim($_POST['subject_name']);
    $subject_code = trim($_POST['subject_code']);
    $stmt = $conn->prepare("INSERT INTO Matières (nom_matiere, code_matiere) VALUES (?, ?)");
    $stmt->bind_param("ss", $subject_name, $subject_code);
    if ($stmt->execute()) {
        $message = "Subject added successfully!";
    } else {
        $message = "Error: " . $stmt->error;
    }
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Subject</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>
<body>
    <div class="admin-dashboard">
        <h1>Add Subject</h1>
        <?php if (isset($message)) { echo '<div class="card">' . htmlspecialchars($message) . '</div>'; } ?>
        <div class="card">
            <form method="post" action="" class="add-form">
                <input type="text" name="subject_name" placeholder="Subject Name" required>
                <input type="text" name="subject_code" placeholder="Subject Code" required>
                <button type="submit">Add Subject</button>
            </form>
        </div>
        <a href="ADDashboard.php" class="btn-link">Back to Dashboard</a>
    </div>
</body>
</html>
