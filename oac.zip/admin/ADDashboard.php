<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../shared/error_logger.php';

// Check if user is logged in and is an admin
$auth = AuthMiddleware::getInstance();
$auth->requireRole(1); // 1 is the id for admin role

// Get database connection
$conn = getDBConnection();

// Get admin info from database
$admin_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT nom_utilisateur as username FROM Utilisateurs WHERE id_utilisateur = ? AND id_role = 1");
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$admin = $result->fetch_assoc();

if (!$admin) {
    $auth->clearSession();
    header('Location: ../auth/Login.php?error=invalid_admin');
    exit();
}

$message = '';
$error = '';

// Handle email sending
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['recipients'])) {
    $recipient_ids = $_POST['recipients'];
    $subject = trim($_POST['subject']);
    $email_content = trim($_POST['message']);
    
    if (empty($recipient_ids)) {
        $error = "Please select at least one recipient";
    } elseif (empty($subject)) {
        $error = "Subject is required";
    } elseif (empty($email_content)) {
        $error = "Message content is required";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Handle file upload if present
            $attachment_path = null;
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = '../uploads/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $file_name = time() . '_' . basename($_FILES['attachment']['name']);
                $target_path = $upload_dir . $file_name;
                
                if (move_uploaded_file($_FILES['attachment']['tmp_name'], $target_path)) {
                    $attachment_path = $target_path;
                }
            }
            
            // Prepare the insert statement once
            $stmt = $conn->prepare("
                INSERT INTO emails (sender_id, recipient_id, subject, message, attachment_path) 
                VALUES (?, ?, ?, ?, ?)
            ");
            
            if (!$stmt) {
                throw new Exception("Failed to prepare statement: " . $conn->error);
            }
            
            $stmt->bind_param("iisss", $_SESSION['user_id'], $recipient_id, $subject, $email_content, $attachment_path);
            
            // Send email to each recipient
            $success_count = 0;
            foreach ($recipient_ids as $recipient_id) {
                if ($stmt->execute()) {
                    $success_count++;
                } else {
                    throw new Exception("Failed to send email to recipient ID $recipient_id: " . $stmt->error);
                }
            }
            
            $stmt->close();
            
            // If we got here, commit the transaction
            $conn->commit();
            $message = "Email sent successfully to $success_count recipient(s)";
            
        } catch (Exception $e) {
            // An error occurred, rollback the transaction
            $conn->rollback();
            $error = "Error: " . $e->getMessage();
            
            // Delete uploaded file if it exists
            if ($attachment_path && file_exists($attachment_path)) {
                unlink($attachment_path);
            }
        }
    }
}

// Get all users with their roles
$stmt = $conn->prepare("
    SELECT 
        u.id_utilisateur,
        u.nom,
        u.prenom,
        u.email,
        u.est_actif,
        u.date_creation,
        u.derniere_connexion,
        r.id_role as role,
        CASE 
            WHEN e.id_etudiant IS NOT NULL THEN 'student'
            WHEN t.id_enseignant IS NOT NULL THEN 'teacher'
            ELSE 'admin'
        END as user_type
    FROM Utilisateurs u
    JOIN Roles r ON u.id_role = r.id_role
    LEFT JOIN Etudiants e ON u.id_utilisateur = e.id_utilisateur
    LEFT JOIN Enseignants t ON u.id_utilisateur = t.id_utilisateur
    WHERE u.est_actif = 1
    ORDER BY u.date_creation DESC
");
$stmt->execute();
$result = $stmt->get_result();
$users = $result->fetch_all(MYSQLI_ASSOC);

// Separate users into teachers and students for the email form
$teachers = array_filter($users, function($user) {
    return $user['user_type'] === 'teacher';
});
$students = array_filter($users, function($user) {
    return $user['user_type'] === 'student';
});

try {
    $conn = getDBConnection();
    
    // Get counts for dashboard
    $counts = [
        'students' => 0,
        'teachers' => 0,
        'subjects' => 0,
        'grades' => 0,
        'pending_grades' => 0
    ];
    
    // Get student count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Etudiants WHERE est_actif = 1");
    $stmt->execute();
    $counts['students'] = $stmt->get_result()->fetch_row()[0];
    
    // Get teacher count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Enseignants WHERE est_actif = 1");
    $stmt->execute();
    $counts['teachers'] = $stmt->get_result()->fetch_row()[0];
    
    // Get subject count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Matieres");
    $stmt->execute();
    $counts['subjects'] = $stmt->get_result()->fetch_row()[0];
    
    // Get total grades count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Notes WHERE est_publie = 1");
    $stmt->execute();
    $counts['grades'] = $stmt->get_result()->fetch_row()[0];
    
    // Get pending grades count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Notes WHERE est_publie = 0");
    $stmt->execute();
    $counts['pending_grades'] = $stmt->get_result()->fetch_row()[0];
    
    // Get recent activities
    $sql = "SELECT 
                'grade' as type,
                n.date_saisie as date,
                CONCAT(e.nom, ' ', e.prenom) as student_name,
                m.nom_matiere as subject,
                n.valeur_note as grade,
                CONCAT(u.prenom, ' ', u.nom) as teacher_name
            FROM Notes n
            JOIN Etudiants e ON n.id_etudiant = e.id_etudiant
            JOIN Matieres m ON n.id_matiere = m.id_matiere
            JOIN Utilisateurs u ON n.id_enseignant_saisie = u.id_utilisateur
            WHERE n.date_saisie >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            UNION
            SELECT 
                'login' as type,
                u.derniere_connexion as date,
                CONCAT(u.prenom, ' ', u.nom) as user_name,
                r.nom_role as role,
                NULL as grade,
                NULL as teacher_name
            FROM Utilisateurs u
            JOIN Roles r ON u.id_role = r.id_role
            WHERE u.derniere_connexion >= DATE_SUB(NOW(), INTERVAL 7 DAY)
            ORDER BY date DESC
            LIMIT 10";
    
    $result = $conn->query($sql);
    $recent_activities = $result->fetch_all(MYSQLI_ASSOC);
    
    // Get system stats
    $sql = "SELECT 
                AVG(n.valeur_note) as average_grade,
                COUNT(DISTINCT n.id_etudiant) as students_with_grades,
                COUNT(DISTINCT n.id_matiere) as subjects_with_grades
            FROM Notes n
            WHERE n.est_publie = 1";
    
    $result = $conn->query($sql);
    $stats = $result->fetch_assoc();
    
} catch (Exception $e) {
    error_log("Database error in admin dashboard: " . $e->getMessage());
    $error_message = "Une erreur s'est produite lors du chargement du tableau de bord.";
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - OAC</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .admin-dashboard {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .welcome-header {
            text-align: center;
            margin-bottom: 3rem;
        }
        
        .welcome-header h1 {
            font-size: 2.5rem;
            color: #333;
            margin: 0;
        }
        
        .management-section {
            background: #fff;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .management-section h2 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 1.5rem;
        }
        
        .buttons-container {
            display: flex;
            flex-wrap: wrap;
            gap: 1rem;
            justify-content: center;
        }
        
        .action-button {
            background: #1a1a1a;
            color: #FFD700;
            padding: 1rem 2rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            text-align: center;
            min-width: 200px;
        }
        
        .action-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        .notifications-section {
            background: #fff;
            border-radius: 15px;
            padding: 2rem;
            margin-bottom: 2rem;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .notifications-section h2 {
            font-size: 1.5rem;
            color: #333;
            margin-bottom: 0.5rem;
        }
        
        .notifications-section p {
            color: #666;
            margin-bottom: 1rem;
        }
        
        .logout-container {
            text-align: center;
            margin-top: 2rem;
        }
        
        .logout-button {
            background: #1a1a1a;
            color: #FFD700;
            padding: 1rem 2rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-block;
        }
        
        .logout-button:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }
        
        body {
            background: #f0f2f5;
            margin: 0;
            min-height: 100vh;
        }
        
        .dashboard-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 1rem 2rem;
            background: #1a1a1a;
            color: #FFD700;
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 1000;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .datetime-display {
            font-size: 1.1rem;
            font-weight: 500;
        }

        .admin-info-container {
            position: relative;
        }

        .admin-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #FFD700;
            color: #1a1a1a;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            font-size: 1.5rem;
            transition: all 0.3s ease;
        }

        .admin-icon:hover {
            transform: scale(1.05);
            box-shadow: 0 2px 10px rgba(255,215,0,0.2);
        }

        .admin-dropdown {
            position: absolute;
            top: 100%;
            right: 0;
            margin-top: 10px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 1rem;
            min-width: 200px;
            display: none;
            color: #333;
        }

        .admin-dropdown.show {
            display: block;
        }

        .admin-dropdown h4 {
            margin: 0 0 0.5rem;
        }

        .admin-dropdown p {
            margin: 0.25rem 0;
            font-size: 0.9rem;
            color: #666;
        }

        .admin-dropdown hr {
            margin: 0.5rem 0;
            border: none;
            border-top: 1px solid #eee;
        }

        .admin-dropdown a {
            color: #1a1a1a;
            text-decoration: none;
            font-size: 0.9rem;
            display: block;
            padding: 0.5rem 0;
            transition: color 0.3s ease;
        }

        .admin-dropdown a:hover {
            color: #FFD700;
        }

        /* Adjust main content to account for fixed header */
        .admin-dashboard {
            padding-top: 5rem;
        }

        /* Stats Grid Styles */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1.5rem;
            margin-top: 1.5rem;
        }

        .stat-card {
            background: white;
            border-radius: 10px;
            padding: 1.5rem;
            text-align: center;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
        }

        .stat-card i {
            font-size: 2.5rem;
            color: #FFD700;
            margin-bottom: 1rem;
        }

        .stat-card h3 {
            color: #666;
            font-size: 1rem;
            margin: 0.5rem 0;
        }

        .stat-card .stat-number {
            color: #1a1a1a;
            font-size: 2rem;
            font-weight: bold;
            margin: 0;
        }

        /* Email Section Styles */
        .email-section {
            background: #fff;
            border-radius: 15px;
            padding: 2rem;
            margin: 2rem 0;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }

        .email-section h2 {
            color: #1a1a1a;
            margin-bottom: 1.5rem;
            font-size: 1.8rem;
        }

        .email-form {
            max-width: 800px;
            margin: 0 auto;
        }

        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: #1a1a1a;
            font-weight: 500;
        }

        .form-control {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid #ddd;
            border-radius: 8px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #FFD700;
            outline: none;
            box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.2);
        }

        .select2-container--default .select2-selection--multiple {
            border: 2px solid #ddd;
            border-radius: 8px;
            min-height: 45px;
        }

        .select2-container--default.select2-container--focus .select2-selection--multiple {
            border-color: #FFD700;
            outline: none;
            box-shadow: 0 0 0 2px rgba(255, 215, 0, 0.2);
        }

        .select2-container--default .select2-selection--multiple .select2-selection__choice {
            background-color: #1a1a1a;
            color: #FFD700;
            border: none;
            border-radius: 4px;
            padding: 4px 8px;
        }

        .select2-container--default .select2-selection--multiple .select2-selection__choice__remove {
            color: #FFD700;
            margin-right: 5px;
        }

        .btn-send {
            background: #1a1a1a;
            color: #FFD700;
            padding: 0.75rem 2rem;
            border: none;
            border-radius: 8px;
            font-size: 1rem;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-send:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        }

        .alert {
            padding: 1rem;
            border-radius: 8px;
            margin-bottom: 1rem;
        }

        .alert-success {
            background-color: rgba(40, 167, 69, 0.1);
            border: 1px solid rgba(40, 167, 69, 0.2);
            color: #28a745;
        }

        .alert-danger {
            background-color: rgba(220, 53, 69, 0.1);
            border: 1px solid rgba(220, 53, 69, 0.2);
            color: #dc3545;
        }
    </style>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
</head>
<body>
    <!-- Add Header Section -->
    <div class="dashboard-header">
        <div class="datetime-display" id="datetime">
            <!-- Will be updated by JavaScript -->
        </div>
        <div class="admin-info-container">
            <div class="admin-icon" onclick="toggleAdminDropdown()">
                <i class="uil uil-user"></i>
            </div>
            <div class="admin-dropdown" id="adminDropdown">
                <h4>Admin Profile</h4>
                <p><?php echo htmlspecialchars($admin['username']); ?></p>
                <hr>
                <a href="profile.php"><i class="uil uil-setting"></i> Settings</a>
                <a href="../logout.php"><i class="uil uil-signout"></i> Logout</a>
            </div>
        </div>
    </div>

    <div class="admin-dashboard">
        <div class="welcome-header">
            <h1>Welcome, <?php echo htmlspecialchars($admin['username']); ?>!</h1>
        </div>
        
        <!-- Stats Overview -->
        <div class="management-section">
            <h2>Overview</h2>
            <div class="stats-grid">
                <div class="stat-card">
                    <i class="uil uil-graduation-cap"></i>
                    <h3>Students</h3>
                    <p class="stat-number" id="studentCount">0</p>
                </div>
                <div class="stat-card">
                    <i class="uil uil-users-alt"></i>
                    <h3>Teachers</h3>
                    <p class="stat-number" id="teacherCount">0</p>
                </div>
                <div class="stat-card">
                    <i class="uil uil-book-alt"></i>
                    <h3>Subjects</h3>
                    <p class="stat-number" id="subjectCount">0</p>
                </div>
                <div class="stat-card">
                    <i class="uil uil-file-check-alt"></i>
                    <h3>Published Notes</h3>
                    <p class="stat-number" id="noteCount">0</p>
                </div>
                <div class="stat-card">
                    <i class="uil uil-file-edit-alt"></i>
                    <h3>Pending Notes</h3>
                    <p class="stat-number" id="pendingNoteCount">0</p>
                </div>
            </div>
        </div>
        
        <!-- Email Section -->
        <div class="email-section">
            <h2>Send Email</h2>
            <?php if (isset($error) && $error): ?>
                <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
            
            <?php if (isset($message) && $message): ?>
                <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data" class="email-form">
                <div class="form-group">
                    <label for="recipients">Recipients</label>
                    <select name="recipients[]" id="recipients" class="form-control" multiple required>
                        <?php if (!empty($teachers)): ?>
                        <optgroup label="Teachers">
                            <?php foreach ($teachers as $teacher): ?>
                                <option value="<?php echo htmlspecialchars($teacher['id_utilisateur']); ?>">
                                    <?php echo htmlspecialchars($teacher['nom'] . ' ' . $teacher['prenom'] . ' (' . $teacher['email'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                        <?php endif; ?>
                        
                        <?php if (!empty($students)): ?>
                        <optgroup label="Students">
                            <?php foreach ($students as $student): ?>
                                <option value="<?php echo htmlspecialchars($student['id_utilisateur']); ?>">
                                    <?php echo htmlspecialchars($student['nom'] . ' ' . $student['prenom'] . ' (' . $student['email'] . ')'); ?>
                                </option>
                            <?php endforeach; ?>
                        </optgroup>
                        <?php endif; ?>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" name="subject" id="subject" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea name="message" id="message" class="form-control" rows="6" required></textarea>
                </div>
                
                <div class="form-group">
                    <label for="attachment">Attachment (optional)</label>
                    <input type="file" name="attachment" id="attachment" class="form-control">
                </div>
                
                <button type="submit" class="btn-send">Send Email</button>
            </form>
        </div>
        
        <!-- User Management Section -->
        <div class="management-section">
            <h2>Communication</h2>
            <div class="buttons-container">
                <a href="send_email.php" class="action-button">
                    <i class="uil uil-envelope"></i>
                    Send Email
                </a>
            </div>
        </div>
        
        <!-- Academic Management Section -->
        <div class="management-section">
            <h2>User Management</h2>
            <div class="buttons-container">
                <a href="add_student.php" class="action-button">Ajouter un Étudiant</a>
                <a href="add_teacher.php" class="action-button">Ajouter un Enseignant</a>
                <a href="view_students.php" class="action-button">Voir les Étudiants</a>
                <a href="view_teachers.php" class="action-button">Voir les Enseignants</a>
            </div>
        </div>
        
        <!-- Academic Management Section -->
        <div class="management-section">
            <h2>Gestion Académique</h2>
            <div class="buttons-container">
                <a href="add_subject.php" class="action-button">Ajouter une Matière</a>
                <a href="view_subjects.php" class="action-button">Voir les Matières</a>
                <a href="view_notes.php" class="action-button">Voir les Notes</a>
            </div>
        </div>
        
        <!-- Performance Chart Section -->
        <div class="management-section">
            <h2>Performance Overview</h2>
            <div style="position: relative; height: 300px;">
                <canvas id="performanceChart"></canvas>
            </div>
        </div>
        
        <!-- Notifications Section -->
        <div class="notifications-section">
            <h2>Notifications</h2>
            <p>Envoyer des annonces et notifications aux utilisateurs.</p>
            <a href="notifications.php" class="action-button">Gérer les Notifications</a>
        </div>
        
        <!-- Logout Button -->
        <div class="logout-container">
            <a href="../logout.php" class="logout-button">Se déconnecter</a>
        </div>
    </div>

    <!-- Add JavaScript for datetime and dropdown -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        // Initialize Select2
        $(document).ready(function() {
            $('#recipients').select2({
                placeholder: "Select recipients",
                allowClear: true,
                theme: "classic"
            });
        });

        // Update datetime display
        function updateDateTime() {
            const now = new Date();
            const options = { 
                weekday: 'long', 
                year: 'numeric', 
                month: 'long', 
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit',
                second: '2-digit'
            };
            document.getElementById('datetime').textContent = now.toLocaleDateString('fr-FR', options);
        }

        // Update time every second
        updateDateTime();
        setInterval(updateDateTime, 1000);

        // Toggle admin dropdown
        function toggleAdminDropdown() {
            const dropdown = document.getElementById('adminDropdown');
            dropdown.classList.toggle('show');
        }

        // Close dropdown when clicking outside
        window.onclick = function(event) {
            if (!event.target.matches('.admin-icon')) {
                const dropdowns = document.getElementsByClassName('admin-dropdown');
                for (let dropdown of dropdowns) {
                    if (dropdown.classList.contains('show')) {
                        dropdown.classList.remove('show');
                    }
                }
            }
        }

        // Update counts
        function updateCounts() {
            fetch('get_counts.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        const counts = data.counts;
                        document.getElementById('studentCount').textContent = counts.students;
                        document.getElementById('teacherCount').textContent = counts.teachers;
                        document.getElementById('subjectCount').textContent = counts.subjects;
                        document.getElementById('noteCount').textContent = counts.notes;
                        document.getElementById('pendingNoteCount').textContent = counts.pending_grades;
                    }
                })
                .catch(error => console.error('Error fetching counts:', error));
        }

        // Update counts every 30 seconds
        updateCounts();
        setInterval(updateCounts, 30000);

        // Get monthly grade averages
        function getMonthlyAverages() {
            fetch('get_monthly_averages.php')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        updatePerformanceChart(data.averages);
                    }
                })
                .catch(error => console.error('Error fetching averages:', error));
        }

        // Initialize performance chart
        const ctx = document.getElementById('performanceChart').getContext('2d');
        const performanceChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: [],
                datasets: [{
                    label: 'Moyenne des notes',
                    data: [],
                    borderColor: '#4CAF50',
                    tension: 0.4,
                    fill: false
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 20,
                        title: {
                            display: true,
                            text: 'Note moyenne'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Mois'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: true,
                        position: 'top'
                    },
                    tooltip: {
                        mode: 'index',
                        intersect: false
                    }
                }
            }
        });

        function updatePerformanceChart(averages) {
            performanceChart.data.labels = averages.map(a => a.month);
            performanceChart.data.datasets[0].data = averages.map(a => a.average);
            performanceChart.update();
        }

        // Update chart data initially and every 5 minutes
        getMonthlyAverages();
        setInterval(getMonthlyAverages, 300000);
    </script>
</body>
</html>