<?php
require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';

// Check if user is logged in and is an admin
$auth = AuthMiddleware::getInstance();
$auth->requireRole(1);

header('Content-Type: application/json');

try {
    $conn = getDBConnection();
    
    // Get counts
    $counts = [
        'students' => 0,
        'teachers' => 0,
        'subjects' => 0,
        'notes' => 0,
        'pending_notes' => 0
    ];
    
    // Get student count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Etudiants WHERE est_actif = 1");
    $stmt->execute();
    $counts['students'] = $stmt->get_result()->fetch_row()[0];
    
    // Get teacher count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Enseignants WHERE est_actif = 1");
    $stmt->execute();
    $counts['teachers'] = $stmt->get_result()->fetch_row()[0];
    
    // Get subject count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Matieres");
    $stmt->execute();
    $counts['subjects'] = $stmt->get_result()->fetch_row()[0];
    
    // Get published notes count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Notes WHERE est_publie = 1");
    $stmt->execute();
    $counts['notes'] = $stmt->get_result()->fetch_row()[0];
    
    // Get pending notes count
    $stmt = $conn->prepare("SELECT COUNT(*) FROM Notes WHERE est_publie = 0");
    $stmt->execute();
    $counts['pending_notes'] = $stmt->get_result()->fetch_row()[0];
    
    echo json_encode([
        'success' => true,
        'counts' => $counts
    ]);
    
} catch (Exception $e) {
    error_log("Error fetching counts: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Failed to fetch counts'
    ]);
}

$conn->close(); 