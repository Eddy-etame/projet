<?php
require_once '../auth/db.php';
header('Content-Type: application/json');
$count = 0;
$res = $conn->query("SELECT COUNT(*) as count FROM Matieres");
if ($res && $row = $res->fetch_assoc()) {
    $count = (int)$row['count'];
}
echo json_encode(['count' => $count]);
$conn->close();
