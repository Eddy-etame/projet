<?php
require_once '../auth/middleware.php';
$authMiddleware = new AuthMiddleware();
$authMiddleware->requireRole(1); // Only admin
require_once '../auth/db.php';

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    // Delete from Enseignants first (if exists)
    $stmt = $conn->prepare("DELETE FROM Enseignants WHERE id_utilisateur = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->close();
    // Then delete from Utilisateurs
    $stmt2 = $conn->prepare("DELETE FROM Utilisateurs WHERE id_utilisateur = ?");
    $stmt2->bind_param("i", $id);
    $stmt2->execute();
    $stmt2->close();
}
$conn->close();
header('Location: view_teachers.php');
exit();
