<?php
require_once '../auth/middleware.php';
$auth = new AuthMiddleware();
$auth->requireRole(1); // Only admin
require_once '../auth/db.php'; // Use db.php for $conn

// Pagination logic
$perPage = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;
$totalQuery = $conn->query("SELECT COUNT(*) FROM Utilisateurs WHERE id_role = 3");
$totalRows = $totalQuery->fetch_row()[0];
$totalPages = ceil($totalRows / $perPage);
$result = $conn->query("SELECT id_utilisateur, nom, prenom, email FROM Utilisateurs WHERE id_role = 3 LIMIT $perPage OFFSET $offset");
$students = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Students</title>
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <link rel="stylesheet" href="../css/admin-dashboard.css">
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #6a82fb; color: #fff; }
        tr:hover { background: #f0f6ff; }
        .pagination {
            margin-top: 20px;
            text-align: center;
        }
        .pagination a, .pagination span {
            display: inline-block;
            padding: 8px 12px;
            margin: 0 4px;
            border: 1px solid #6a82fb;
            color: #6a82fb;
            text-decoration: none;
            border-radius: 4px;
        }
        .pagination a:hover {
            background: #6a82fb;
            color: #fff;
        }
        .pagination .active {
            background: #6a82fb;
            color: #fff;
            border: 1px solid #6a82fb;
        }
    </style>
</head>
<body>
    <div class="admin-dashboard">
        <h1>All Students</h1>
        <table>
            <tr><th>Name</th><th>Email</th><th>Actions</th></tr>
            <?php foreach ($students as $student): ?>
            <tr>
                <td><?= htmlspecialchars($student['prenom'] . ' ' . $student['nom']) ?></td>
                <td><?= htmlspecialchars($student['email']) ?></td>
                <td>
                    <a href="delete_student.php?id=<?= $student['id_utilisateur'] ?>" class="action-btn">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <!-- Pagination controls -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        <a href="ADDashboard.php" class="btn-link">Back to Dashboard</a>
    </div>
</body>
<script>
// Confirm delete dialog for all delete buttons
const deleteLinks = document.querySelectorAll('a[href*="delete_student.php"]');
deleteLinks.forEach(link => {
  link.addEventListener('click', function(e) {
    if(!confirm('Are you sure you want to delete this student? This action cannot be undone.')) {
      e.preventDefault();
    }
  });
});
</script>
</html>
