<?php
// add_test_users.php
require_once __DIR__ . '/../auth/db.php';

// --- Add Teacher (eddy) ---
$teacher_username = 'eddy';
$teacher_password = 'password';
$teacher_email = 'eddy@example.com';
$teacher_nom = 'Eddy';
$teacher_prenom = 'Ed';
$teacher_role = 2; // Teacher
$teacher_must_change = 1;

$hashed_teacher_password = password_hash($teacher_password, PASSWORD_BCRYPT);

$stmt = $conn->prepare("INSERT INTO Utilisateurs (id_role, email, mot_de_passe, nom, prenom, nom_utilisateur, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt->bind_param("isssssi", $teacher_role, $teacher_email, $hashed_teacher_password, $teacher_nom, $teacher_prenom, $teacher_username, $teacher_must_change);
$stmt->execute();
$teacher_id_utilisateur = $stmt->insert_id;
$stmt->close();

$stmt2 = $conn->prepare("INSERT INTO Enseignants (id_utilisateur, nom, prenom, email, nom_utilisateur) VALUES (?, ?, ?, ?, ?)");
$stmt2->bind_param("issss", $teacher_id_utilisateur, $teacher_nom, $teacher_prenom, $teacher_email, $teacher_username);
$stmt2->execute();
$stmt2->close();

// --- Add Student (etame) ---
$student_username = 'etame';
$student_password = 'password';
$student_email = 'etame@example.com';
$student_nom = 'Etame';
$student_prenom = 'Et';
$student_role = 3; // Student
$student_must_change = 1;

$hashed_student_password = password_hash($student_password, PASSWORD_BCRYPT);

$stmt3 = $conn->prepare("INSERT INTO Utilisateurs (id_role, email, mot_de_passe, nom, prenom, nom_utilisateur, must_change_password) VALUES (?, ?, ?, ?, ?, ?, ?)");
$stmt3->bind_param("isssssi", $student_role, $student_email, $hashed_student_password, $student_nom, $student_prenom, $student_username, $student_must_change);
$stmt3->execute();
$student_id_utilisateur = $stmt3->insert_id;
$stmt3->close();

$code_etudiant = 'ETU' . $student_id_utilisateur;
$id_promotion = 1; // Default promotion (adjust as needed)
$date_de_naissance = '2000-01-01';
$adresse = '123 Main St';
$telephone = '0123456789';

$stmt4 = $conn->prepare("INSERT INTO Etudiants (id_utilisateur, code_etudiant, id_promotion, date_de_naissance, adresse, telephone) VALUES (?, ?, ?, ?, ?, ?)");
$stmt4->bind_param("isisss", $student_id_utilisateur, $code_etudiant, $id_promotion, $date_de_naissance, $adresse, $telephone);
$stmt4->execute();
$stmt4->close();

echo "Test teacher and student created.\n";
