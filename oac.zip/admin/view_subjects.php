<?php
require_once '../auth/middleware.php';
$authMiddleware = new AuthMiddleware();
$authMiddleware->requireRole(1); // Only admin
require_once '../auth/Login.php';

// Pagination logic
$perPage = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;
$totalQuery = $conn->query("SELECT COUNT(*) FROM Matieres");
$totalRows = $totalQuery->fetch_row()[0];
$totalPages = ceil($totalRows / $perPage);
$result = $conn->query("SELECT * FROM Matieres LIMIT $perPage OFFSET $offset");
$subjects = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Subjects</title>
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>
<body>
    <div class="admin-dashboard">
        <h1>All Subjects</h1>
        <table>
            <tr><th>Subject Name</th><th>Subject Code</th><th>Actions</th></tr>
            <?php foreach ($subjects as $subject): ?>
            <tr>
                <td><?= htmlspecialchars($subject['nom_matiere']) ?></td>
                <td><?= htmlspecialchars($subject['code_matiere']) ?></td>
                <td>
                    <a href="delete_subject.php?id=<?= $subject['id_matiere'] ?>" class="action-btn">Delete</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        
        <!-- Pagination controls -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        
        <a href="ADDashboard.php" class="btn-link">Back to Dashboard</a>
    </div>
</body>
</html>
<script>
// Confirm delete dialog for all delete buttons
const deleteLinks = document.querySelectorAll('a[href*="delete_subject.php"]');
deleteLinks.forEach(link => {
  link.addEventListener('click', function(e) {
    if(!confirm('Are you sure you want to delete this subject? This action cannot be undone.')) {
      e.preventDefault();
    }
  });
});
</script>
