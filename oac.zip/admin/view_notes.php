<?php
require_once '../auth/middleware.php';
$authMiddleware = new AuthMiddleware();
$authMiddleware->requireRole(1); // Only admin
require_once '../auth/Login.php';

// Pagination logic
$perPage = 10;
$page = isset($_GET['page']) ? max(1, intval($_GET['page'])) : 1;
$offset = ($page - 1) * $perPage;
$totalQuery = $conn->query("SELECT COUNT(*) FROM Notes WHERE est_publie = 1");
$totalRows = $totalQuery->fetch_row()[0];
$totalPages = ceil($totalRows / $perPage);
$result = $conn->query("SELECT Notes.id_note, Utilisateurs.prenom, Utilisateurs.nom, Matieres.nom_matiere, Notes.valeur_note, Notes.date_saisie, Notes.est_publie, T.prenom AS prof_prenom, T.nom AS prof_nom FROM Notes JOIN Etudiants ON Notes.id_etudiant = Etudiants.id_etudiant JOIN Utilisateurs ON Etudiants.id_utilisateur = Utilisateurs.id_utilisateur JOIN Matieres ON Notes.id_matiere = Matieres.id_matiere JOIN Utilisateurs T ON Notes.id_enseignant_saisie = T.id_utilisateur WHERE Notes.est_publie = 1 ORDER BY Notes.date_saisie DESC LIMIT $perPage OFFSET $offset");
$notes = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Notes</title>
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <link rel="stylesheet" href="../css/admin-dashboard.css">
    <style>
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 10px; border-bottom: 1px solid #eee; text-align: left; }
        th { background: #fc5c7d; color: #fff; }
        tr:hover { background: #f0f6ff; }
        .pagination { margin-top: 20px; }
        .pagination a, .pagination span { 
            display: inline-block; 
            padding: 8px 12px; 
            margin: 0 4px; 
            text-decoration: none; 
            border: 1px solid #fc5c7d; 
            color: #fc5c7d; 
            border-radius: 4px;
        }
        .pagination .active { 
            background: #fc5c7d; 
            color: #fff; 
            border: 1px solid #fc5c7d;
        }
    </style>
</head>
<body>
    <div class="admin-dashboard">
        <h1>All Notes</h1>
        <table>
            <tr><th>Student</th><th>Subject</th><th>Note</th><th>Date</th><th>Teacher</th><th>Publié</th></tr>
            <?php foreach ($notes as $note): ?>
            <tr>
                <td><?= htmlspecialchars($note['prenom'] . ' ' . $note['nom']) ?></td>
                <td><?= htmlspecialchars($note['nom_matiere']) ?></td>
                <td><?= htmlspecialchars($note['valeur_note']) ?></td>
                <td><?= htmlspecialchars($note['date_saisie']) ?></td>
                <td><?= htmlspecialchars($note['prof_prenom'] . ' ' . $note['prof_nom']) ?></td>
                <td><span class="badge badge-success">Publié</span></td>
            </tr>
            <?php endforeach; ?>
        </table>
        
        <!-- Pagination controls -->
        <?php if ($totalPages > 1): ?>
        <div class="pagination">
            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i == $page): ?>
                    <span class="active"><?= $i ?></span>
                <?php else: ?>
                    <a href="?page=<?= $i ?>"><?= $i ?></a>
                <?php endif; ?>
            <?php endfor; ?>
        </div>
        <?php endif; ?>
        
        <a href="ADDashboard.php" class="btn-link">Back to Dashboard</a>
    </div>
</body>
</html>
<script>
// Confirm delete dialog for all delete buttons
const deleteLinks = document.querySelectorAll('a[href*="delete_note.php"]');
deleteLinks.forEach(link => {
  link.addEventListener('click', function(e) {
    if(!confirm('Are you sure you want to delete this note? This action cannot be undone.')) {
      e.preventDefault();
    }
  });
});
</script>
