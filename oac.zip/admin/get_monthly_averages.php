<?php
require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';

// Check if user is logged in and is an admin
$auth = AuthMiddleware::getInstance();
$auth->requireRole(1);

header('Content-Type: application/json');

try {
    $conn = getDBConnection();
    
    // Get monthly averages for the last 6 months
    $stmt = $conn->prepare("
        SELECT 
            DATE_FORMAT(date_saisie, '%Y-%m') as month,
            DATE_FORMAT(date_saisie, '%b %Y') as month_label,
            ROUND(AVG(valeur_note), 2) as average
        FROM Notes
        WHERE date_saisie >= DATE_SUB(NOW(), INTERVAL 6 MONTH)
            AND est_publie = 1
        GROUP BY month
        ORDER BY month ASC
    ");
    
    $stmt->execute();
    $result = $stmt->get_result();
    $averages = [];
    
    while ($row = $result->fetch_assoc()) {
        $averages[] = [
            'month' => $row['month_label'],
            'average' => floatval($row['average'])
        ];
    }
    
    echo json_encode([
        'success' => true,
        'averages' => $averages
    ]);
    
} catch (Exception $e) {
    error_log("Error fetching monthly averages: " . $e->getMessage());
    echo json_encode([
        'success' => false,
        'error' => 'Failed to fetch monthly averages'
    ]);
}

$conn->close(); 