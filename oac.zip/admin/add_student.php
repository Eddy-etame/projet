<?php
require_once '../auth/middleware.php';
$auth = new AuthMiddleware();
$auth->requireRole('admin');

// Ensure session is started and session ID is regenerated for session isolation when creating a student
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
session_regenerate_id(true);

// Handle form submission
$password_generated = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../auth/db.php';
    // Input validation: check for duplicate email
    $email = $_POST['email'];
    $check = $conn->prepare("SELECT id_utilisateur FROM Utilisateurs WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();
    if ($check->num_rows > 0) {
        $error = "Cet email existe déjà. Veuillez en choisir un autre.";
        $check->close();
    } else {
        $check->close();
        $prenom = $_POST['prenom'];
        $nom = $_POST['nom'];
        $date_de_naissance = $_POST['date_de_naissance'];
        $adresse = $_POST['adresse'];
        $telephone = $_POST['telephone'];
        $id_promotion = $_POST['id_promotion'];
        $nom_utilisateur = $_POST['nom_utilisateur'];
        $annee = isset($_POST['annee']) ? intval($_POST['annee']) : 1;
        $password = bin2hex(random_bytes(4));
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $id_role = 3; // Student
        // Set must_change_password to 1
        $stmt = $conn->prepare("INSERT INTO Utilisateurs (id_role, email, mot_de_passe, nom, prenom, nom_utilisateur, must_change_password) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->bind_param("isssss", $id_role, $email, $hashed_password, $nom, $prenom, $nom_utilisateur);
        if ($stmt->execute()) {
            $id_utilisateur = $stmt->insert_id;
            $code_etudiant = "ETU" . $id_utilisateur;
            $stmt2 = $conn->prepare("INSERT INTO Etudiants (id_utilisateur, code_etudiant, id_promotion, date_de_naissance, adresse, telephone, annee) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt2->bind_param("isisssi", $id_utilisateur, $code_etudiant, $id_promotion, $date_de_naissance, $adresse, $telephone, $annee);
            $stmt2->execute();
            $stmt2->close();
            $password_generated = $password;
        }
        $stmt->close();
    }
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un Étudiant</title>
    <link rel="stylesheet" href="../css/admin-dashboard.css">
</head>
<body>
<div class="admin-dashboard">
    <h2>Ajouter un Étudiant</h2>
    <?php if (isset($error)): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($password_generated): ?>
        <div class="alert alert-success">Compte créé ! Mot de passe initial : <b><?= htmlspecialchars($password_generated) ?></b></div>
    <?php endif; ?>
    <form method="post">
        <input type="text" name="nom_utilisateur" placeholder="Nom d'utilisateur" required><br>
        <input type="text" name="prenom" placeholder="Prénom" required><br>
        <input type="text" name="nom" placeholder="Nom" required><br>
        <input type="email" name="email" placeholder="Email" required><br>
        <input type="date" name="date_de_naissance" placeholder="Date de naissance" required><br>
        <input type="text" name="adresse" placeholder="Adresse" required><br>
        <input type="text" name="telephone" placeholder="Téléphone" required><br>
        <label>Promotion :</label>
        <select name="id_promotion" required>
            <option value="1">B1 Informatique</option>
            <option value="2">B2 Informatique</option>
            <option value="3">B3 Informatique</option>
        </select><br>
        <label for="annee">Année d'étude (Year):</label>
        <input type="number" name="annee" id="annee" min="1" max="10" required placeholder="e.g. 1 for 1st year"><br>
        <!-- Password is always randomly generated and shown after creation. -->
        <button type="submit">Créer le compte étudiant</button>
    </form>
    <a href="ADDashboard.php">Retour au tableau de bord</a>
</div>
</body>
</html>
