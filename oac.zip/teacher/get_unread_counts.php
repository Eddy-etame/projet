<?php
require_once '../includes/db.php';
require_once '../includes/middleware.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Accès non autorisé']);
    exit;
}

$user_id = $_SESSION['user_id'];

try {
    // Get unread counts for emails and messages
    $query = "SELECT 
        SUM(CASE WHEN type = 'email' AND is_read = FALSE THEN 1 ELSE 0 END) as emails,
        SUM(CASE WHEN type = 'message' AND is_read = FALSE THEN 1 ELSE 0 END) as messages
    FROM Notifications 
    WHERE recipient_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $counts = $result->fetch_assoc();
    
    // Get count of unread news (news from last 24 hours)
    $news_query = "SELECT COUNT(*) as news 
                   FROM News 
                   WHERE created_at >= DATE_SUB(NOW(), INTERVAL 24 HOUR)";
    
    $news_result = $conn->query($news_query);
    $news_count = $news_result->fetch_assoc();
    
    $response = [
        'emails' => (int)$counts['emails'],
        'messages' => (int)$counts['messages'],
        'news' => (int)$news_count['news']
    ];
    
    echo json_encode($response);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 