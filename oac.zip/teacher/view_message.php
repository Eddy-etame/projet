<?php
require_once '../includes/db.php';
require_once '../includes/middleware.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$message_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

try {
    // Get the message and its thread
    $query = "SELECT m.*, 
              sender.nom as sender_name, 
              sender.email as sender_email,
              recipient.nom as recipient_name,
              recipient.email as recipient_email
              FROM Messages m
              JOIN Utilisateurs sender ON m.sender_id = sender.id_utilisateur
              JOIN Utilisateurs recipient ON m.recipient_id = recipient.id_utilisateur
              WHERE (m.id_message = ? OR m.parent_message_id = ?) 
              AND (m.sender_id = ? OR m.recipient_id = ?)
              ORDER BY m.created_at ASC";
              
    $stmt = $conn->prepare($query);
    $stmt->bind_param('iiii', $message_id, $message_id, $user_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $messages = $result->fetch_all(MYSQLI_ASSOC);

    if (empty($messages)) {
        header('Location: TDashboard.php');
        exit;
    }

    // Mark message as read if user is recipient
    $update_query = "UPDATE Messages 
                    SET is_read = TRUE 
                    WHERE id_message = ? AND recipient_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param('ii', $message_id, $user_id);
    $update_stmt->execute();

} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
    header('Location: TDashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Message - OAC</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <style>
        .message-thread {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: var(--white);
            border-radius: 12px;
            box-shadow: var(--shadow);
        }

        .message-item {
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            background: var(--light-bg);
        }

        .message-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            color: var(--text-dark);
        }

        .message-sender {
            font-weight: 600;
        }

        .message-time {
            color: var(--text-light);
            font-size: 0.9em;
        }

        .message-content {
            color: var(--text-dark);
            line-height: 1.5;
        }

        .reply-form {
            margin-top: 20px;
            padding: 20px;
            background: var(--white);
            border-radius: 8px;
            box-shadow: var(--shadow);
        }

        .reply-form textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            resize: vertical;
            min-height: 100px;
        }

        .btn-reply {
            background: var(--accent);
            color: var(--white);
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.2s;
        }

        .btn-reply:hover {
            background: var(--secondary);
        }
    </style>
</head>
<body>
    <div class="message-thread">
        <?php foreach ($messages as $msg): ?>
            <div class="message-item">
                <div class="message-header">
                    <span class="message-sender">
                        <?php echo htmlspecialchars($msg['sender_name']); ?> 
                        (<?php echo htmlspecialchars($msg['sender_email']); ?>)
                    </span>
                    <span class="message-time">
                        <?php echo date('d/m/Y H:i', strtotime($msg['created_at'])); ?>
                    </span>
                </div>
                <div class="message-content">
                    <?php echo nl2br(htmlspecialchars($msg['content'])); ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="reply-form">
            <h3>Répondre</h3>
            <form id="replyForm" onsubmit="return sendReply(event)">
                <input type="hidden" name="parent_id" value="<?php echo $message_id; ?>">
                <input type="hidden" name="recipient_id" value="<?php echo ($messages[0]['sender_id'] == $user_id) ? $messages[0]['recipient_id'] : $messages[0]['sender_id']; ?>">
                <textarea name="content" placeholder="Votre réponse..." required></textarea>
                <button type="submit" class="btn-reply">Envoyer la réponse</button>
            </form>
        </div>
    </div>

    <script>
    async function sendReply(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        formData.append('subject', 'RE: <?php echo htmlspecialchars($messages[0]['subject']); ?>');
        
        try {
            const response = await fetch('send_message.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            if (data.success) {
                location.reload();
            } else {
                alert(data.error || 'Erreur lors de l\'envoi de la réponse');
            }
        } catch (error) {
            alert('Erreur lors de l\'envoi de la réponse');
        }
        
        return false;
    }
    </script>
</body>
</html> 