<?php
require_once '../auth/middleware.php';
AuthMiddleware::requireRole('teacher');

session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];

$import_result = '';
$skipped_rows = [];
// Fix preview/confirm logic: retain file between steps using a temporary upload
// Use a hidden input to pass the temp file name for confirmation step

$preview_data = [];
$show_preview = false;
$temp_file = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['notes_file']) && isset($_POST['preview'])) {
    $file = $_FILES['notes_file']['tmp_name'];
    $temp_file = sys_get_temp_dir() . '/import_notes_' . uniqid() . '.csv';
    move_uploaded_file($file, $temp_file);
    if (($handle = fopen($temp_file, 'r')) !== false) {
        $header = fgetcsv($handle, 1000, ',');
        if ($header) {
            $col_map = array_flip($header);
            $max_preview = 10;
            $row = 0;
            while (($data = fgetcsv($handle, 1000, ',')) !== false && $row < $max_preview) {
                $row++;
                $row_data = [];
                foreach ($header as $col) {
                    $row_data[$col] = isset($col_map[$col]) ? $data[$col_map[$col]] : '';
                }
                $preview_data[] = $row_data;
            }
            $show_preview = true;
        }
        fclose($handle);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['import_confirm']) && isset($_POST['temp_file'])) {
    $temp_file = $_POST['temp_file'];
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $import_result = 'Erreur de sécurité : jeton CSRF invalide.';
    } elseif (!file_exists($temp_file)) {
        $import_result = 'Fichier temporaire introuvable. Veuillez réessayer.';
    } else {
        $file = $temp_file;
        $file_size = filesize($file);
        $file_type = mime_content_type($file);
        $allowed_types = ['text/plain', 'text/csv', 'application/vnd.ms-excel', 'application/csv', 'text/comma-separated-values', 'application/octet-stream'];
        if ($file_size > 2 * 1024 * 1024) { // 2MB max
            $import_result = 'Fichier trop volumineux (max 2MB).';
        } elseif (!in_array($file_type, $allowed_types)) {
            $import_result = 'Type de fichier non supporté. Veuillez importer un fichier CSV.';
        } elseif (($handle = fopen($file, 'r')) !== false) {
            require_once '../auth/Login.php';
            $teacher_id = $_SESSION['user_id'];
            $row = 0;
            $imported = 0;
            $skipped = 0;
            $header = fgetcsv($handle, 1000, ',');
            if (!$header) {
                $import_result = 'Fichier CSV invalide (en-tête manquant).';
            } else {
                // Map header columns to indices
                $col_map = array_flip($header);
                $required_cols = ['id_etudiant', 'id_matiere', 'valeur_note'];
                foreach ($required_cols as $col) {
                    if (!isset($col_map[$col])) {
                        $import_result = 'Colonne obligatoire manquante : ' . $col;
                        fclose($handle);
                        goto end_import;
                    }
                }
                while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                    $row++;
                    // Use header mapping
                    $id_etudiant = $data[$col_map['id_etudiant']];
                    $id_matiere = $data[$col_map['id_matiere']];
                    $valeur_note = $data[$col_map['valeur_note']];
                    $commentaire = isset($col_map['commentaire']) ? $data[$col_map['commentaire']] : '';
                    $type_evaluation = isset($col_map['type_evaluation']) ? $data[$col_map['type_evaluation']] : 'Examen';
                    $statut_validation = isset($col_map['statut_validation']) ? $data[$col_map['statut_validation']] : 'Brouillon';
                    $est_publie = isset($col_map['est_publie']) ? (int)$data[$col_map['est_publie']] : 0;

                    // Validate foreign keys
                    $valid_etudiant = false;
                    $valid_matiere = false;
                    $check_etudiant = $conn->prepare("SELECT 1 FROM Etudiants WHERE id_etudiant = ?");
                    $check_etudiant->bind_param("i", $id_etudiant);
                    $check_etudiant->execute();
                    $check_etudiant->store_result();
                    if ($check_etudiant->num_rows > 0) $valid_etudiant = true;
                    $check_etudiant->close();

                    $check_matiere = $conn->prepare("SELECT 1 FROM Matieres WHERE id_matiere = ?");
                    $check_matiere->bind_param("i", $id_matiere);
                    $check_matiere->execute();
                    $check_matiere->store_result();
                    if ($check_matiere->num_rows > 0) $valid_matiere = true;
                    $check_matiere->close();

                    if (!$valid_etudiant) {
                        $skipped++;
                        $skipped_rows[] = ['row' => $row + 1, 'reason' => 'id_etudiant inexistant'];
                        continue;
                    }
                    if (!$valid_matiere) {
                        $skipped++;
                        $skipped_rows[] = ['row' => $row + 1, 'reason' => 'id_matiere inexistant'];
                        continue;
                    }
                    if (!is_numeric($valeur_note) || $valeur_note < 0 || $valeur_note > 20) {
                        $skipped++;
                        $skipped_rows[] = ['row' => $row + 1, 'reason' => 'Note invalide (doit être entre 0 et 20)'];
                        continue;
                    }
                    $stmt = $conn->prepare("INSERT INTO Notes (id_etudiant, id_matiere, id_enseignant, id_enseignant_saisie, valeur_note, type_evaluation, statut_validation, date_saisie, est_publie, commentaire) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), ?, ?) ON DUPLICATE KEY UPDATE valeur_note=VALUES(valeur_note), commentaire=VALUES(commentaire), type_evaluation=VALUES(type_evaluation), statut_validation=VALUES(statut_validation), est_publie=VALUES(est_publie)");
                    $stmt->bind_param("iiiisssis", $id_etudiant, $id_matiere, $teacher_id, $teacher_id, $valeur_note, $type_evaluation, $statut_validation, $est_publie, $commentaire);
                    if ($stmt->execute()) {
                        $imported++;
                    } else {
                        $skipped++;
                        $skipped_rows[] = ['row' => $row + 1, 'reason' => 'Erreur SQL: ' . $stmt->error];
                    }
                    $stmt->close();
                }
                fclose($handle);
                // Log import event in ImportNotes table
                $file_name = basename($_FILES['notes_file']['name']);
                $stmt_log = $conn->prepare("INSERT INTO ImportNotes (id_enseignant, file_name, notes_imported) VALUES (?, ?, ?)");
                $stmt_log->bind_param("isi", $teacher_id, $file_name, $imported);
                $stmt_log->execute();
                $stmt_log->close();

                $import_result = "Importation terminée. $imported notes importées, $skipped ignorées.";
            }
            end_import:
        } else {
            $import_result = 'Erreur lors de la lecture du fichier.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Importer les notes (Excel/CSV)</title>
    <link rel="stylesheet" href="../css/teacher-dashboard.css">
</head>
<body>
<div class="teacher-dashboard">
    <h2 class="dashboard-title">Importer les notes (Excel/CSV)</h2>
    <?php if ($import_result): ?>
        <div class="alert alert-info" style="margin-bottom:16px;"><?= htmlspecialchars($import_result) ?></div>
    <?php endif; ?>
    <?php if (!empty($skipped_rows)): ?>
        <div class="alert alert-warning" style="margin-bottom:16px;">
            <b>Lignes ignorées :</b>
            <div class="table-responsive">
            <table class="styled-table" style="margin-top:8px; background:#fffbe6; border:1px solid #ffe58f; width:100%;">
                <tr><th>Ligne</th><th>Raison</th></tr>
                <?php foreach ($skipped_rows as $skip): ?>
                    <tr><td><?= htmlspecialchars($skip['row']) ?></td><td><?= htmlspecialchars($skip['reason']) ?></td></tr>
                <?php endforeach; ?>
            </table>
            </div>
        </div>
    <?php endif; ?>
    <?php if ($show_preview): ?>
        <div class="alert alert-secondary" style="margin-bottom:16px;">
            <b>Aperçu du fichier (10 premières lignes) :</b>
            <div class="table-responsive">
            <table class="styled-table" style="margin-top:8px; background:#f0f6ff; border:1px solid #b3d8fd; width:100%;">
                <tr>
                    <?php foreach ($header as $col): ?><th><?= htmlspecialchars($col) ?></th><?php endforeach; ?>
                </tr>
                <?php foreach ($preview_data as $row): ?>
                    <tr>
                        <?php foreach ($header as $col): ?><td><?= htmlspecialchars($row[$col]) ?></td><?php endforeach; ?>
                    </tr>
                <?php endforeach; ?>
            </table>
            </div>
            <form method="post">
                <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                <input type="hidden" name="import_confirm" value="1">
                <input type="hidden" name="temp_file" value="<?= htmlspecialchars($temp_file) ?>">
                <button type="submit" class="btn btn-primary" style="margin-top:12px;">Confirmer l'importation</button>
            </form>
        </div>
    <?php else: ?>
    <form method="post" enctype="multipart/form-data" class="import-form" style="margin-bottom:24px;">
        <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
        <input type="hidden" name="preview" value="1">
        <label for="notes_file" class="form-label">Fichier CSV :</label>
        <input type="file" name="notes_file" id="notes_file" accept=".csv" required class="form-control" style="margin-bottom:12px;">
        <button type="submit" class="btn btn-primary">Prévisualiser</button>
    </form>
    <?php endif; ?>
    <div class="info-card" style="background:#f9f9f9; border-radius:8px; padding:16px; margin-bottom:16px;">
        <p style="margin-bottom:8px;">Format attendu : <b>id_etudiant, id_matiere, valeur_note</b>, commentaire, type_evaluation, statut_validation, est_publie (en-tête obligatoire, les autres colonnes sont optionnelles)</p>
        <a href="sample_notes.csv" download class="btn btn-secondary" style="margin-right:8px;">Télécharger un exemple de CSV</a>
        <a href="TDashboard.php" class="btn btn-link">Retour au tableau de bord</a>
    </div>
    <?php if ($import_result && (isset($imported) && $imported > 0 || isset($skipped) && $skipped > 0)): ?>
        <div class="import-summary" style="margin-top:20px;">
            <h3 style="font-size:1.2em; color:#333;">Résumé de l'importation</h3>
            <table class="styled-table" style="width:100%; border:1px solid #eee; background:#f9f9f9;">
                <tr><th>Importées</th><th>Ignorées</th></tr>
                <tr><td><?= (int)($imported ?? 0) ?></td><td><?= (int)($skipped ?? 0) ?></td></tr>
            </table>
        </div>
    <?php endif; ?>
</div>
<style>
.dashboard-title { color: #fc5c7d; font-size: 2em; margin-bottom: 20px; }
.styled-table th, .styled-table td { padding: 8px 12px; border-bottom: 1px solid #eee; }
.styled-table th { background: #fc5c7d; color: #fff; }
.styled-table tr:hover { background: #f0f6ff; }
.btn { display: inline-block; padding: 8px 18px; border-radius: 6px; font-weight: 500; text-decoration: none; transition: background 0.2s; }
.btn-primary { background: #fc5c7d; color: #fff; border: none; }
.btn-primary:hover { background: #6a82fb; color: #fff; }
.btn-secondary { background: #FFD966; color: #222; border: none; }
.btn-secondary:hover { background: #ffe58f; color: #222; }
.btn-link { background: none; color: #6a82fb; border: none; text-decoration: underline; padding: 0; }
.btn-link:hover { color: #fc5c7d; }
.form-label { font-weight: 600; margin-bottom: 4px; display: block; }
.form-control { border: 1px solid #ccc; border-radius: 4px; padding: 6px 10px; width: 100%; max-width: 350px; }
.table-responsive { overflow-x: auto; }
.alert { border-radius: 6px; padding: 12px 18px; margin-bottom: 12px; }
.alert-info { background: #e3f0ff; color: #1a237e; border: 1px solid #b3d8fd; }
.alert-warning { background: #fffbe6; color: #ad8b00; border: 1px solid #ffe58f; }
.alert-secondary { background: #f0f6ff; color: #333; border: 1px solid #b3d8fd; }
.info-card { box-shadow: 0 2px 8px rgba(17,17,17,0.07); }
.import-summary h3 { margin-bottom: 10px; }
</style>
</body>
</html>
