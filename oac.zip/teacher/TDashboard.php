<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../shared/error_logger.php';

// Check if user is logged in and is a teacher
$auth = AuthMiddleware::getInstance();
$auth->requireRole(2); // 2 is the id for teacher role

// Get teacher data
$teacher_id = $_SESSION['user_id'];

try {
    // Get database connection
    $conn = getDBConnection();
    
    // Check if must_change_password is set for this teacher
    $stmt = $conn->prepare('SELECT must_change_password FROM Utilisateurs WHERE id_utilisateur = ?');
    $stmt->bind_param('i', $teacher_id);
    $stmt->execute();
    $stmt->bind_result($must_change_password);
    $stmt->fetch();
    $stmt->close();

    if ($must_change_password) {
        header('Location: change_password.php');
        exit();
    }
} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    // Handle error gracefully
    echo "Une erreur s'est produite. Veuillez réessayer plus tard.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="stylesheet" href="../css/teacher-dashboard.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
</head>
<body>
    <nav class="navbar navbar-dashboard">
        <div class="navbar-left">
            <span class="navbar-title">Portail Enseignant</span>
        </div>
        <div class="navbar-right">
            <div class="user-profile-menu">
                <span class="user-avatar" style="background:#fc5c7d; color:#fff; border-radius:50%; width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center; font-weight:bold; font-size:1.1em; margin-right:8px;">
                    <?= strtoupper(substr($_SESSION['user_name'] ?? '', 0, 1)) ?>
                </span>
                <span class="user-name" style="font-weight:600; color:#222; margin-right:12px;">
                    <?= htmlspecialchars($_SESSION['user_name'] ?? '') ?>
                </span>
                <div class="dropdown" style="display:inline-block; position:relative;">
                    <button class="btn btn-link" onclick="toggleProfileDropdown()" style="padding:0; font-size:1.2em;">&#x25BC;</button>
                    <div id="profileDropdown" class="dropdown-content" style="display:none; position:absolute; right:0; background:#fff; box-shadow:0 2px 8px rgba(17,17,17,0.07); border-radius:8px; min-width:180px; z-index:100;">
                        <a href="TDashboard.php" class="dropdown-item">Tableau de bord</a>
                        <a href="#" class="dropdown-item" onclick="showProfileModal();return false;">Mon profil</a>
                        <a href="change_password.php" class="dropdown-item">Changer le mot de passe</a>
                        <a href="../logout.php" class="dropdown-item" style="color:#fc5c7d;">Se déconnecter</a>
                    </div>
                </div>
            </div>
            <div class="notification-icons">
                <div class="notification-icon-wrapper">
                    <a href="#" onclick="toggleNotificationPanel('email'); return false;" class="notification-icon">
                        <i class="uil uil-envelope"></i>
                        <span id="emailBadge" class="notification-badge" style="display: none;">0</span>
                    </a>
                </div>
                <div class="notification-icon-wrapper">
                    <a href="#" onclick="toggleNotificationPanel('news'); return false;" class="notification-icon">
                        <i class="uil uil-newspaper"></i>
                        <span id="newsBadge" class="notification-badge" style="display: none;">0</span>
                    </a>
                </div>
                <div class="notification-icon-wrapper">
                    <a href="#" onclick="toggleNotificationPanel('message'); return false;" class="notification-icon">
                        <i class="uil uil-comment-alt"></i>
                        <span id="messageBadge" class="notification-badge" style="display: none;">0</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <div class="teacher-dashboard">
        <div class="profile-card">
            <div class="profile-image">
                <img src="../img/default-profile.png" alt="Profile Picture" />
            </div>
            <div class="profile-info">
                <h2><?= htmlspecialchars($_SESSION['user_name'] ?? 'Teacher') ?></h2>
                <p><strong>Email:</strong> <?= htmlspecialchars($_SESSION['user_email'] ?? '') ?></p>
                <p><strong>Username:</strong> <?= htmlspecialchars($_SESSION['user_username'] ?? '') ?></p>
                <p><strong>Teacher ID:</strong> <?= htmlspecialchars($teacher_id ?? '') ?></p>
            </div>
        </div>
        <div class="dashboard-settings-panel">
            <div class="settings-card">
                <div class="settings-header">
                    <span class="settings-icon">
                        <svg width="28" height="28" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#FFD966"/><path d="M12 7v5l3 3" stroke="#222" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </span>
                    <span class="settings-title">Date & Heure</span>
                </div>
                <div class="settings-content">
                    <div class="settings-datetime">
                        <span id="dashboardDateTime" style="font-size:1.1rem; color:var(--accent,#222);"></span>
                    </div>
                </div>
            </div>
            <div class="settings-card">
                <div class="settings-header">
                    <span class="settings-icon">
                        <svg width="28" height="28" fill="none" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#B3E6FF"/><path d="M8 15h8M12 7v8" stroke="#222" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>
                    </span>
                    <span class="settings-title">Météo</span>
                </div>
                <div class="settings-content">
                    <div class="settings-weather" id="dashboardWeather" style="font-size:1.1rem; color:var(--accent,#222);">
                        <span id="weatherIcon" style="font-size:1.5rem; vertical-align:middle;"></span>
                        <span id="weatherDesc">Chargement...</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="dashboard-actions" style="margin: 2rem 0; display: flex; flex-wrap: wrap; gap: 1.5rem;">
            <a href="import_notes.php" class="btn btn-primary">Importer des notes</a>
            <a href="manage_notes.php" class="btn btn-secondary">Gérer les notes</a>
            <a href="choose_subjects.php" class="btn btn-secondary">Choisir les matières</a>
            <a href="change_password.php" class="btn btn-link">Changer le mot de passe</a>
            <a href="../logout.php" class="btn btn-link" style="color:#fc5c7d;">Se déconnecter</a>
        </div>
        <div class="info-card" style="background:#f9f9f9; border-radius:8px; padding:16px; margin-bottom:16px;">
            <h3 style="color:#fc5c7d;">Bienvenue sur votre tableau de bord enseignant</h3>
            <p>Utilisez les boutons ci-dessus pour gérer vos matières, notes, et paramètres de compte.</p>
        </div>
        <div class="col-md-4 mb-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Email Management</h5>
                    <p class="card-text">Send and manage emails to students.</p>
                    <a href="send_email.php" class="btn btn-primary">Send Email</a>
                    <a href="../includes/email/view_emails.php" class="btn btn-info">View Emails</a>
                </div>
            </div>
        </div>
    </div>
    <!-- Profile Modal -->
    <div id="profileModal" class="modal" style="display:none; position:fixed; top:0; left:0; width:100vw; height:100vh; background:rgba(0,0,0,0.25); z-index:200; align-items:center; justify-content:center;">
        <div class="modal-content" style="background:#fff; border-radius:10px; padding:2rem; min-width:320px; max-width:95vw; box-shadow:0 2px 16px rgba(17,17,17,0.15); position:relative;">
            <button onclick="closeProfileModal()" style="position:absolute; top:12px; right:16px; background:none; border:none; font-size:1.5em; color:#888; cursor:pointer;">&times;</button>
            <h2 style="color:#fc5c7d; margin-bottom:1rem;">Mon profil</h2>
            <div style="display:flex; align-items:center; gap:1.2rem; margin-bottom:1.2rem;">
                <span class="user-avatar" style="background:#fc5c7d; color:#fff; border-radius:50%; width:56px; height:56px; display:inline-flex; align-items:center; justify-content:center; font-weight:bold; font-size:2em;">
                    <?= strtoupper(substr($_SESSION['user_name'] ?? '', 0, 1)) ?>
                </span>
                <div>
                    <div style="font-size:1.2em; font-weight:600; color:#222; margin-bottom:2px;"> <?= htmlspecialchars($_SESSION['user_name'] ?? '') ?> </div>
                    <div style="color:#888; font-size:0.98em;"> <?= htmlspecialchars($_SESSION['user_email'] ?? '') ?> </div>
                </div>
            </div>
            <form method="post" action="update_profile.php">
                <label for="profile_name" style="font-weight:500;">Nom complet</label><br>
                <input type="text" id="profile_name" name="profile_name" value="<?= htmlspecialchars($_SESSION['user_name'] ?? '') ?>" class="form-control" style="margin-bottom:12px;" required><br>
                <label for="profile_email" style="font-weight:500;">Email</label><br>
                <input type="email" id="profile_email" name="profile_email" value="<?= htmlspecialchars($_SESSION['user_email'] ?? '') ?>" class="form-control" style="margin-bottom:12px;" required><br>
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
            </form>
        </div>
    </div>
    <!-- Notification Panel -->
    <div id="notificationPanel" class="notification-panel">
        <div class="notification-header">
            <h3 id="notificationTitle">Notifications</h3>
            <button onclick="closeNotificationPanel()" class="close-btn">
                <i class="uil uil-times"></i>
            </button>
        </div>
        <div id="notificationList" class="notification-list"></div>
    </div>
    <style>
    :root {
        --primary: #8B4513;
        --primary-light: #A0522D;
        --secondary: #FFD700;
        --secondary-light: #FFE55C;
        --accent: #DEB887;
        --text-dark: #3E2723;
        --text-light: #ffffff;
        --background-light: #FFF8DC;
        --shadow: 0 2px 8px rgba(139, 69, 19, 0.1);
    }

    .dashboard-title { color: var(--primary); font-size: 2em; margin-bottom: 20px; }
    .btn { display: inline-block; padding: 8px 18px; border-radius: 6px; font-weight: 500; text-decoration: none; transition: all 0.2s; }
    .btn-primary { background: var(--primary); color: var(--text-light); border: none; }
    .btn-primary:hover { background: var(--primary-light); color: var(--text-light); transform: translateY(-2px); }
    .btn-secondary { background: var(--secondary); color: var(--text-dark); border: none; }
    .btn-secondary:hover { background: var(--secondary-light); color: var(--text-dark); transform: translateY(-2px); }
    .btn-link { background: none; color: var(--primary); border: none; text-decoration: underline; padding: 0; }
    .btn-link:hover { color: var(--primary-light); }
    
    .profile-card { 
        display: flex; 
        align-items: center; 
        background: var(--background-light); 
        border-radius: 10px; 
        box-shadow: var(--shadow);
        padding: 1.5rem; 
        margin-bottom: 2rem; 
    }
    .profile-image img { 
        width: 80px; 
        height: 80px; 
        border-radius: 50%; 
        border: 2px solid var(--primary); 
    }
    .profile-info { margin-left: 1.5rem; }
    .profile-info h2 { color: var(--primary); }
    
    .dashboard-settings-panel { display: flex; gap: 1.5rem; margin-bottom: 2rem; }
    .settings-card { 
        background: var(--background-light); 
        border-radius: 8px; 
        box-shadow: var(--shadow);
        padding: 1rem 1.5rem; 
        flex: 1; 
    }
    .settings-header { display: flex; align-items: center; gap: 0.7rem; margin-bottom: 0.5rem; }
    .settings-title { font-weight: 600; color: var(--text-dark); }
    
    .info-card { 
        background: var(--background-light); 
        box-shadow: var(--shadow);
        border-radius: 8px; 
        padding: 16px; 
        margin-bottom: 16px; 
    }
    .info-card h3 { color: var(--primary); }
    
    .navbar-dashboard { 
        display: flex; 
        justify-content: space-between; 
        align-items: center; 
        background: var(--background-light); 
        box-shadow: var(--shadow);
        padding: 0.7rem 2rem; 
        margin-bottom: 2rem; 
    }
    .navbar-title { 
        font-size: 1.3em; 
        font-weight: 700; 
        color: var(--primary); 
        letter-spacing: 1px; 
    }
    
    .user-profile-menu { display: flex; align-items: center; }
    .user-avatar { 
        background: var(--primary) !important; 
        box-shadow: var(--shadow);
    }
    .user-name { 
        font-size: 1.1em; 
        color: var(--text-dark); 
    }
    
    .dropdown-content { 
        background: var(--background-light) !important; 
        min-width: 180px; 
    }
    .dropdown-item { 
        display: block; 
        padding: 10px 18px; 
        color: var(--text-dark); 
        text-decoration: none; 
        border-bottom: 1px solid rgba(139, 69, 19, 0.1); 
        transition: background 0.2s; 
    }
    .dropdown-item:hover { 
        background: var(--accent); 
        color: var(--text-dark); 
    }
    
    .notification-icons {
        display: flex;
        gap: 20px;
        margin-right: 20px;
    }
    .notification-icon-wrapper {
        position: relative;
    }
    .notification-icon {
        color: var(--text-dark);
        font-size: 1.5rem;
        cursor: pointer;
        transition: color 0.2s;
    }
    .notification-icon:hover {
        color: var(--primary);
    }
    .notification-badge {
        position: absolute;
        top: -8px;
        right: -8px;
        background: var(--primary);
        color: var(--text-light);
        border-radius: 50%;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 12px;
        font-weight: bold;
        border: 2px solid var(--text-light);
        box-shadow: var(--shadow);
    }
    
    .notification-panel {
        position: fixed;
        top: 60px;
        right: 20px;
        background: var(--background-light);
        border-radius: 12px;
        box-shadow: 0 4px 12px rgba(139, 69, 19, 0.15);
        width: 320px;
        max-height: 480px;
        overflow-y: auto;
        z-index: 1000;
        border: 1px solid rgba(139, 69, 19, 0.1);
        display: none;
    }
    .notification-panel.show {
        display: block;
        animation: slideIn 0.3s ease-out;
    }
    .notification-header {
        padding: 15px;
        border-bottom: 1px solid rgba(139, 69, 19, 0.1);
        display: flex;
        justify-content: space-between;
        align-items: center;
        background: var(--primary);
        color: var(--text-light);
        border-radius: 12px 12px 0 0;
    }
    .notification-title {
        font-weight: 600;
        color: var(--text-light);
    }
    .close-btn {
        color: var(--text-light);
        background: none;
        border: none;
        font-size: 1.2em;
        cursor: pointer;
        padding: 0;
        margin: 0;
    }
    .close-btn:hover {
        opacity: 0.8;
    }
    .notification-list {
        padding: 0;
        margin: 0;
        list-style: none;
    }
    .notification-item {
        padding: 12px 15px;
        border-bottom: 1px solid rgba(139, 69, 19, 0.1);
        cursor: pointer;
        transition: background 0.2s;
        background: var(--background-light);
    }
    .notification-item:hover {
        background: var(--accent);
    }
    .notification-item.unread {
        background: rgba(139, 69, 19, 0.05);
    }
    
    .modal-content {
        background: var(--background-light) !important;
    }
    .modal-content h2 {
        color: var(--primary) !important;
    }
    .modal-content input.form-control {
        border: 1px solid var(--primary-light);
        border-radius: 4px;
        padding: 8px 12px;
    }
    .modal-content input.form-control:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 2px rgba(139, 69, 19, 0.1);
    }
    
    .card {
        background: var(--background-light);
        border-radius: 10px;
        box-shadow: var(--shadow);
        padding: 1.5rem;
        margin-bottom: 1.5rem;
    }
    .card-title {
        color: var(--primary);
        margin-bottom: 1rem;
    }
    .card-text {
        color: var(--text-dark);
        margin-bottom: 1rem;
    }
    
    @keyframes slideIn {
        from {
            opacity: 0;
            transform: translateY(-10px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }
    </style>
</body>
<script src="../js/dayjs.min.js"></script>
<script src="../js/datetime.js"></script>
<script>
function updateDashboardDateTime() {
    var el = document.getElementById('dashboardDateTime');
    if (el && window.dayjs) {
        el.textContent = dayjs().format('dddd, MMMM D, YYYY - HH:mm:ss');
    }
}
setInterval(updateDashboardDateTime, 1000);
document.addEventListener('DOMContentLoaded', updateDashboardDateTime);

function updateDashboardWeather() {
    var weatherIcon = document.getElementById('weatherIcon');
    var weatherDesc = document.getElementById('weatherDesc');
    var lat = 3.848;
    var lon = 11.5021;
    fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current_weather=true&timezone=auto`)
        .then(res => res.json())
        .then(data => {
            if (data.current_weather) {
                var temp = data.current_weather.temperature;
                var code = data.current_weather.weathercode;
                var icon = '☀️';
                var desc = 'Ensoleillé';
                if (code >= 45 && code <= 48) { icon = '🌫️'; desc = 'Brouillard'; }
                else if (code >= 51 && code <= 67) { icon = '🌦️'; desc = 'Bruine'; }
                else if (code >= 71 && code <= 77) { icon = '❄️'; desc = 'Neige'; }
                else if (code >= 80 && code <= 82) { icon = '🌧️'; desc = 'Averses'; }
                else if (code >= 95) { icon = '⛈️'; desc = 'Orage'; }
                else if (code >= 61 && code <= 65) { icon = '🌧️'; desc = 'Pluie'; }
                else if (code === 0) { icon = '☀️'; desc = 'Ciel clair'; }
                else if (code >= 1 && code <= 3) { icon = '⛅'; desc = 'Partiellement nuageux'; }
                weatherIcon.textContent = icon;
                weatherDesc.textContent = `${desc} • ${temp}°C`;
            } else {
                weatherIcon.textContent = '❓';
                weatherDesc.textContent = 'Indisponible';
            }
        })
        .catch(() => {
            weatherIcon.textContent = '❓';
            weatherDesc.textContent = 'Indisponible';
        });
}
document.addEventListener('DOMContentLoaded', updateDashboardWeather);

function toggleProfileDropdown() {
    var el = document.getElementById('profileDropdown');
    if (el) el.style.display = (el.style.display === 'block') ? 'none' : 'block';
}
document.addEventListener('click', function(e) {
    if (!e.target.closest('.user-profile-menu')) {
        var el = document.getElementById('profileDropdown');
        if (el) el.style.display = 'none';
    }
});
function showProfileModal() {
    document.getElementById('profileModal').style.display = 'flex';
    document.getElementById('profileDropdown').style.display = 'none';
}
function closeProfileModal() {
    document.getElementById('profileModal').style.display = 'none';
}

let currentNotificationType = null;

function toggleNotificationPanel(type) {
    const panel = document.getElementById('notificationPanel');
    if (currentNotificationType === type && panel.classList.contains('show')) {
        closeNotificationPanel();
    } else {
        currentNotificationType = type;
        loadNotifications(type);
        panel.classList.add('show');
    }
}

function closeNotificationPanel() {
    document.getElementById('notificationPanel').classList.remove('show');
    currentNotificationType = null;
}

function loadNotifications(type) {
    const titles = {
        email: 'Emails',
        news: 'Actualités',
        message: 'Messages'
    };
    document.getElementById('notificationTitle').textContent = titles[type];
    
    fetch(`get_notifications.php?type=${type}`)
        .then(response => response.json())
        .then(data => {
            updateNotificationList(data);
            updateBadges();
        })
        .catch(error => {
            console.error('Error loading notifications:', error);
        });
}

function updateNotificationList(notifications) {
    const list = document.getElementById('notificationList');
    list.innerHTML = '';
    
    if (notifications.length === 0) {
        list.innerHTML = '<div class="notification-item">Aucune notification</div>';
        return;
    }
    
    notifications.forEach(notif => {
        const item = document.createElement('div');
        item.className = `notification-item ${notif.is_read ? '' : 'unread'}`;
        item.onclick = () => openNotification(notif);
        
        item.innerHTML = `
            <div class="notification-content">
                <div class="notification-title">${notif.subject}</div>
                <div class="notification-message">${notif.content}</div>
                <div class="notification-time">${formatDate(notif.created_at)}</div>
            </div>
        `;
        
        list.appendChild(item);
    });
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: 'short',
        hour: '2-digit',
        minute: '2-digit'
    });
}

function openNotification(notif) {
    switch (notif.type) {
        case 'email':
            window.location.href = `view_email.php?id=${notif.id}`;
            break;
        case 'news':
            window.location.href = `view_news.php?id=${notif.id}`;
            break;
        case 'message':
            window.location.href = `view_message.php?id=${notif.id}`;
            break;
    }
}

function updateBadges() {
    fetch('get_unread_counts.php')
        .then(response => response.json())
        .then(data => {
            updateBadge('emailBadge', data.emails);
            updateBadge('newsBadge', data.news);
            updateBadge('messageBadge', data.messages);
        })
        .catch(error => {
            console.error('Error updating badges:', error);
        });
}

function updateBadge(id, count) {
    const badge = document.getElementById(id);
    if (badge) {
        badge.textContent = count;
        badge.style.display = count > 0 ? 'flex' : 'none';
    }
}

// Update badges every minute
updateBadges();
setInterval(updateBadges, 60000);

// Close notification panel when clicking outside
document.addEventListener('click', function(event) {
    const panel = document.getElementById('notificationPanel');
    const icons = document.querySelector('.notification-icons');
    if (!panel.contains(event.target) && !icons.contains(event.target) && panel.classList.contains('show')) {
        closeNotificationPanel();
    }
});
</script>
</html>