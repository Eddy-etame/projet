<?php
require_once '../includes/db.php';
require_once '../includes/middleware.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Accès non autorisé']);
    exit;
}

$user_id = $_SESSION['user_id'];
$recipient_id = isset($_POST['recipient_id']) ? (int)$_POST['recipient_id'] : 0;
$subject = isset($_POST['subject']) ? trim($_POST['subject']) : '';
$content = isset($_POST['content']) ? trim($_POST['content']) : '';
$parent_id = isset($_POST['parent_id']) ? (int)$_POST['parent_id'] : null;
$type = isset($_POST['type']) ? $_POST['type'] : 'message';

try {
    // Validate inputs
    if ($recipient_id <= 0 || empty($subject) || empty($content)) {
        throw new Exception('Tous les champs sont obligatoires');
    }

    // Start transaction
    $conn->begin_transaction();

    if ($type === 'message') {
        // Insert into Messages table
        $query = "INSERT INTO Messages (sender_id, recipient_id, subject, content, parent_message_id) 
                 VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('iissi', $user_id, $recipient_id, $subject, $content, $parent_id);
    } else {
        // Insert into Notifications table
        $query = "INSERT INTO Notifications (type, sender_id, recipient_id, subject, content) 
                 VALUES (?, ?, ?, ?, ?)";
        $stmt = $conn->prepare($query);
        $stmt->bind_param('siiss', $type, $user_id, $recipient_id, $subject, $content);
    }

    $stmt->execute();
    
    if ($stmt->affected_rows > 0) {
        $conn->commit();
        echo json_encode([
            'success' => true,
            'message' => 'Message envoyé avec succès',
            'id' => $stmt->insert_id
        ]);
    } else {
        throw new Exception('Erreur lors de l\'envoi du message');
    }
} catch (Exception $e) {
    if (isset($conn)) {
        $conn->rollback();
    }
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 