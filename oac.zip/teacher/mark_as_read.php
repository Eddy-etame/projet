<?php
require_once '../includes/db.php';
require_once '../includes/middleware.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['error' => 'Accès non autorisé']);
    exit;
}

$user_id = $_SESSION['user_id'];
$type = isset($_POST['type']) ? $_POST['type'] : '';
$id = isset($_POST['id']) ? (int)$_POST['id'] : 0;

try {
    $query = '';
    switch ($type) {
        case 'notification':
            $query = "UPDATE Notifications 
                     SET is_read = TRUE 
                     WHERE id_notification = ? AND recipient_id = ?";
            break;
            
        case 'message':
            $query = "UPDATE Messages 
                     SET is_read = TRUE 
                     WHERE id_message = ? AND recipient_id = ?";
            break;
            
        case 'all':
            // Mark all notifications of a specific type as read
            $notif_type = isset($_POST['notification_type']) ? $_POST['notification_type'] : '';
            if (!empty($notif_type)) {
                $query = "UPDATE Notifications 
                         SET is_read = TRUE 
                         WHERE recipient_id = ? AND type = ?";
                $stmt = $conn->prepare($query);
                $stmt->bind_param('is', $user_id, $notif_type);
                $stmt->execute();
                echo json_encode(['success' => true]);
                exit;
            }
            break;
            
        default:
            throw new Exception('Type invalide');
    }

    if ($query && $id > 0) {
        $stmt = $conn->prepare($query);
        $stmt->bind_param('ii', $id, $user_id);
        $stmt->execute();
        
        if ($stmt->affected_rows > 0) {
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['error' => 'Notification non trouvée ou déjà lue']);
        }
    } else {
        echo json_encode(['error' => 'Paramètres invalides']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 