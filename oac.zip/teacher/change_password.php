<?php
// teacher/change_password.php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once '../auth/db.php';

$error = '';
$success = '';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] != 2) {
    header('Location: ../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';
    if (strlen($new_password) < 6) {
        $error = 'Le mot de passe doit contenir au moins 6 caractères.';
    } elseif ($new_password !== $confirm_password) {
        $error = 'Les mots de passe ne correspondent pas.';
    } else {
        $hashed = password_hash($new_password, PASSWORD_BCRYPT);
        $stmt = $conn->prepare('UPDATE Utilisateurs SET mot_de_passe = ?, must_change_password = 0 WHERE id_utilisateur = ?');
        $stmt->bind_param('si', $hashed, $_SESSION['user_id']);
        if ($stmt->execute()) {
            $success = 'Mot de passe changé avec succès. Vous pouvez accéder à votre tableau de bord.';
        } else {
            $error = 'Erreur lors du changement de mot de passe.';
        }
        $stmt->close();
    }
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Changer le mot de passe</title>
    <link rel="stylesheet" href="../css/teacher-dashboard.css">
    <style>
    body { background: #181a1b; color: #f1f1f1; }
    .teacher-dashboard { background: #23272b; color: #f1f1f1; min-height: 100vh; padding: 2rem; }
    .dashboard-title { color: #FFD966; font-size: 2em; margin-bottom: 20px; }
    .btn { display: inline-block; padding: 8px 18px; border-radius: 6px; font-weight: 500; text-decoration: none; transition: background 0.2s; }
    .btn-primary { background: #FFD966; color: #181a1b; border: none; }
    .btn-primary:hover { background: #fc5c7d; color: #fff; }
    .btn-link { background: none; color: #FFD966; border: none; text-decoration: underline; padding: 0; }
    .btn-link:hover { color: #fc5c7d; }
    .alert-danger { background: #2d1a1a; color: #ff7875; border: 1px solid #ff7875; border-radius: 6px; padding: 12px 18px; margin-bottom: 12px; }
    .alert-success { background: #1a2d1a; color: #b7eb8f; border: 1px solid #b7eb8f; border-radius: 6px; padding: 12px 18px; margin-bottom: 12px; }
    .card { background: #23272b; border-radius: 10px; box-shadow: 0 2px 8px rgba(17,17,17,0.25); padding: 1.5rem; margin-bottom: 2rem; }
    input[type="password"] { background: #181a1b; color: #f1f1f1; border: 1px solid #444; border-radius: 6px; padding: 10px; margin-bottom: 10px; width: 100%; }
    input[type="password"]:focus { border-color: #FFD966; outline: none; }
    </style>
</head>
<body>
<div class="teacher-dashboard">
    <h2 class="dashboard-title">Changer le mot de passe</h2>
    <?php if ($error): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
    <?php elseif ($success): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
        <a href="TDashboard.php" class="btn-link">Aller au tableau de bord</a>
    <?php else: ?>
    <form method="post" class="card">
        <input type="password" name="new_password" placeholder="Nouveau mot de passe" required style="margin-bottom:10px;">
        <input type="password" name="confirm_password" placeholder="Confirmer le mot de passe" required style="margin-bottom:10px;">
        <button type="submit" class="btn btn-primary">Changer le mot de passe</button>
    </form>
    <?php endif; ?>
</div>
</body>
</html>
