<?php
require_once '../auth/middleware.php';
require_once '../auth/db.php';

AuthMiddleware::requireRole('teacher');

$teacher_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';

// ... existing code ... 