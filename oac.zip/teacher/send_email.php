<?php
session_start();
require_once '../auth/middleware.php';

// Ensure user is logged in as a teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 2) {
    header('Location: ../index.php');
    exit();
}

$servername = "localhost";
$username = "Eddy";
$password = "Daddiesammy1$";
$bd = "keyce";

$conn = new mysqli($servername, $username, $password, $bd);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = '';
$error = '';

// Handle email sending
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $recipient_ids = isset($_POST['recipients']) ? $_POST['recipients'] : [];
    $subject = trim($_POST['subject']);
    $email_content = trim($_POST['message']);
    
    if (empty($recipient_ids)) {
        $error = "Please select at least one recipient";
    } elseif (empty($subject)) {
        $error = "Subject is required";
    } elseif (empty($email_content)) {
        $error = "Message content is required";
    } else {
        // Start transaction
        $conn->begin_transaction();
        
        try {
            // Handle file upload if present
            $attachment_path = null;
            if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
                $upload_dir = '../uploads/';
                if (!file_exists($upload_dir)) {
                    mkdir($upload_dir, 0777, true);
                }
                
                $file_name = time() . '_' . basename($_FILES['attachment']['name']);
                $target_path = $upload_dir . $file_name;
                
                if (move_uploaded_file($_FILES['attachment']['tmp_name'], $target_path)) {
                    $attachment_path = $target_path;
                }
            }
            
            // Prepare the insert statement once
            $stmt = $conn->prepare("
                INSERT INTO emails (sender_id, recipient_id, subject, message, attachment_path) 
                VALUES (?, ?, ?, ?, ?)
            ");
            
            if (!$stmt) {
                throw new Exception("Failed to prepare statement: " . $conn->error);
            }
            
            $stmt->bind_param("iisss", $_SESSION['user_id'], $recipient_id, $subject, $email_content, $attachment_path);
            
            // Send email to each recipient
            $success_count = 0;
            foreach ($recipient_ids as $recipient_id) {
                if ($stmt->execute()) {
                    $success_count++;
                } else {
                    throw new Exception("Failed to send email to recipient ID $recipient_id: " . $stmt->error);
                }
            }
            
            $stmt->close();
            
            // If we got here, commit the transaction
            $conn->commit();
            $message = "Email sent successfully to $success_count recipient(s)";
            
        } catch (Exception $e) {
            // An error occurred, rollback the transaction
            $conn->rollback();
            $error = "Error: " . $e->getMessage();
            
            // Delete uploaded file if it exists
            if ($attachment_path && file_exists($attachment_path)) {
                unlink($attachment_path);
            }
        }
    }
}

// Get list of students with proper error handling
try {
    $students_query = "
        SELECT U.id_utilisateur, U.nom, U.prenom, U.email 
        FROM Utilisateurs U 
        INNER JOIN Etudiants E ON U.id_utilisateur = E.id_utilisateur 
        WHERE U.id_role = 3
        ORDER BY U.nom, U.prenom
    ";
    
    if (!($students = $conn->query($students_query))) {
        throw new Exception("Failed to fetch students: " . $conn->error);
    }
    
} catch (Exception $e) {
    $error = "System Error: " . $e->getMessage();
    $students = false;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Email - Teacher Dashboard</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css">
    <style>
        .container { margin-top: 30px; }
        .select2-container { width: 100% !important; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Send Email to Students</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($message): ?>
            <div class="alert alert-success"><?php echo htmlspecialchars($message); ?></div>
        <?php endif; ?>
        
        <?php if ($students): ?>
        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="recipients">Recipients</label>
                <select name="recipients[]" id="recipients" class="form-control" multiple required>
                    <?php while ($student = $students->fetch_assoc()): ?>
                        <option value="<?php echo htmlspecialchars($student['id_utilisateur']); ?>">
                            <?php echo htmlspecialchars($student['nom'] . ' ' . $student['prenom'] . ' (' . $student['email'] . ')'); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label for="subject">Subject</label>
                <input type="text" name="subject" id="subject" class="form-control" required>
            </div>
            
            <div class="form-group">
                <label for="message">Message</label>
                <textarea name="message" id="message" class="form-control" rows="6" required></textarea>
            </div>
            
            <div class="form-group">
                <label for="attachment">Attachment (optional)</label>
                <input type="file" name="attachment" id="attachment" class="form-control-file">
            </div>
            
            <div class="form-group">
                <button type="submit" class="btn btn-primary">Send Email</button>
                <a href="TDashboard.php" class="btn btn-secondary">Back to Dashboard</a>
            </div>
        </form>
        <?php endif; ?>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#recipients').select2({
                placeholder: 'Select students',
                allowClear: true
            });
        });
    </script>
</body>
</html>
<?php
$conn->close();
?> 