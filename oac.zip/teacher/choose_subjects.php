<?php
require_once '../auth/middleware.php';
AuthMiddleware::requireRole('teacher');

// Example: fetch all subjects
require_once '../auth/Login.php';
$teacher_id = $_SESSION['user_id'];
$subjects = $conn->query("SELECT id_matiere, nom_matiere FROM Matieres");

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['subjects'])) {
    // Save chosen subjects for this teacher (simple version: clear and insert)
    $conn->query("DELETE FROM Enseignant_Matieres WHERE id_enseignant = $teacher_id");
    foreach ($_POST['subjects'] as $id_matiere) {
        $stmt = $conn->prepare("INSERT INTO Enseignant_Matieres (id_enseignant, id_matiere) VALUES (?, ?)");
        $stmt->bind_param("ii", $teacher_id, $id_matiere);
        $stmt->execute();
        $stmt->close();
    }
    $success = true;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Choisir ses matières</title>
    <link rel="stylesheet" href="../css/teacher-dashboard.css">
    <style>
    .dashboard-title { color: #fc5c7d; font-size: 2em; margin-bottom: 20px; }
    .btn { display: inline-block; padding: 8px 18px; border-radius: 6px; font-weight: 500; text-decoration: none; transition: background 0.2s; }
    .btn-primary { background: #fc5c7d; color: #fff; border: none; }
    .btn-primary:hover { background: #6a82fb; color: #fff; }
    .btn-secondary { background: #FFD966; color: #222; border: none; }
    .btn-secondary:hover { background: #ffe58f; color: #222; }
    .btn-link { background: none; color: #6a82fb; border: none; text-decoration: underline; padding: 0; }
    .btn-link:hover { color: #fc5c7d; }
    .card { background: #fff; border-radius: 10px; box-shadow: 0 2px 8px rgba(17,17,17,0.07); padding: 1.5rem; margin-bottom: 2rem; }
    .alert-success { background: #e3fcec; color: #1a7f37; border: 1px solid #b7eb8f; border-radius: 6px; padding: 12px 18px; margin-bottom: 12px; }
    </style>
</head>
<body>
<div class="teacher-dashboard">
    <h2 class="dashboard-title">Choisir vos matières</h2>
    <?php if (!empty($success)): ?>
        <div class="alert alert-success">Matières enregistrées !</div>
    <?php endif; ?>
    <form method="post" class="card">
        <?php while ($row = $subjects->fetch_assoc()): ?>
            <div style="margin-bottom:8px;"><label><input type="checkbox" name="subjects[]" value="<?= $row['id_matiere'] ?>"> <?= htmlspecialchars($row['nom_matiere']) ?></label></div>
        <?php endwhile; ?>
        <button type="submit" class="btn btn-primary" style="margin-top:12px;">Enregistrer</button>
    </form>
    <a href="TDashboard.php" class="btn btn-link">Retour au tableau de bord</a>
</div>
</body>
</html>
