<?php
require_once 'auth/middleware.php';
require_once 'config/database.php';

AuthMiddleware::requireRole('teacher');

$teacher_id = $_SESSION['user_id'];
$success_message = '';
$error_message = '';
$grade = null;

if (isset($_GET['id'])) {
    $grade_id = intval($_GET['id']);
    
    // Get grade details
    $sql = "SELECT n.*, u.prenom, u.nom, m.nom_matiere 
            FROM Notes n
            JOIN Utilisateurs u ON n.id_etudiant = u.id_utilisateur
            JOIN Matieres m ON n.id_matiere = m.id_matiere
            WHERE n.id_note = ? AND n.id_enseignant_saisie = ?";
            
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $grade_id, $teacher_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 1) {
        $grade = $result->fetch_assoc();
    } else {
        header('Location: manage-grades.php');
        exit();
    }
}

// Handle grade update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_grade'])) {
    $grade_id = intval($_POST['grade_id']);
    $new_note = floatval($_POST['note']);
    
    if ($new_note >= 0 && $new_note <= 20) {
        $sql = "UPDATE Notes SET valeur_note = ?, date_modification = NOW() 
                WHERE id_note = ? AND id_enseignant_saisie = ?";
        
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("dii", $new_note, $grade_id, $teacher_id);
        
        if ($stmt->execute()) {
            $success_message = "Note mise à jour avec succès";
            // Refresh grade data
            header("Location: edit-grade.php?id=" . $grade_id . "&success=1");
            exit();
        } else {
            $error_message = "Erreur lors de la mise à jour de la note";
        }
    } else {
        $error_message = "La note doit être comprise entre 0 et 20";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Modifier une Note</title>
    <link rel="stylesheet" href="../css/teacher-dashboard.css">
    <style>
    .dashboard-title { color: #fc5c7d; font-size: 2em; margin-bottom: 20px; }
    .btn { display: inline-block; padding: 8px 18px; border-radius: 6px; font-weight: 500; text-decoration: none; transition: background 0.2s; }
    .btn-primary { background: #fc5c7d; color: #fff; border: none; }
    .btn-primary:hover { background: #6a82fb; color: #fff; }
    .btn-link { background: none; color: #6a82fb; border: none; text-decoration: underline; padding: 0; }
    .btn-link:hover { color: #fc5c7d; }
    .alert-danger { background: #fff1f0; color: #cf1322; border: 1px solid #ffa39e; border-radius: 6px; padding: 12px 18px; margin-bottom: 12px; }
    .alert-success { background: #e3fcec; color: #1a7f37; border: 1px solid #b7eb8f; border-radius: 6px; padding: 12px 18px; margin-bottom: 12px; }
    .card { background: #fff; border-radius: 10px; box-shadow: 0 2px 8px rgba(17,17,17,0.07); padding: 1.5rem; margin-bottom: 2rem; }
    </style>
</head>
<body>
<div class="teacher-dashboard">
    <h2 class="dashboard-title">Modifier une Note</h2>
    <?php if ($success_message): ?>
        <div class="alert alert-success"><?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>
    <?php if ($error_message): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>
    <form method="post" class="card">
        <input type="hidden" name="grade_id" value="<?= htmlspecialchars($grade['id_note'] ?? '') ?>">
        <div style="margin-bottom:10px;"><strong>Étudiant:</strong> <?= htmlspecialchars($grade['prenom'] ?? '') ?> <?= htmlspecialchars($grade['nom'] ?? '') ?></div>
        <div style="margin-bottom:10px;"><strong>Matière:</strong> <?= htmlspecialchars($grade['nom_matiere'] ?? '') ?></div>
        <div style="margin-bottom:10px;"><strong>Note actuelle:</strong> <?= htmlspecialchars($grade['valeur_note'] ?? '') ?>/20</div>
        <input type="number" name="note" min="0" max="20" step="0.25" value="<?= htmlspecialchars($grade['valeur_note'] ?? '') ?>" required style="margin-bottom:10px;">
        <button type="submit" name="update_grade" class="btn btn-primary">Mettre à jour</button>
    </form>
    <a href="manage_notes" class="btn-link">Retour à la gestion des notes</a>
</div>
</body>
</html>