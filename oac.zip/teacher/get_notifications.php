<?php
require_once '../includes/db.php';
require_once '../includes/middleware.php';

// Ensure user is logged in and is a teacher
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'teacher') {
    http_response_code(403);
    echo json_encode(['error' => 'Accès non autorisé']);
    exit;
}

$type = isset($_GET['type']) ? $_GET['type'] : '';
$user_id = $_SESSION['user_id'];

try {
    $query = '';
    switch ($type) {
        case 'email':
            $query = "SELECT n.*, u.nom as sender_name 
                     FROM Notifications n 
                     JOIN Utilisateurs u ON n.sender_id = u.id_utilisateur 
                     WHERE n.type = 'email' AND n.recipient_id = ? 
                     ORDER BY n.created_at DESC 
                     LIMIT 20";
            break;
            
        case 'news':
            $query = "SELECT n.*, u.nom as author_name 
                     FROM News n 
                     JOIN Utilisateurs u ON n.author_id = u.id_utilisateur 
                     ORDER BY n.created_at DESC 
                     LIMIT 10";
            break;
            
        case 'message':
            $query = "SELECT m.*, u.nom as sender_name 
                     FROM Messages m 
                     JOIN Utilisateurs u ON m.sender_id = u.id_utilisateur 
                     WHERE m.recipient_id = ? 
                     ORDER BY m.created_at DESC 
                     LIMIT 20";
            break;
            
        default:
            throw new Exception('Type de notification invalide');
    }

    $stmt = $conn->prepare($query);
    
    if ($type !== 'news') {
        $stmt->bind_param('i', $user_id);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    $notifications = $result->fetch_all(MYSQLI_ASSOC);

    echo json_encode($notifications);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
?> 