<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
session_regenerate_id(true);

require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../shared/error_logger.php';

// Check if user is logged in and is a student
$auth = AuthMiddleware::getInstance();
$auth->requireRole(3); // 3 is the id for student role

// Get student data
$student_id = $_SESSION['user_id'];

try {
    // Get database connection
    $conn = getDBConnection();
    
    // Check if must_change_password is set for this student
    $stmt = $conn->prepare('SELECT must_change_password FROM Utilisateurs WHERE id_utilisateur = ?');
    $stmt->bind_param('i', $student_id);
    $stmt->execute();
    $stmt->bind_result($must_change_password);
    $stmt->fetch();
    $stmt->close();

    if ($must_change_password) {
        header('Location: change_password.php');
        exit();
    }

    // Get student's latest grades
    $sql = "SELECT n.*, m.nom_matiere, u.nom as prof_nom, u.prenom as prof_prenom,
            (SELECT AVG(valeur_note) 
             FROM Notes n2 
             WHERE n2.id_matiere = n.id_matiere 
             AND n2.type_evaluation = n.type_evaluation
             AND n2.est_publie = 1) as class_average
            FROM Notes n
            JOIN Matieres m ON n.id_matiere = m.id_matiere
            JOIN Utilisateurs u ON n.id_enseignant_saisie = u.id_utilisateur
            WHERE n.id_etudiant = ? AND n.est_publie = 1
            ORDER BY n.date_saisie DESC
            LIMIT 5";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $student_id);
    $stmt->execute();
    $latest_grades = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Get unread notifications
    $sql = "SELECT n.*, u.nom as sender_name, u.prenom as sender_prenom, m.nom_matiere
            FROM Notifications n
            LEFT JOIN Utilisateurs u ON n.sender_id = u.id_utilisateur
            LEFT JOIN Matieres m ON n.id_matiere = m.id_matiere
            WHERE (n.recipient_id = ? OR (n.role_target = 'student' AND n.recipient_id IS NULL))
            AND n.is_read = 0
            ORDER BY n.date_sent DESC";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $student_id);
    $stmt->execute();
    $notifications = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Get student's overall performance
    $sql = "SELECT 
                AVG(n.valeur_note) as overall_average,
                COUNT(DISTINCT n.id_matiere) as total_subjects,
                (SELECT COUNT(*) 
                 FROM Notes n2 
                 WHERE n2.id_etudiant = ? 
                 AND n2.valeur_note >= 10 
                 AND n2.est_publie = 1) as passed_subjects
            FROM Notes n
            WHERE n.id_etudiant = ? AND n.est_publie = 1";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ii', $student_id, $student_id);
    $stmt->execute();
    $performance = $stmt->get_result()->fetch_assoc();

    // Calculate completion percentage
    $completion_percentage = $performance['total_subjects'] > 0 
        ? ($performance['passed_subjects'] / $performance['total_subjects']) * 100 
        : 0;

} catch (Exception $e) {
    error_log("Database error: " . $e->getMessage());
    // Handle error gracefully
    echo "Une erreur s'est produite. Veuillez réessayer plus tard.";
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard</title>
    <link rel="stylesheet" href="../css/student-dashboard.css">
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <nav class="navbar navbar-dashboard">
        <div class="navbar-left">
            <span class="navbar-title">Portail Étudiant</span>
        </div>
        <div class="navbar-right">
            <div class="user-profile-menu">
                <span class="user-avatar" style="background:#fc5c7d; color:#fff; border-radius:50%; width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center; font-weight:bold; font-size:1.1em; margin-right:8px;">
                    <?= strtoupper(substr($_SESSION['user_name'] ?? '', 0, 1)) ?>
                </span>
                <span class="user-name" style="font-weight:600; color:#222; margin-right:12px;">
                    <?= htmlspecialchars($_SESSION['user_name'] ?? '') ?>
                </span>
                <div class="dropdown" style="display:inline-block; position:relative;">
                    <button class="btn btn-link" onclick="toggleProfileDropdown()" style="padding:0; font-size:1.2em;">&#x25BC;</button>
                    <div id="profileDropdown" class="dropdown-content" style="display:none; position:absolute; right:0; background:#fff; box-shadow:0 2px 8px rgba(17,17,17,0.07); border-radius:8px; min-width:180px; z-index:100;">
                        <a href="SDashboard.php" class="dropdown-item">Tableau de bord</a>
                        <a href="#" class="dropdown-item" onclick="showProfileModal();return false;">Mon profil</a>
                        <a href="change_password.php" class="dropdown-item">Changer le mot de passe</a>
                        <a href="../logout.php" class="dropdown-item" style="color:#fc5c7d;">Se déconnecter</a>
                    </div>
                </div>
            </div>
            <div class="notification-icons">
                <div class="notification-icon-wrapper">
                    <a href="#" onclick="toggleNotificationPanel('notification'); return false;" class="notification-icon">
                        <i class="uil uil-bell"></i>
                        <span id="notificationBadge" class="notification-badge" style="display: <?= count($notifications) > 0 ? 'block' : 'none' ?>;">
                            <?= count($notifications) ?>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </nav>
    <div class="student-dashboard">
        <!-- Welcome Section -->
        <div class="welcome-section card">
            <div class="welcome-content">
                <h1>Bienvenue, <?= htmlspecialchars($_SESSION['user_name'] ?? 'Student') ?></h1>
                <p class="subtitle">Voici un aperçu de votre progression académique</p>
            </div>
            <div class="quick-stats">
                <div class="stat-card">
                    <div class="stat-icon"><i class="uil uil-graduation-cap"></i></div>
                    <div class="stat-info">
                        <h3>Moyenne Générale</h3>
                        <p><?= number_format($performance['overall_average'], 2) ?>/20</p>
                    </div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="uil uil-chart-line"></i></div>
                    <div class="stat-info">
                        <h3>Progression</h3>
                        <p><?= number_format($completion_percentage, 1) ?>%</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Latest Grades -->
        <div class="latest-grades card">
            <h2>Dernières Notes</h2>
            <div class="grades-list">
                <?php if (!empty($latest_grades)): ?>
                    <?php foreach ($latest_grades as $grade): ?>
                        <div class="grade-item">
                            <div class="grade-subject">
                                <h3><?= htmlspecialchars($grade['nom_matiere']) ?></h3>
                                <p class="grade-type"><?= htmlspecialchars($grade['type_evaluation']) ?></p>
                            </div>
                            <div class="grade-details">
                                <div class="grade-value <?= $grade['valeur_note'] >= 10 ? 'passing' : 'failing' ?>">
                                    <?= number_format($grade['valeur_note'], 2) ?>/20
                                </div>
                                <div class="grade-comparison">
                                    <small>Moyenne de la classe: <?= number_format($grade['class_average'], 2) ?></small>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-grades">Aucune note récente à afficher</p>
                <?php endif; ?>
            </div>
            <a href="view_grades.php" class="btn btn-primary">Voir toutes les notes</a>
        </div>

        <!-- Notifications Panel -->
        <div id="notificationPanel" class="notification-panel" style="display: none;">
            <div class="notification-header">
                <h3>Notifications</h3>
                <button onclick="closeNotificationPanel()" class="close-btn">
                    <i class="uil uil-times"></i>
                </button>
            </div>
            <div class="notification-list">
                <?php if (!empty($notifications)): ?>
                    <?php foreach ($notifications as $notif): ?>
                        <div class="notification-item" data-id="<?= $notif['id_notification'] ?>">
                            <div class="notification-icon">
                                <i class="uil <?= $notif['id_matiere'] ? 'uil-book-alt' : 'uil-bell' ?>"></i>
                            </div>
                            <div class="notification-content">
                                <h4><?= htmlspecialchars($notif['title']) ?></h4>
                                <p><?= htmlspecialchars($notif['message']) ?></p>
                                <small>
                                    <?php if ($notif['id_matiere']): ?>
                                        <?= htmlspecialchars($notif['nom_matiere']) ?> -
                                    <?php endif; ?>
                                    <?= htmlspecialchars($notif['sender_prenom'] . ' ' . $notif['sender_name']) ?> -
                                    <?= date('d/m/Y H:i', strtotime($notif['date_sent'])) ?>
                                </small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p class="no-notifications">Aucune notification non lue</p>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <style>
    .card {
        background: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }

    .welcome-section {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 30px;
        background: linear-gradient(135deg, #6a11cb 0%, #2575fc 100%);
        color: white;
    }

    .welcome-content h1 {
        font-size: 2em;
        margin: 0;
    }

    .subtitle {
        opacity: 0.9;
        margin-top: 5px;
    }

    .quick-stats {
        display: flex;
        gap: 20px;
    }

    .stat-card {
        background: rgba(255,255,255,0.1);
        padding: 15px;
        border-radius: 8px;
        display: flex;
        align-items: center;
        gap: 15px;
    }

    .stat-icon {
        font-size: 2em;
    }

    .stat-info h3 {
        font-size: 0.9em;
        margin: 0;
        opacity: 0.9;
    }

    .stat-info p {
        font-size: 1.2em;
        font-weight: bold;
        margin: 5px 0 0;
    }

    .latest-grades {
        margin-top: 30px;
    }

    .grades-list {
        margin: 20px 0;
    }

    .grade-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 15px;
        border-bottom: 1px solid #eee;
    }

    .grade-item:last-child {
        border-bottom: none;
    }

    .grade-subject h3 {
        margin: 0;
        font-size: 1.1em;
    }

    .grade-type {
        color: #666;
        font-size: 0.9em;
        margin: 5px 0 0;
    }

    .grade-value {
        font-size: 1.2em;
        font-weight: bold;
        text-align: right;
    }

    .grade-value.passing {
        color: #4caf50;
    }

    .grade-value.failing {
        color: #f44336;
    }

    .grade-comparison {
        font-size: 0.8em;
        color: #666;
        text-align: right;
        margin-top: 5px;
    }

    .notification-panel {
        position: fixed;
        top: 60px;
        right: 20px;
        width: 350px;
        background: white;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        z-index: 1000;
    }

    .notification-header {
        padding: 15px;
        border-bottom: 1px solid #eee;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }

    .notification-list {
        max-height: 400px;
        overflow-y: auto;
    }

    .notification-item {
        display: flex;
        padding: 15px;
        border-bottom: 1px solid #eee;
        cursor: pointer;
    }

    .notification-item:hover {
        background: #f8f9fa;
    }

    .notification-icon {
        font-size: 1.5em;
        color: #2575fc;
        margin-right: 15px;
    }

    .notification-content h4 {
        margin: 0;
        font-size: 1em;
    }

    .notification-content p {
        margin: 5px 0;
        font-size: 0.9em;
        color: #666;
    }

    .notification-content small {
        color: #999;
        font-size: 0.8em;
    }

    .close-btn {
        background: none;
        border: none;
        font-size: 1.2em;
        cursor: pointer;
        color: #666;
    }

    .close-btn:hover {
        color: #333;
    }
    </style>

    <script>
    // Notification handling
    function toggleNotificationPanel() {
        const panel = document.getElementById('notificationPanel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
        
        if (panel.style.display === 'block') {
            // Mark notifications as read
            const notifications = document.querySelectorAll('.notification-item');
            notifications.forEach(notif => {
                const notifId = notif.dataset.id;
                fetch('mark_notification_read.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ notification_id: notifId })
                });
            });
            
            // Hide the badge
            document.getElementById('notificationBadge').style.display = 'none';
        }
    }

    function closeNotificationPanel() {
        document.getElementById('notificationPanel').style.display = 'none';
    }

    // Real-time updates using Server-Sent Events
    const eventSource = new EventSource('student_updates.php');
    
    eventSource.onmessage = function(event) {
        const data = JSON.parse(event.data);
        
        if (data.type === 'grade') {
            // Update grades list
            const gradesList = document.querySelector('.grades-list');
            const newGrade = createGradeElement(data.grade);
            gradesList.insertBefore(newGrade, gradesList.firstChild);
            
            // Show notification
            showNotification(`Nouvelle note en ${data.grade.subject}`, `Note: ${data.grade.value}/20`);
        } else if (data.type === 'notification') {
            // Update notification count
            const badge = document.getElementById('notificationBadge');
            badge.textContent = parseInt(badge.textContent || '0') + 1;
            badge.style.display = 'block';
            
            // Add notification to panel
            const notifList = document.querySelector('.notification-list');
            const newNotif = createNotificationElement(data.notification);
            notifList.insertBefore(newNotif, notifList.firstChild);
            
            // Show notification
            showNotification(data.notification.title, data.notification.message);
        }
    };

    eventSource.onerror = function() {
        console.log('SSE connection failed. Retrying...');
    };

    function createGradeElement(grade) {
        const div = document.createElement('div');
        div.className = 'grade-item';
        div.innerHTML = `
            <div class="grade-subject">
                <h3>${grade.subject}</h3>
                <p class="grade-type">${grade.type}</p>
            </div>
            <div class="grade-details">
                <div class="grade-value ${parseFloat(grade.value) >= 10 ? 'passing' : 'failing'}">
                    ${parseFloat(grade.value).toFixed(2)}/20
                </div>
                <div class="grade-comparison">
                    <small>Moyenne de la classe: ${parseFloat(grade.class_average).toFixed(2)}</small>
                </div>
            </div>
        `;
        return div;
    }

    function createNotificationElement(notification) {
        const div = document.createElement('div');
        div.className = 'notification-item';
        div.dataset.id = notification.id;
        div.innerHTML = `
            <div class="notification-icon">
                <i class="uil ${notification.subject ? 'uil-book-alt' : 'uil-bell'}"></i>
            </div>
            <div class="notification-content">
                <h4>${notification.title}</h4>
                <p>${notification.message}</p>
                <small>
                    ${notification.subject ? notification.subject + ' - ' : ''}
                    ${notification.sender} - 
                    ${new Date(notification.date).toLocaleString()}
                </small>
            </div>
        `;
        return div;
    }

    function showNotification(title, message) {
        if ('Notification' in window) {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    new Notification(title, { body: message });
                }
            });
        }
    }
    </script>
</body>
</html>