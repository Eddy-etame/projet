<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';
require_once __DIR__ . '/../shared/error_logger.php';

// Get database connection
$conn = getDBConnection();

$error = '';
$success = '';

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || $_SESSION['role'] != 3) {
    header('Location: ../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $new_password = $_POST['new_password'] ?? '';
        $confirm_password = $_POST['confirm_password'] ?? '';
        
        if (strlen($new_password) < 6) {
            $error = 'Le mot de passe doit contenir au moins 6 caractères.';
        } elseif ($new_password !== $confirm_password) {
            $error = 'Les mots de passe ne correspondent pas.';
        } else {
            $hashed = password_hash($new_password, PASSWORD_BCRYPT);
            $stmt = $conn->prepare('UPDATE Utilisateurs SET mot_de_passe_hash = ?, must_change_password = 0 WHERE id_utilisateur = ?');
            if (!$stmt) {
                throw new Exception("Erreur de préparation de la requête");
            }
            
            $stmt->bind_param('si', $hashed, $_SESSION['user_id']);
            if ($stmt->execute()) {
                $success = 'Mot de passe changé avec succès. Vous pouvez accéder à votre tableau de bord.';
            } else {
                throw new Exception("Erreur lors de l'exécution de la requête");
            }
            $stmt->close();
        }
    } catch (Exception $e) {
        error_log("Password change error: " . $e->getMessage());
        $error = 'Une erreur est survenue lors du changement de mot de passe. Veuillez réessayer.';
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Changer le mot de passe</title>
    <link rel="stylesheet" href="../css/student-dashboard.css">
    <style>
    :root {
        --primary: #8B4513;
        --primary-light: #A0522D;
        --secondary: #FFD700;
        --secondary-light: #FFE55C;
        --accent: #DEB887;
        --text-dark: #3E2723;
        --text-light: #ffffff;
        --background-light: #FFF8DC;
        --shadow: 0 2px 8px rgba(139, 69, 19, 0.1);
    }

    body {
        background-color: var(--background-light);
        color: var(--text-dark);
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 20px;
    }

    .change-password-container {
        max-width: 500px;
        margin: 40px auto;
        padding: 2rem;
        background: white;
        border-radius: 12px;
        box-shadow: var(--shadow);
    }

    h2 {
        color: var(--primary);
        margin-bottom: 1.5rem;
        text-align: center;
    }

    .form-group {
        margin-bottom: 1.2rem;
    }

    label {
        display: block;
        margin-bottom: 0.5rem;
        color: var(--text-dark);
        font-weight: 500;
    }

    input[type="password"] {
        width: 100%;
        padding: 10px;
        border: 1px solid var(--accent);
        border-radius: 6px;
        font-size: 1rem;
        transition: all 0.3s ease;
    }

    input[type="password"]:focus {
        outline: none;
        border-color: var(--primary);
        box-shadow: 0 0 0 2px rgba(139, 69, 19, 0.1);
    }

    button {
        background: var(--primary);
        color: white;
        border: none;
        padding: 12px 24px;
        border-radius: 6px;
        font-size: 1rem;
        cursor: pointer;
        width: 100%;
        transition: all 0.3s ease;
    }

    button:hover {
        background: var(--primary-light);
        transform: translateY(-2px);
    }

    .alert {
        padding: 12px;
        border-radius: 6px;
        margin-bottom: 1rem;
    }

    .alert-danger {
        background: rgba(220, 53, 69, 0.1);
        color: #dc3545;
        border: 1px solid rgba(220, 53, 69, 0.2);
    }

    .alert-success {
        background: rgba(40, 167, 69, 0.1);
        color: #28a745;
        border: 1px solid rgba(40, 167, 69, 0.2);
    }

    .btn-link {
        display: inline-block;
        color: var(--primary);
        text-decoration: none;
        margin-top: 1rem;
        font-weight: 500;
    }

    .btn-link:hover {
        color: var(--primary-light);
        text-decoration: underline;
    }

    .password-requirements {
        font-size: 0.9rem;
        color: #666;
        margin-top: 0.5rem;
    }
    </style>
</head>
<body>
    <div class="change-password-container">
        <h2>Changer le mot de passe</h2>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
        <?php elseif ($success): ?>
            <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
            <div style="text-align: center;">
                <a href="SDashboard.php" class="btn-link">Retourner au tableau de bord</a>
            </div>
        <?php else: ?>
            <form method="post">
                <div class="form-group">
                    <label for="new_password">Nouveau mot de passe</label>
                    <input type="password" id="new_password" name="new_password" required>
                    <div class="password-requirements">Le mot de passe doit contenir au moins 6 caractères.</div>
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirmer le mot de passe</label>
                    <input type="password" id="confirm_password" name="confirm_password" required>
                </div>
                <button type="submit">Changer le mot de passe</button>
                <div style="text-align: center; margin-top: 1rem;">
                    <a href="SDashboard.php" class="btn-link">Annuler</a>
                </div>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
