<?php
require_once '../includes/db.php';
require_once '../includes/middleware.php';

// Ensure user is logged in as student
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];

// Get list of teachers
try {
    $query = "SELECT id_utilisateur, nom, email 
              FROM Utilisateurs 
              WHERE role = 'teacher' 
              ORDER BY nom";
    $result = $conn->query($query);
    $teachers = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
    header('Location: SDashboard.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envoyer un message - OAC</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <style>
        .message-form {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background: var(--white);
            border-radius: 12px;
            box-shadow: var(--shadow);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-dark);
            font-weight: 600;
        }

        .form-group select,
        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            background: var(--white);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 150px;
        }

        .btn-send {
            background: var(--accent);
            color: var(--white);
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.2s;
        }

        .btn-send:hover {
            background: var(--secondary);
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
    </style>
</head>
<body>
    <div class="message-form">
        <h2>Envoyer un message à un professeur</h2>
        
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php 
                echo $_SESSION['success'];
                unset($_SESSION['success']);
                ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?php 
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>

        <form id="messageForm" onsubmit="return sendMessage(event)">
            <div class="form-group">
                <label for="teacher">Professeur</label>
                <select name="recipient_id" id="teacher" required>
                    <option value="">Sélectionnez un professeur</option>
                    <?php foreach ($teachers as $teacher): ?>
                        <option value="<?php echo $teacher['id_utilisateur']; ?>">
                            <?php echo htmlspecialchars($teacher['nom']) . ' (' . htmlspecialchars($teacher['email']) . ')'; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="subject">Sujet</label>
                <input type="text" name="subject" id="subject" required>
            </div>

            <div class="form-group">
                <label for="content">Message</label>
                <textarea name="content" id="content" required></textarea>
            </div>

            <button type="submit" class="btn-send">Envoyer le message</button>
        </form>
    </div>

    <script>
    async function sendMessage(event) {
        event.preventDefault();
        const form = event.target;
        const formData = new FormData(form);
        
        try {
            const response = await fetch('../teacher/send_message.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            if (data.success) {
                form.reset();
                const alert = document.createElement('div');
                alert.className = 'alert alert-success';
                alert.textContent = 'Message envoyé avec succès';
                form.parentNode.insertBefore(alert, form);
                
                setTimeout(() => {
                    alert.remove();
                }, 3000);
            } else {
                throw new Error(data.error || 'Erreur lors de l\'envoi du message');
            }
        } catch (error) {
            const alert = document.createElement('div');
            alert.className = 'alert alert-error';
            alert.textContent = error.message;
            form.parentNode.insertBefore(alert, form);
            
            setTimeout(() => {
                alert.remove();
            }, 3000);
        }
        
        return false;
    }
    </script>
</body>
</html> 