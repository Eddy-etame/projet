<?php
require_once __DIR__ . '/../auth/middleware.php';
require_once __DIR__ . '/../auth/db.php';

AuthMiddleware::requireRole(3);

// Helper functions for grade conversion and analytics
function calculateGPA($score_20) {
    // Standard GPA calculation based on 20-point scale
    if ($score_20 >= 18) return 4.0;      // A+ (Excellent)
    if ($score_20 >= 16) return 3.7;      // A  (Very Good)
    if ($score_20 >= 15) return 3.3;      // B+ (Good)
    if ($score_20 >= 14) return 3.0;      // B  (Above Average)
    if ($score_20 >= 13) return 2.7;      // B- (Average)
    if ($score_20 >= 12) return 2.3;      // C+ (Below Average)
    if ($score_20 >= 11) return 2.0;      // C  (Poor)
    if ($score_20 >= 10) return 1.7;      // C- (Very Poor)
    if ($score_20 >= 9) return 1.3;       // D+ (Passing)
    if ($score_20 >= 8) return 1.0;       // D  (Minimum Pass)
    return 0.0;                           // F  (Fail)
}

function getLetterGrade($score_20) {
    if ($score_20 >= 18) return 'A+';
    if ($score_20 >= 16) return 'A';
    if ($score_20 >= 15) return 'B+';
    if ($score_20 >= 14) return 'B';
    if ($score_20 >= 13) return 'B-';
    if ($score_20 >= 12) return 'C+';
    if ($score_20 >= 11) return 'C';
    if ($score_20 >= 10) return 'C-';
    if ($score_20 >= 9) return 'D+';
    if ($score_20 >= 8) return 'D';
    return 'F';
}

// Convert French 20-point scale to 100-point scale
function convertTo100Point($score) {
    return ($score / 20) * 100;
}

// New analytics functions
function calculateTrend($grades) {
    if (count($grades) < 2) return 'stable';
    $first_half = array_slice($grades, 0, floor(count($grades)/2));
    $second_half = array_slice($grades, floor(count($grades)/2));
    $first_avg = array_sum($first_half) / count($first_half);
    $second_avg = array_sum($second_half) / count($second_half);
    $diff = $second_avg - $first_avg;
    if ($diff > 1) return 'improving';
    if ($diff < -1) return 'declining';
    return 'stable';
}

function getStrengthsAndWeaknesses($grades_by_subject) {
    $strengths = [];
    $weaknesses = [];
    foreach ($grades_by_subject as $subject => $data) {
        $avg = $data['total'] / $data['count'];
        if ($avg >= 15) {
            $strengths[] = $subject;
        } elseif ($avg < 10) {
            $weaknesses[] = $subject;
        }
    }
    return ['strengths' => $strengths, 'weaknesses' => $weaknesses];
}

function calculateClassRank($student_id, $conn) {
    $sql = "WITH StudentAverages AS (
        SELECT 
            n.id_etudiant,
            AVG(n.valeur_note) as moyenne,
            RANK() OVER (ORDER BY AVG(n.valeur_note) DESC) as rank
        FROM Notes n
        WHERE n.est_publie = 1
        GROUP BY n.id_etudiant
    )
    SELECT rank, COUNT(*) OVER() as total_students
    FROM StudentAverages
    WHERE id_etudiant = ?";
    
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $student_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $rank_data = $result->fetch_assoc();
    return $rank_data ? $rank_data : ['rank' => 'N/A', 'total_students' => 0];
}

// Get student data
$student_id = $_SESSION['user_id'];
$studentName = $_SESSION['user_name'] ?? 'Student';
$success_message = '';
$error_message = '';

// Get student's published grades with class averages
$sql = "SELECT n.*, m.nom_matiere, u.nom as prof_nom, u.prenom as prof_prenom,
        (SELECT AVG(valeur_note) 
         FROM Notes n2 
         WHERE n2.id_matiere = n.id_matiere 
         AND n2.type_evaluation = n.type_evaluation
         AND n2.est_publie = 1) as class_average
        FROM Notes n
        JOIN Matieres m ON n.id_matiere = m.id_matiere
        JOIN Utilisateurs u ON n.id_enseignant_saisie = u.id_utilisateur
        WHERE n.id_etudiant = ? AND n.est_publie = 1
        ORDER BY n.date_saisie DESC";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$results = $stmt->get_result();

// Calculate overall average and analytics
$total_gpa = 0;
$total_notes = 0;
$count_notes = 0;
$grades_by_subject = [];
$grades = [];
$grade_history = [];

if ($results->num_rows > 0) {
    while ($row = $results->fetch_assoc()) {
        $score_100 = convertTo100Point($row['valeur_note']);
        $letter_grade = getLetterGrade($row['valeur_note']);
        $gpa = calculateGPA($row['valeur_note']);
        
        $total_notes += $row['valeur_note'];
        $total_gpa += $gpa;
        $count_notes++;
        
        // Group grades by subject
        if (!isset($grades_by_subject[$row['nom_matiere']])) {
            $grades_by_subject[$row['nom_matiere']] = [
                'total' => 0,
                'total_gpa' => 0,
                'count' => 0,
                'grades' => [],
                'class_averages' => []
            ];
        }
        $grades_by_subject[$row['nom_matiere']]['total'] += $row['valeur_note'];
        $grades_by_subject[$row['nom_matiere']]['total_gpa'] += $gpa;
        $grades_by_subject[$row['nom_matiere']]['count']++;
        $grades_by_subject[$row['nom_matiere']]['grades'][] = $row['valeur_note'];
        $grades_by_subject[$row['nom_matiere']]['class_averages'][] = $row['class_average'];

        // Add to grades array for the main table
        $grades[] = [
            'subject' => $row['nom_matiere'],
            'type_evaluation' => $row['type_evaluation'],
            'grade_20' => number_format($row['valeur_note'], 2),
            'grade_100' => number_format($score_100, 2),
            'letter_grade' => $letter_grade,
            'gpa' => number_format($gpa, 2),
            'class_average' => number_format($row['class_average'], 2),
            'teacher' => $row['prof_prenom'] . ' ' . $row['prof_nom'],
            'comments' => $row['commentaire'] ?? '',
            'date' => date('d/m/Y', strtotime($row['date_saisie']))
        ];

        // Add to grade history for trend analysis
        $grade_history[] = [
            'date' => $row['date_saisie'],
            'grade' => $row['valeur_note'],
            'subject' => $row['nom_matiere']
        ];
    }
}

$overall_average_20 = $count_notes > 0 ? number_format($total_notes / $count_notes, 2) : 0;
$overall_average_100 = convertTo100Point($overall_average_20);
$overall_letter_grade = getLetterGrade($overall_average_20);
$overall_gpa = $count_notes > 0 ? number_format($total_gpa / $count_notes, 2) : 0;

// Calculate analytics
$rank_data = calculateClassRank($student_id, $conn);
$rank = $rank_data['rank'];
$total_students = $rank_data['total_students'];

// Calculate performance insights
$performance_analysis = [];
foreach ($grades_by_subject as $subject => $data) {
    $subject_avg = $data['total'] / $data['count'];
    $class_avg = array_sum($data['class_averages']) / count($data['class_averages']);
    $trend = calculateTrend($data['grades']);
    
    $performance_analysis[$subject] = [
        'average' => number_format($subject_avg, 2),
        'class_average' => number_format($class_avg, 2),
        'trend' => $trend,
        'difference' => number_format($subject_avg - $class_avg, 2)
    ];
}

$strengths_weaknesses = getStrengthsAndWeaknesses($grades_by_subject);

// Add PDF export logic at the top
if (isset($_GET['export_pdf'])) {
    require_once __DIR__ . '/../fpdf186/fpdf.php';
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Bulletin de Notes', 0, 1, 'C');
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, 'Nom: ' . htmlspecialchars($_SESSION['user_name']), 0, 1);
    $pdf->Cell(0, 10, 'Email: ' . htmlspecialchars($_SESSION['user_email']), 0, 1);
    $pdf->Ln(5);
    
    // Add performance summary
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Résumé des Performances', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 8, 'Moyenne Générale: ' . $overall_average_20 . '/20 (GPA: ' . $overall_gpa . ')', 0, 1);
    $pdf->Cell(0, 8, 'Classement: ' . $rank . ' sur ' . $total_students . ' étudiants', 0, 1);
    
    // Add subject details
    foreach ($grades_by_subject as $subject => $data) {
        $pdf->SetFont('Arial', 'B', 12);
        $pdf->Cell(0, 8, $subject . ' (Moyenne: ' . number_format($data['total'] / $data['count'], 2) . '/20)', 0, 1);
        $pdf->SetFont('Arial', '', 11);
        foreach ($data['grades'] as $grade) {
            if (!empty($grade['est_publie'])) {
                $pdf->Cell(0, 7, $grade['type_evaluation'] . ': ' . number_format($grade['valeur_note'], 2) . '/20 - ' . date('d/m/Y', strtotime($grade['date_saisie'])) . ' - Prof: ' . $grade['prof_prenom'] . ' ' . $grade['prof_nom'], 0, 1);
                if (!empty($grade['commentaire'])) {
                    $pdf->SetFont('Arial', 'I', 10);
                    $pdf->Cell(0, 6, 'Commentaire: ' . $grade['commentaire'], 0, 1);
                    $pdf->SetFont('Arial', '', 11);
                }
            }
        }
        $pdf->Ln(2);
    }
    
    // Add performance analysis
    $pdf->SetFont('Arial', 'B', 14);
    $pdf->Cell(0, 10, 'Analyse des Performances', 0, 1);
    $pdf->SetFont('Arial', '', 12);
    
    if (!empty($strengths_weaknesses['strengths'])) {
        $pdf->Cell(0, 8, 'Points Forts: ' . implode(', ', $strengths_weaknesses['strengths']), 0, 1);
    }
    if (!empty($strengths_weaknesses['weaknesses'])) {
        $pdf->Cell(0, 8, 'Points à Améliorer: ' . implode(', ', $strengths_weaknesses['weaknesses']), 0, 1);
    }
    
    $pdf->Output('I', 'Bulletin_de_notes.pdf');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Notes</title>
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <link rel="stylesheet" href="../css/student-dashboard.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <nav class="navbar navbar-dashboard">
        <div class="navbar-left">
            <span class="navbar-title">Portail Étudiant</span>
        </div>
        <div class="navbar-right">
            <div class="user-profile-menu">
                <span class="user-avatar" style="background:#fc5c7d; color:#fff; border-radius:50%; width:36px; height:36px; display:inline-flex; align-items:center; justify-content:center; font-weight:bold; font-size:1.1em; margin-right:8px;">
                    <?= strtoupper(substr($_SESSION['user_name'] ?? '', 0, 1)) ?>
                </span>
                <span class="user-name" style="font-weight:600; color:#222; margin-right:12px;">
                    <?= htmlspecialchars($_SESSION['user_name'] ?? '') ?>
                </span>
                <div class="dropdown" style="display:inline-block; position:relative;">
                    <button class="btn btn-link" onclick="toggleProfileDropdown()" style="padding:0; font-size:1.2em;">&#x25BC;</button>
                    <div id="profileDropdown" class="dropdown-content" style="display:none; position:absolute; right:0; background:#fff; box-shadow:0 2px 8px rgba(17,17,17,0.07); border-radius:8px; min-width:180px; z-index:100;">
                        <a href="SDashboard.php" class="dropdown-item">Tableau de bord</a>
                        <a href="#" class="dropdown-item" onclick="showProfileModal();return false;">Mon profil</a>
                        <a href="change_password.php" class="dropdown-item">Changer le mot de passe</a>
                        <a href="../logout.php" class="dropdown-item" style="color:#fc5c7d;">Se déconnecter</a>
                    </div>
                </div>
            </div>
        </div>
    </nav>
    <div class="student-dashboard">
        <h1 class="dashboard-title">Mes Notes et Analyses</h1>
        
        <!-- Performance Overview -->
        <div class="performance-overview card">
            <h2>Vue d'ensemble</h2>
            <div class="overview-grid">
                <div class="overview-item">
                    <h3>Moyenne Générale</h3>
                    <div class="big-number"><?= $overall_average_20 ?>/20</div>
                    <div class="sub-text">GPA: <?= $overall_gpa ?></div>
                </div>
                <div class="overview-item">
                    <h3>Classement</h3>
                    <div class="big-number"><?= $rank ?></div>
                    <div class="sub-text">sur <?= $total_students ?> étudiants</div>
                </div>
                <div class="overview-item">
                    <h3>Tendance Globale</h3>
                    <div class="trend-indicator">
                        <?php
                        $overall_trend = calculateTrend(array_column($grade_history, 'grade'));
                        $trend_icon = [
                            'improving' => '↗️',
                            'declining' => '↘️',
                            'stable' => '→'
                        ][$overall_trend];
                        echo $trend_icon;
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Strengths and Weaknesses -->
        <div class="strengths-weaknesses card">
            <h2>Points Forts et Points à Améliorer</h2>
            <div class="sw-grid">
                <div class="strengths">
                    <h3>Points Forts</h3>
                    <ul>
                        <?php foreach ($strengths_weaknesses['strengths'] as $subject): ?>
                            <li><?= htmlspecialchars($subject) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="weaknesses">
                    <h3>Points à Améliorer</h3>
                    <ul>
                        <?php foreach ($strengths_weaknesses['weaknesses'] as $subject): ?>
                            <li><?= htmlspecialchars($subject) ?></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Grade History Chart -->
        <div class="grade-history card">
            <h2>Évolution des Notes</h2>
            <canvas id="gradeHistoryChart"></canvas>
        </div>

        <!-- Subject Performance -->
        <div class="subject-performance card">
            <h2>Performance par Matière</h2>
            <div class="subject-grid">
                <?php foreach ($performance_analysis as $subject => $analysis): ?>
                    <div class="subject-card">
                        <h3><?= htmlspecialchars($subject) ?></h3>
                        <div class="subject-stats">
                            <div class="stat-item">
                                <label>Votre moyenne:</label>
                                <span><?= $analysis['average'] ?>/20</span>
                            </div>
                            <div class="stat-item">
                                <label>Moyenne de la classe:</label>
                                <span><?= $analysis['class_average'] ?>/20</span>
                            </div>
                            <div class="stat-item">
                                <label>Différence:</label>
                                <span class="<?= $analysis['difference'] >= 0 ? 'positive' : 'negative' ?>">
                                    <?= $analysis['difference'] ?>
                                </span>
                            </div>
                            <div class="stat-item">
                                <label>Tendance:</label>
                                <span><?= $analysis['trend'] ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- Export Options -->
        <div class="export-options">
            <a href="?export_pdf=1" class="btn btn-primary">Exporter en PDF</a>
            <button onclick="exportToExcel()" class="btn btn-secondary">Exporter en Excel</button>
        </div>
    </div>

    <style>
    .card {
        background: white;
        border-radius: 10px;
        padding: 20px;
        margin-bottom: 20px;
        box-shadow: 0 2px 4px rgba(0,0,0,0.1);
    }
    
    .overview-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }
    
    .overview-item {
        text-align: center;
        padding: 20px;
        background: #f8f9fa;
        border-radius: 8px;
    }
    
    .big-number {
        font-size: 2em;
        font-weight: bold;
        color: var(--primary);
        margin: 10px 0;
    }
    
    .sub-text {
        color: #666;
        font-size: 0.9em;
    }
    
    .sw-grid {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    
    .strengths, .weaknesses {
        padding: 15px;
        border-radius: 8px;
    }
    
    .strengths {
        background: #e8f5e9;
    }
    
    .weaknesses {
        background: #ffebee;
    }
    
    .subject-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin-top: 20px;
    }
    
    .subject-card {
        background: #f8f9fa;
        padding: 15px;
        border-radius: 8px;
    }
    
    .subject-stats {
        margin-top: 10px;
    }
    
    .stat-item {
        display: flex;
        justify-content: space-between;
        margin: 5px 0;
    }
    
    .positive {
        color: #4caf50;
    }
    
    .negative {
        color: #f44336;
    }
    
    .export-options {
        margin-top: 20px;
        display: flex;
        gap: 10px;
    }
    </style>

    <script>
    // Initialize grade history chart
    const ctx = document.getElementById('gradeHistoryChart').getContext('2d');
    const gradeHistory = <?= json_encode($grade_history) ?>;
    
    const datasets = {};
    gradeHistory.forEach(entry => {
        if (!datasets[entry.subject]) {
            datasets[entry.subject] = {
                label: entry.subject,
                data: [],
                borderColor: '#' + Math.floor(Math.random()*16777215).toString(16),
                fill: false
            };
        }
        datasets[entry.subject].data.push({
            x: new Date(entry.date),
            y: entry.grade
        });
    });
    
    new Chart(ctx, {
        type: 'line',
        data: {
            datasets: Object.values(datasets)
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'time',
                    time: {
                        unit: 'day'
                    }
                },
                y: {
                    min: 0,
                    max: 20
                }
            }
        }
    });

    // Excel export function
    function exportToExcel() {
        const grades = <?= json_encode($grades) ?>;
        let csv = 'Matière,Type,Note/20,Note/100,Note Lettre,GPA,Moyenne Classe,Professeur,Commentaires,Date\n';
        
        grades.forEach(grade => {
            csv += `${grade.subject},${grade.type_evaluation},${grade.grade_20},${grade.grade_100},${grade.letter_grade},${grade.gpa},${grade.class_average},"${grade.teacher}","${grade.comments}",${grade.date}\n`;
        });
        
        const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement("a");
        const url = URL.createObjectURL(blob);
        link.setAttribute("href", url);
        link.setAttribute("download", "notes.csv");
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    </script>
</body>
</html>