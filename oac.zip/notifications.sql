-- Notifications table for emails, news, and messages
CREATE TABLE IF NOT EXISTS Notifications (
    id_notification INT PRIMARY KEY AUTO_INCREMENT,
    type ENUM('email', 'news', 'message') NOT NULL,
    sender_id INT NOT NULL,
    recipient_id INT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES Utilisateurs(id_utilisateur),
    FOREIGN KEY (recipient_id) REFERENCES Utilisateurs(id_utilisateur)
);

-- News table for school announcements
CREATE TABLE IF NOT EXISTS News (
    id_news INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    author_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES Utilisateurs(id_utilisateur)
);

-- Messages table for student-teacher communication
CREATE TABLE IF NOT EXISTS Messages (
    id_message INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT NOT NULL,
    recipient_id INT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    parent_message_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES Utilisateurs(id_utilisateur),
    FOREIGN KEY (recipient_id) REFERENCES Utilisateurs(id_utilisateur),
    FOREIGN KEY (parent_message_id) REFERENCES Messages(id_message)
); 