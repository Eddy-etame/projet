<?php
// Include the main database configuration from auth/db.php
require_once __DIR__ . '/auth/db.php';

// Database configuration
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'Eddy');
define('DB_PASSWORD', 'Daddiesammy1$');
define('DB_NAME', 'keyce');

// Create connection
function getDBConnection() {
    static $conn = null;
    if ($conn === null) {
        $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
        if ($conn->connect_error) {
            error_log("Database connection failed: " . $conn->connect_error);
            die("Connection failed: " . $conn->connect_error);
        }
    }
    return $conn;
}

// Get a new connection (for cases where we need a fresh connection)
function getNewDBConnection() {
    $conn = new mysqli(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
    if ($conn->connect_error) {
        error_log("Database connection failed: " . $conn->connect_error);
        die("Connection failed: " . $conn->connect_error);
    }
    return $conn;
}

// Close all connections when the script ends
register_shutdown_function(function() {
    $conn = getDBConnection();
    if ($conn) {
        $conn->close();
    }
});
?> 