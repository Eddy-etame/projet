-- Sample admin user (replace password hash as needed)
INSERT INTO Utilisateurs (id_utilisateur, id_role, email, mot_de_passe, nom, prenom, nom_utilisateur, must_change_password)
VALUES (1, 1, 'etame.eddy01@gmail.com', '$2y$10$W.H/tLxt4DiR36wSBiB41.5uwfHd03FED4LJ0kDUOcxy12ODYk9NK', 'Admin', 'Super', 'admin', 0); 