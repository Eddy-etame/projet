// Form submission handlers
document.addEventListener('DOMContentLoaded', function() {
    // Registration form handler
    const registerForm = document.querySelector('.card-back form');
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const formData = {
                username: this.querySelector('input[placeholder="Full Name"]').value,
                firstname: this.querySelector('input[placeholder="First Name"]').value,
                lastname: this.querySelector('input[placeholder="Last Name"]').value,
                email: this.querySelector('input[type="email"]').value,
                password: this.querySelector('input[type="password"]').value,
                role: this.querySelector('select').value
            };
            
            // Validate password confirmation
            const confirmPassword = this.querySelector('input[placeholder="confirm Password"]').value;
            if (formData.password !== confirmPassword) {
                showError('Passwords do not match');
                return;
            }
            
            try {
                const response = await fetch('/api/auth/register.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showSuccess('Registration successful! Please login.');
                    // Switch to login form
                    document.querySelector('#reg-log').checked = false;
                } else {
                    showError(data.message);
                }
            } catch (error) {
                showError('An error occurred. Please try again.');
            }
        });
    }
});

// Helper functions
function showError(message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'alert alert-danger';
    errorDiv.textContent = message;
    
    const form = document.querySelector('.section.text-center');
    form.insertBefore(errorDiv, form.firstChild);
    
    setTimeout(() => errorDiv.remove(), 5000);
}

function showSuccess(message) {
    const successDiv = document.createElement('div');
    successDiv.className = 'alert alert-success';
    successDiv.textContent = message;
    
    const form = document.querySelector('.section.text-center');
    form.insertBefore(successDiv, form.firstChild);
    
    setTimeout(() => successDiv.remove(), 5000);
}