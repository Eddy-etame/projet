// admin-dashboard.js
// Handles live preview tooltips for entity counts on the admin dashboard
function setupPreviewTooltip(linkId, tooltipId, endpoint, label) {
    const previewLink = document.getElementById(linkId);
    const tooltip = document.getElementById(tooltipId);
    let loaded = false;
    if (!previewLink || !tooltip) return;
    previewLink.addEventListener('mouseenter', function() {
        if (!loaded) {
            fetch(endpoint)
                .then(res => res.json())
                .then(data => {
                    tooltip.textContent = label + (data.count ?? 'N/A');
                    tooltip.style.display = 'inline-block';
                    loaded = true;
                })
                .catch(() => {
                    tooltip.textContent = 'Erreur de chargement';
                    tooltip.style.display = 'inline-block';
                });
        } else {
            tooltip.style.display = 'inline-block';
        }
    });
    previewLink.addEventListener('mouseleave', function() {
        tooltip.style.display = 'none';
    });
}
document.addEventListener('DOMContentLoaded', function() {
    setupPreviewTooltip('preview-teachers', 'teachers-count-tooltip', 'get_teacher_count.php', "Nombre d'enseignants: ");
    setupPreviewTooltip('preview-subjects', 'subjects-count-tooltip', 'get_subject_count.php', "Nombre de matières: ");
    setupPreviewTooltip('preview-notes', 'notes-count-tooltip', 'get_note_count.php', "Nombre de notes: ");
});
