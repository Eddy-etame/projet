import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import { getAuth, signInAnonymously, signInWithCustomToken, onAuthStateChanged, signOut } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore'; // Import getFirestore

// Dummy data for demonstration
const dummyStudentGrades = [
    { id: 1, subject: 'Mathématiques', score: '15/20', date: '2024-05-10', remarks: 'Bon travail' },
    { id: 2, subject: 'Physique', score: '12/20', date: '2024-05-10', remarks: 'À améliorer' },
    { id: 3, subject: 'Informatique', score: '18/20', date: '2024-05-12', remarks: 'Excellent' },
];

const dummyStudentTranscript = {
    name: 'Jean Dupont',
    id: 'ETU12345',
    program: 'Licence Informatique',
    academicYear: '2024-2025 Semestre 1',
    grades: [
        { subject: 'Algorithmique', score: '16/20', credits: 5 },
        { subject: 'Bases de Données', score: '14/20', credits: 5 },
        { subject: 'Réseaux', score: '13/20', credits: 4 },
        { subject: 'Anglais', score: '17/20', credits: 2 },
    ],
    gpa: '3.5/4.0',
    overallAverage: '15/20',
};

const dummyNotifications = [
    { id: 1, message: 'Nouvelles notes pour Physique publiées le 10-05-2024', timestamp: '2024-05-10 14:30', read: false },
    { id: 2, message: 'Rappel: Inscription aux examens de fin de semestre', timestamp: '2024-04-28 09:00', read: true },
    { id: 3, message: 'Votre relevé de notes du semestre précédent est disponible.', timestamp: '2024-04-15 11:00', read: true },
];

const dummyTeachers = [
    { id: 'T001', name: 'Mme. Dubois', email: 'dubois@univ.com', status: 'Actif' },
    { id: 'T002', name: 'M. Leclerc', email: 'leclerc@univ.com', status: 'Actif' },
];

const dummySubjects = [
    { id: 'MATH101', name: 'Mathématiques' },
    { id: 'PHY101', name: 'Physique' },
    { id: 'INFO101', name: 'Informatique' },
];

const dummySessions = [
    { id: 'S2024-1', name: '2024-2025 Semestre 1', startDate: '2024-09-01', endDate: '2025-01-31', status: 'Active' },
    { id: 'S2023-2', name: '2023-2024 Semestre 2', startDate: '2024-02-01', endDate: '2024-06-30', status: 'Archivée' },
];

// Firebase initialization (using global variables provided by Canvas)
let firebaseApp;
let db;
let auth;
let currentUserId = 'guest'; // Default to guest

const initializeFirebase = async () => {
    try {
        const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
        const firebaseConfig = typeof __firebase_config !== 'undefined' ? JSON.parse(__firebase_config) : {};

        if (Object.keys(firebaseConfig).length > 0 && !firebaseApp) {
            firebaseApp = initializeApp(firebaseConfig);
            db = getFirestore(firebaseApp);
            auth = getAuth(firebaseApp);

            if (typeof __initial_auth_token !== 'undefined') {
                await signInWithCustomToken(auth, __initial_auth_token);
            } else {
                await signInAnonymously(auth);
            }

            onAuthStateChanged(auth, (user) => {
                if (user) {
                    currentUserId = user.uid;
                    console.log('Firebase user ID:', currentUserId);
                } else {
                    currentUserId = 'guest';
                    console.log('No Firebase user is signed in.');
                }
            });
        }
    } catch (error) {
        console.error("Erreur lors de l'initialisation de Firebase:", error);
    }
};

// Call initialization once
initializeFirebase();

// Global Components
const Header = ({ userName, userRole, onLogout, currentPath, navigate }) => {
    const getRoleDisplayName = (role) => {
        switch (role) {
            case 'student': return 'Étudiant';
            case 'teacher': return 'Enseignant';
            case 'admin': return 'Administrateur';
            default: return '';
        }
    };

    return (
        <header className="bg-gradient-to-r from-blue-600 to-indigo-700 text-white p-4 shadow-lg flex justify-between items-center rounded-b-lg">
            <div className="flex items-center space-x-4">
                <h1 className="text-2xl font-bold cursor-pointer" onClick={() => navigate('/')}>Plateforme Académique</h1>
                {userRole && userRole !== 'public' && (
                    <span className="text-sm font-medium">
                        {userName} - {getRoleDisplayName(userRole)}
                    </span>
                )}
            </div>
            {userRole && userRole !== 'public' && (
                <nav className="flex items-center space-x-4">
                    <button
                        onClick={() => navigate(`/${userRole}/profil`)}
                        className="px-3 py-1 bg-white bg-opacity-20 hover:bg-opacity-30 rounded-md transition-all duration-200"
                    >
                        Mon Profil
                    </button>
                    <button
                        onClick={onLogout}
                        className="px-3 py-1 bg-red-500 hover:bg-red-600 rounded-md transition-all duration-200 shadow"
                    >
                        Déconnexion
                    </button>
                </nav>
            )}
        </header>
    );
};

const Footer = () => (
    <footer className="bg-gray-800 text-white text-center p-4 mt-8 rounded-t-lg shadow-inner">
        <p className="text-sm">&copy; {new Date().getFullYear()} Plateforme Académique. Tous droits réservés.</p>
        <div className="flex justify-center space-x-4 mt-2 text-xs">
            <a href="#" className="hover:underline">Contact & Support</a>
            <a href="#" className="hover:underline">Politique de Confidentialité</a>
        </div>
    </footer>
);

const SidebarNav = ({ userRole, currentPath, navigate }) => {
    const studentLinks = [
        { name: 'Tableau de Bord', path: '/etudiant/tableau-de-bord' },
        { name: 'Mes Notes', path: '/etudiant/notes' },
        { name: 'Mes Relevés de Notes', path: '/etudiant/releves' },
        { name: 'Historique des Notes', path: '/etudiant/historique' },
        { name: 'Notifications', path: '/etudiant/notifications' },
        { name: 'Mon Profil', path: '/etudiant/profil' },
    ];

    const teacherLinks = [
        { name: 'Tableau de Bord', path: '/enseignant/tableau-de-bord' },
        { name: 'Saisir/Gérer les Notes', path: '/enseignant/notes/gestion' },
        { name: 'Importer les Notes (PV)', path: '/enseignant/notes/import' },
        { name: 'Exporter les Notes', path: '/enseignant/notes/export' },
        { name: 'Voir les Résultats des Étudiants', path: '/enseignant/resultats/voir' },
        { name: 'Notifications', path: '/enseignant/notifications' },
        { name: 'Mon Profil', path: '/enseignant/profil' },
    ];

    const adminLinks = [
        { name: 'Tableau de Bord', path: '/admin/tableau-de-bord' },
        { name: 'Gestion des Utilisateurs', path: '/admin/utilisateurs' },
        { name: 'Gestion des Matières', path: '/admin/matieres' },
        { name: 'Gestion des Sessions Académiques', path: '/admin/sessions' },
        { name: 'Gestion des Notes & PV', path: '/admin/notes-pv' },
        { name: 'Journaux Système', path: '/admin/journaux' },
        { name: 'Gestion des Notifications', path: '/admin/notifications-config' },
        { name: 'Paramètres Système', path: '/admin/parametres' },
        { name: 'Mon Profil', path: '/admin/profil' },
    ];

    let links = [];
    switch (userRole) {
        case 'student': links = studentLinks; break;
        case 'teacher': links = teacherLinks; break;
        case 'admin': links = adminLinks; break;
        default: links = []; break;
    }

    return (
        <nav className="w-64 bg-gray-100 p-4 shadow-md rounded-lg">
            <ul>
                {links.map((link) => (
                    <li key={link.path} className="mb-2">
                        <button
                            onClick={() => navigate(link.path)}
                            className={`block w-full text-left p-2 rounded-md transition-colors duration-200 ${
                                currentPath === link.path
                                    ? 'bg-blue-600 text-white shadow-md'
                                    : 'text-gray-700 hover:bg-blue-100 hover:text-blue-700'
                            }`}
                        >
                            {link.name}
                        </button>
                    </li>
                ))}
            </ul>
        </nav>
    );
};

// Public Pages
const LoginPage = ({ onLogin, navigate }) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [message, setMessage] = useState('');

    const handleLogin = () => {
        // Simple client-side authentication simulation
        if (username === 'student' && password === 'password') {
            onLogin('student', 'Jean Dupont');
        } else if (username === 'teacher' && password === 'password') {
            onLogin('teacher', 'Mme. Martin');
        } else if (username === 'admin' && password === 'password') {
            onLogin('admin', 'Admin Principal');
        } else {
            setMessage('Identifiant ou mot de passe incorrect.');
        }
    };

    return (
        <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4">
            <div className="bg-white p-8 rounded-xl shadow-2xl w-full max-w-md text-center">
                <img src="https://placehold.co/150x50/3B82F6/FFFFFF?text=LOGO" alt="Logo du site" className="mx-auto mb-6" />
                <h2 className="text-3xl font-extrabold text-gray-900 mb-6">Bienvenue - Veuillez vous connecter</h2>
                <div className="space-y-4">
                    <input
                        type="text"
                        placeholder="Nom d'utilisateur/Identifiant"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                    />
                    <input
                        type="password"
                        placeholder="Mot de passe"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                    />
                    <button
                        onClick={handleLogin}
                        className="w-full bg-blue-600 text-white py-3 rounded-lg font-semibold hover:bg-blue-700 transition-all duration-200 shadow-md"
                    >
                        Se Connecter
                    </button>
                    {message && <p className="text-red-500 text-sm mt-2">{message}</p>}
                    <a href="#" className="text-blue-600 hover:underline text-sm block mt-4">Mot de passe oublié ?</a>
                </div>
                <p className="text-gray-500 text-sm mt-6">
                    Plateforme sécurisée de publication et de consultation des résultats académiques.
                </p>
            </div>
        </div>
    );
};

// Student Pages
const StudentDashboard = ({ userName, navigate }) => (
    <div className="p-6 bg-white rounded-xl shadow-lg">
        <h2 className="text-3xl font-bold text-gray-800 mb-6">Bienvenue, {userName} !</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-blue-50 p-6 rounded-lg shadow-inner">
                <h3 className="text-xl font-semibold text-blue-800 mb-3">Aperçu Rapide</h3>
                <p className="text-gray-700 mb-2">Nouvelles notes pour Mathématiques disponibles !</p>
                <p className="text-gray-700">Notifications non lues : <span className="font-bold text-blue-600">2</span></p>
            </div>
            <div className="bg-green-50 p-6 rounded-lg shadow-inner">
                <h3 className="text-xl font-semibold text-green-800 mb-3">Liens Rapides</h3>
                <div className="flex flex-col space-y-3">
                    <button
                        onClick={() => navigate('/etudiant/notes')}
                        className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 shadow"
                    >
                        Voir les Dernières Notes
                    </button>
                    <button
                        onClick={() => navigate('/etudiant/releves')}
                        className="bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors duration-200 shadow"
                    >
                        Voir Mon Relevé de Notes
                    </button>
                </div>
            </div>
        </div>
    </div>
);

const StudentGrades = () => {
    const [selectedYear, setSelectedYear] = useState('2024-2025 Sem. 1');
    const [selectedSubject, setSelectedSubject] = useState('');

    const filteredGrades = dummyStudentGrades.filter(grade => {
        // In a real app, filter by selectedYear and selectedSubject
        return true;
    });

    const overallAverage = filteredGrades.reduce((sum, grade) => {
        const score = parseInt(grade.score.split('/')[0]);
        return sum + score;
    }, 0) / filteredGrades.length;

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Mes Notes</h2>
            <div className="flex flex-wrap gap-4 mb-6">
                <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="2024-2025 Sem. 1">2024-2025 Sem. 1</option>
                    <option value="2023-2024 Sem. 2">2023-2024 Sem. 2</option>
                </select>
                <select
                    value={selectedSubject}
                    onChange={(e) => setSelectedSubject(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="">Toutes les matières</option>
                    <option value="Mathématiques">Mathématiques</option>
                    <option value="Physique">Physique</option>
                    <option value="Informatique">Informatique</option>
                </select>
            </div>
            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom de la Matière</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note/Score</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date de Publication</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Remarques</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredGrades.map((grade) => (
                            <tr key={grade.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{grade.subject}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.score}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.date}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.remarks}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            {filteredGrades.length > 0 && (
                <p className="mt-6 text-lg font-semibold text-gray-800">
                    Moyenne générale pour la période sélectionnée : {overallAverage.toFixed(2)}/20
                </p>
            )}
        </div>
    );
};

const StudentTranscripts = () => {
    const [selectedSession, setSelectedSession] = useState(dummyStudentTranscript.academicYear);

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Mes Relevés de Notes</h2>
            <div className="mb-6">
                <label htmlFor="session-select" className="block text-sm font-medium text-gray-700 mb-2">
                    Sélectionner Année Académique/Session :
                </label>
                <select
                    id="session-select"
                    value={selectedSession}
                    onChange={(e) => setSelectedSession(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 w-full md:w-1/2 lg:w-1/3"
                >
                    <option value="2024-2025 Semestre 1">2024-2025 Semestre 1</option>
                    <option value="2023-2024 Semestre 2">2023-2024 Semestre 2</option>
                </select>
            </div>

            <div className="border border-gray-200 rounded-lg p-6 mb-6 bg-blue-50">
                <h3 className="text-xl font-semibold text-blue-800 mb-4">Informations de l'Étudiant</h3>
                <p className="mb-1"><span className="font-medium">Nom :</span> {dummyStudentTranscript.name}</p>
                <p className="mb-1"><span className="font-medium">Identifiant :</span> {dummyStudentTranscript.id}</p>
                <p className="mb-1"><span className="font-medium">Programme :</span> {dummyStudentTranscript.program}</p>
                <p className="mb-1"><span className="font-medium">Session :</span> {dummyStudentTranscript.academicYear}</p>
            </div>

            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm mb-6">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Matière</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Crédits</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {dummyStudentTranscript.grades.map((grade, index) => (
                            <tr key={index}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{grade.subject}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.score}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.credits}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <div className="text-right mb-6">
                <p className="text-lg font-semibold text-gray-800">
                    Moyenne Générale Pondérée (GPA) : <span className="text-blue-600">{dummyStudentTranscript.gpa}</span>
                </p>
                <p className="text-lg font-semibold text-gray-800">
                    Moyenne générale : <span className="text-blue-600">{dummyStudentTranscript.overallAverage}</span>
                </p>
            </div>

            <div className="flex flex-wrap gap-4 justify-end">
                <button
                    onClick={() => alert('Téléchargement du relevé en PDF... (Fonctionnalité non implémentée)')}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                >
                    Télécharger le Relevé en PDF
                </button>
                <button
                    onClick={() => alert('Impression du relevé... (Fonctionnalité non implémentée)')}
                    className="bg-gray-600 text-white py-2 px-4 rounded-lg hover:bg-gray-700 transition-colors duration-200 shadow-md"
                >
                    Imprimer le Relevé
                </button>
            </div>
        </div>
    );
};

const StudentGradeHistory = () => {
    const [selectedYear, setSelectedYear] = useState('Toutes');
    const [selectedSemester, setSelectedSemester] = useState('Tous');

    const allYears = ['Toutes', '2024-2025', '2023-2024'];
    const allSemesters = ['Tous', 'Semestre 1', 'Semestre 2'];

    const filteredHistory = dummyStudentGrades.filter(grade => {
        // In a real app, filter by selectedYear and selectedSemester
        return true;
    });

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Historique de Mes Notes</h2>
            <div className="flex flex-wrap gap-4 mb-6">
                <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    {allYears.map(year => <option key={year} value={year}>{year}</option>)}
                </select>
                <select
                    value={selectedSemester}
                    onChange={(e) => setSelectedSemester(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    {allSemesters.map(semester => <option key={semester} value={semester}>{semester}</option>)}
                </select>
            </div>
            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom de la Matière</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note/Score</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date de Publication</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Remarques</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredHistory.map((grade) => (
                            <tr key={grade.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{grade.subject}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.score}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.date}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.remarks}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

const StudentNotifications = () => {
    const [notifications, setNotifications] = useState(dummyNotifications);

    const markAsRead = (id) => {
        setNotifications(notifications.map(n => n.id === id ? { ...n, read: true } : n));
    };

    const deleteNotification = (id) => {
        setNotifications(notifications.filter(n => n.id !== id));
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Notifications</h2>
            <div className="space-y-4">
                {notifications.length === 0 ? (
                    <p className="text-gray-600">Aucune notification pour le moment.</p>
                ) : (
                    notifications.map((notification) => (
                        <div
                            key={notification.id}
                            className={`p-4 rounded-lg flex items-center justify-between ${
                                notification.read ? 'bg-gray-100 text-gray-600' : 'bg-blue-50 text-blue-800 font-medium border border-blue-200'
                            }`}
                        >
                            <div>
                                <p className="text-base">{notification.message}</p>
                                <p className="text-xs text-gray-500 mt-1">{notification.timestamp}</p>
                            </div>
                            <div className="flex space-x-2">
                                {!notification.read && (
                                    <button
                                        onClick={() => markAsRead(notification.id)}
                                        className="text-blue-600 hover:text-blue-800 text-sm"
                                    >
                                        Marquer comme lue
                                    </button>
                                )}
                                <button
                                    onClick={() => deleteNotification(notification.id)}
                                    className="text-red-600 hover:text-red-800 text-sm"
                                >
                                    Supprimer
                                </button>
                            </div>
                        </div>
                    ))
                )}
            </div>
        </div>
    );
};

const StudentProfile = () => {
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmNewPassword, setConfirmNewPassword] = useState('');
    const [passwordMessage, setPasswordMessage] = useState('');

    const handleChangePassword = () => {
        if (newPassword !== confirmNewPassword) {
            setPasswordMessage('Les nouveaux mots de passe ne correspondent pas.');
            return;
        }
        // In a real app, send to backend for password update
        setPasswordMessage('Mot de passe mis à jour avec succès ! (Fonctionnalité non implémentée)');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmNewPassword('');
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Mon Profil</h2>
            <div className="mb-8 border border-gray-200 rounded-lg p-6 bg-blue-50">
                <h3 className="text-xl font-semibold text-blue-800 mb-4">Informations Personnelles</h3>
                <p className="mb-2"><span className="font-medium">Nom :</span> Jean Dupont</p>
                <p className="mb-2"><span className="font-medium">Identifiant Étudiant :</span> ETU12345</p>
                <p className="mb-2"><span className="font-medium">Programme :</span> Licence Informatique</p>
                <p className="mb-2"><span className="font-medium">Email :</span> jean.dupont@etu.univ.com</p>
            </div>

            <div className="mb-8 border border-gray-200 rounded-lg p-6 bg-gray-50">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Changer le Mot de Passe</h3>
                <div className="space-y-4 max-w-md">
                    <input
                        type="password"
                        placeholder="Mot de Passe Actuel"
                        value={currentPassword}
                        onChange={(e) => setCurrentPassword(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    />
                    <input
                        type="password"
                        placeholder="Nouveau Mot de Passe"
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    />
                    <input
                        type="password"
                        placeholder="Confirmer Nouveau Mot de Passe"
                        value={confirmNewPassword}
                        onChange={(e) => setConfirmNewPassword(e.target.value)}
                        className="w-full px-4 py-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                    />
                    <button
                        onClick={handleChangePassword}
                        className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                    >
                        Mettre à Jour le Mot de Passe
                    </button>
                    {passwordMessage && <p className="text-sm mt-2 text-green-600">{passwordMessage}</p>}
                </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-6 bg-gray-50">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Préférences de Notification</h3>
                <div className="flex items-center">
                    <input type="checkbox" id="email-notifications" className="h-4 w-4 text-blue-600 border-gray-300 rounded" defaultChecked />
                    <label htmlFor="email-notifications" className="ml-2 block text-sm text-gray-900">
                        Activer les notifications par email
                    </label>
                </div>
            </div>
        </div>
    );
};

// Teacher Pages
const TeacherDashboard = ({ userName, navigate }) => (
    <div className="p-6 bg-white rounded-xl shadow-lg">
        <h2 className="text-3xl font-bold text-gray-800 mb-6">Bienvenue, {userName} !</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-blue-50 p-6 rounded-lg shadow-inner">
                <h3 className="text-xl font-semibold text-blue-800 mb-3">Actions Rapides</h3>
                <div className="flex flex-col space-y-3">
                    <button
                        onClick={() => navigate('/enseignant/notes/gestion')}
                        className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow"
                    >
                        Saisir les Notes pour une Classe
                    </button>
                    <button
                        onClick={() => navigate('/enseignant/notes/import')}
                        className="bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700 transition-colors duration-200 shadow"
                    >
                        Importer un Fichier PV
                    </button>
                </div>
            </div>
            <div className="bg-green-50 p-6 rounded-lg shadow-inner">
                <h3 className="text-xl font-semibold text-green-800 mb-3">Mes Classes/Matières</h3>
                <ul className="list-disc list-inside text-gray-700">
                    <li>Mathématiques - Licence 1</li>
                    <li>Algorithmique - Licence 2</li>
                    <li>Physique - Master 1</li>
                </ul>
            </div>
        </div>
    </div>
);

const TeacherManageGrades = () => {
    const [selectedClass, setSelectedClass] = useState('Licence 1');
    const [selectedSubject, setSelectedSubject] = useState('Mathématiques');
    const [selectedYear, setSelectedYear] = useState('2024-2025 Sem. 1');
    const [grades, setGrades] = useState([
        { id: 'ETU12345', name: 'Jean Dupont', score: '15', remarks: '' },
        { id: 'ETU67890', name: 'Marie Curie', score: '17', remarks: 'Très bon' },
        { id: 'ETU11223', name: 'Pierre Martin', score: '10', remarks: 'Passable' },
    ]);
    const [status, setStatus] = useState('Brouillon');

    const handleScoreChange = (id, newScore) => {
        setGrades(grades.map(g => (g.id === id ? { ...g, score: newScore } : g)));
    };

    const handleRemarksChange = (id, newRemarks) => {
        setGrades(grades.map(g => (g.id === id ? { ...g, remarks: newRemarks } : g)));
    };

    const saveDraft = () => {
        setStatus('Brouillon');
        alert('Brouillon enregistré !');
    };

    const publishGrades = () => {
        setStatus('Publié');
        alert('Notes validées et publiées !');
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Saisir/Gérer les Notes</h2>
            <div className="flex flex-wrap gap-4 mb-6">
                <select
                    value={selectedClass}
                    onChange={(e) => setSelectedClass(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="Licence 1">Licence 1</option>
                    <option value="Licence 2">Licence 2</option>
                </select>
                <select
                    value={selectedSubject}
                    onChange={(e) => setSelectedSubject(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="Mathématiques">Mathématiques</option>
                    <option value="Physique">Physique</option>
                </select>
                <select
                    value={selectedYear}
                    onChange={(e) => setSelectedYear(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="2024-2025 Sem. 1">2024-2025 Sem. 1</option>
                    <option value="2023-2024 Sem. 2">2023-2024 Sem. 2</option>
                </select>
            </div>

            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm mb-6">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Identifiant Étudiant</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom de l'Étudiant</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Remarques</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {grades.map((student) => (
                            <tr key={student.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{student.id}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{student.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    <input
                                        type="text"
                                        value={student.score}
                                        onChange={(e) => handleScoreChange(student.id, e.target.value)}
                                        className="w-20 p-1 border border-gray-300 rounded-md text-center"
                                    />
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    <input
                                        type="text"
                                        value={student.remarks}
                                        onChange={(e) => handleRemarksChange(student.id, e.target.value)}
                                        className="w-40 p-1 border border-gray-300 rounded-md"
                                    />
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            <div className="flex flex-wrap gap-4 justify-end items-center">
                <span className={`text-sm font-semibold ${status === 'Brouillon' ? 'text-orange-500' : 'text-green-600'}`}>
                    Statut : {status}
                </span>
                <button
                    onClick={saveDraft}
                    className="bg-gray-500 text-white py-2 px-4 rounded-lg hover:bg-gray-600 transition-colors duration-200 shadow-md"
                >
                    Enregistrer le Brouillon
                </button>
                <button
                    onClick={publishGrades}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                >
                    Valider et Publier les Notes
                </button>
            </div>
        </div>
    );
};

const TeacherImportGrades = () => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [targetClass, setTargetClass] = useState('Licence 1');
    const [targetSubject, setTargetSubject] = useState('Mathématiques');
    const [targetYear, setTargetYear] = useState('2024-2025 Sem. 1');
    const [importStatus, setImportStatus] = useState('');

    const handleFileChange = (event) => {
        setSelectedFile(event.target.files[0]);
    };

    const handleImport = () => {
        if (selectedFile) {
            setImportStatus(`Importation de "${selectedFile.name}" pour ${targetClass} - ${targetSubject} (${targetYear})...`);
            // Simulate API call
            setTimeout(() => {
                setImportStatus('Importation réussie ! 30 lignes traitées, 0 erreur.');
                setSelectedFile(null);
            }, 2000);
        } else {
            setImportStatus('Veuillez choisir un fichier à importer.');
        }
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Importer les Notes (PV)</h2>
            <p className="text-gray-700 mb-4">
                Veuillez télécharger un fichier CSV ou Excel. <a href="#" className="text-blue-600 hover:underline">Télécharger le modèle ici.</a>
            </p>

            <div className="mb-6 space-y-4">
                <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Choisir un Fichier :</label>
                    <input
                        type="file"
                        onChange={handleFileChange}
                        className="block w-full text-sm text-gray-500
                                   file:mr-4 file:py-2 file:px-4
                                   file:rounded-full file:border-0
                                   file:text-sm file:font-semibold
                                   file:bg-blue-50 file:text-blue-700
                                   hover:file:bg-blue-100"
                    />
                    {selectedFile && <p className="mt-2 text-sm text-gray-600">Fichier sélectionné : {selectedFile.name}</p>}
                </div>

                <select
                    value={targetClass}
                    onChange={(e) => setTargetClass(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 w-full md:w-1/2 lg:w-1/3"
                >
                    <option value="Licence 1">Licence 1</option>
                    <option value="Licence 2">Licence 2</option>
                </select>
                <select
                    value={targetSubject}
                    onChange={(e) => setTargetSubject(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 w-full md:w-1/2 lg:w-1/3"
                >
                    <option value="Mathématiques">Mathématiques</option>
                    <option value="Physique">Physique</option>
                </select>
                <select
                    value={targetYear}
                    onChange={(e) => setTargetYear(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 w-full md:w-1/2 lg:w-1/3"
                >
                    <option value="2024-2025 Sem. 1">2024-2025 Sem. 1</option>
                    <option value="2023-2024 Sem. 2">2023-2024 Sem. 2</option>
                </select>
            </div>

            <button
                onClick={handleImport}
                className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 shadow-md"
            >
                Importer les Notes
            </button>

            {importStatus && (
                <div className="mt-6 p-4 bg-gray-100 rounded-lg border border-gray-200 text-gray-700">
                    <p className="font-semibold">Statut d'importation :</p>
                    <p>{importStatus}</p>
                    {importStatus.includes('réussie') ? (
                        <p className="text-green-600">Détails : Fichier traité avec succès.</p>
                    ) : (
                        <p className="text-red-600">Détails : Veuillez vérifier le format du fichier.</p>
                    )}
                </div>
            )}
        </div>
    );
};

const TeacherExportGrades = () => {
    const [exportClass, setExportClass] = useState('Licence 1');
    const [exportSubject, setExportSubject] = useState('Mathématiques');
    const [exportYear, setExportYear] = useState('2024-2025 Sem. 1');

    const handleGenerateExport = () => {
        alert(`Génération du fichier d'export pour ${exportClass}, ${exportSubject}, ${exportYear}... (Fonctionnalité non implémentée)`);
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Exporter les Notes</h2>
            <p className="text-gray-700 mb-4">
                Sélectionnez les critères pour générer un fichier pour le logiciel métier.
            </p>

            <div className="space-y-4 mb-6">
                <select
                    value={exportClass}
                    onChange={(e) => setExportClass(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 w-full md:w-1/2 lg:w-1/3"
                >
                    <option value="Licence 1">Licence 1</option>
                    <option value="Licence 2">Licence 2</option>
                </select>
                <select
                    value={exportSubject}
                    onChange={(e) => setExportSubject(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 w-full md:w-1/2 lg:w-1/3"
                >
                    <option value="Mathématiques">Mathématiques</option>
                    <option value="Physique">Physique</option>
                </select>
                <select
                    value={exportYear}
                    onChange={(e) => setExportYear(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 w-full md:w-1/2 lg:w-1/3"
                >
                    <option value="2024-2025 Sem. 1">2024-2025 Sem. 1</option>
                    <option value="2023-2024 Sem. 2">2023-2024 Sem. 2</option>
                </select>
            </div>

            <button
                onClick={handleGenerateExport}
                className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
            >
                Générer le Fichier d'Export
            </button>
        </div>
    );
};

const TeacherViewStudentResults = () => {
    const [filterClass, setFilterClass] = useState('Licence 1');
    const [filterSubject, setFilterSubject] = useState('Mathématiques');
    const [filterYear, setFilterYear] = useState('2024-2025 Sem. 1');
    const [searchStudent, setSearchStudent] = useState('');

    const results = dummyStudentGrades.filter(grade =>
        grade.subject.toLowerCase().includes(filterSubject.toLowerCase()) &&
        (searchStudent === '' || grade.id.toLowerCase().includes(searchStudent.toLowerCase()) || grade.subject.toLowerCase().includes(searchStudent.toLowerCase()))
    );

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Voir les Résultats des Étudiants</h2>
            <div className="flex flex-wrap gap-4 mb-6">
                <select
                    value={filterClass}
                    onChange={(e) => setFilterClass(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="Licence 1">Licence 1</option>
                    <option value="Licence 2">Licence 2</option>
                </select>
                <select
                    value={filterSubject}
                    onChange={(e) => setFilterSubject(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="Mathématiques">Mathématiques</option>
                    <option value="Physique">Physique</option>
                </select>
                <select
                    value={filterYear}
                    onChange={(e) => setFilterYear(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500"
                >
                    <option value="2024-2025 Sem. 1">2024-2025 Sem. 1</option>
                    <option value="2023-2024 Sem. 2">2023-2024 Sem. 2</option>
                </select>
                <input
                    type="text"
                    placeholder="Rechercher un Étudiant"
                    value={searchStudent}
                    onChange={(e) => setSearchStudent(e.target.value)}
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 flex-grow"
                />
            </div>
            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Identifiant Étudiant</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom de l'Étudiant</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Matière</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {results.map((grade) => (
                            <tr key={grade.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">ETU{grade.id}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">Nom Étudiant {grade.id}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.subject}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.score}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

const TeacherNotifications = StudentNotifications; // Re-use student notifications for simplicity
const TeacherProfile = StudentProfile; // Re-use student profile for simplicity

// Admin Pages
const AdminDashboard = ({ navigate }) => (
    <div className="p-6 bg-white rounded-xl shadow-lg">
        <h2 className="text-3xl font-bold text-gray-800 mb-6">Bienvenue, Administrateur !</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div className="bg-blue-50 p-6 rounded-lg shadow-inner">
                <h3 className="text-xl font-semibold text-blue-800 mb-3">Statistiques d'Aperçu du Système</h3>
                <p className="mb-2"><span className="font-medium">Total Utilisateurs :</span> 1500 (1400 Étudiants, 90 Enseignants, 10 Admins)</p>
                <p className="mb-2"><span className="font-medium">Nombre de Matières :</span> 75</p>
                <p className="mb-2"><span className="font-medium">Journal d'Activité Récente :</span> 5 nouvelles connexions aujourd'hui.</p>
            </div>
            <div className="bg-green-50 p-6 rounded-lg shadow-inner">
                <h3 className="text-xl font-semibold text-green-800 mb-3">Liens Rapides</h3>
                <div className="flex flex-col space-y-3">
                    <button
                        onClick={() => navigate('/admin/utilisateurs')}
                        className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 shadow"
                    >
                        Gérer les Utilisateurs
                    </button>
                    <button
                        onClick={() => navigate('/admin/matieres')}
                        className="bg-indigo-600 text-white py-2 px-4 rounded-lg hover:bg-indigo-700 transition-colors duration-200 shadow"
                    >
                        Gérer les Matières
                    </button>
                </div>
            </div>
        </div>
    </div>
);

const AdminUserManagement = () => {
    const [activeTab, setActiveTab] = useState('students'); // 'students', 'teachers', 'admins'
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingUser, setEditingUser] = useState(null); // null for add, object for edit

    const users = {
        students: [
            { id: 'ETU12345', name: 'Jean Dupont', email: 'jean.dupont@etu.com', role: 'Étudiant', status: 'Actif' },
            { id: 'ETU67890', name: 'Marie Curie', email: 'marie.curie@etu.com', role: 'Étudiant', status: 'Actif' },
        ],
        teachers: dummyTeachers,
        admins: [
            { id: 'ADM001', name: 'Admin Principal', email: 'admin@univ.com', role: 'Administrateur', status: 'Actif' },
        ],
    };

    const openModal = (user = null) => {
        setEditingUser(user);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingUser(null);
    };

    const handleSaveUser = (userData) => {
        // In a real app, send to backend to add/update user
        console.log('Saving user:', userData);
        closeModal();
    };

    const renderUserTable = (userList) => (
        <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
            <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                    <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Identifiant Utilisateur</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Email</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Rôle</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                    {userList.map((user) => (
                        <tr key={user.id}>
                            <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{user.id}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.name}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.email}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{user.role}</td>
                            <td className="px-6 py-4 whitespace-nowrap text-sm">
                                <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${user.status === 'Actif' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                    {user.status}
                                </span>
                            </td>
                            <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                <div className="flex space-x-2">
                                    <button onClick={() => openModal(user)} className="text-blue-600 hover:text-blue-900">Modifier</button>
                                    <button onClick={() => alert(`Voir détails de ${user.name}`)} className="text-indigo-600 hover:text-indigo-900">Voir Détails</button>
                                    <button onClick={() => alert(`Activer/Désactiver ${user.name}`)} className="text-yellow-600 hover:text-yellow-900">Activer/Désactiver</button>
                                    <button onClick={() => alert(`Réinitialiser mot de passe de ${user.name}`)} className="text-red-600 hover:text-red-900">Réinitialiser Mot de Passe</button>
                                </div>
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Gestion des Utilisateurs</h2>
            <div className="mb-6">
                <div className="flex border-b border-gray-200">
                    <button
                        onClick={() => setActiveTab('students')}
                        className={`py-2 px-4 text-sm font-medium ${activeTab === 'students' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        Étudiants
                    </button>
                    <button
                        onClick={() => setActiveTab('teachers')}
                        className={`py-2 px-4 text-sm font-medium ${activeTab === 'teachers' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        Enseignants
                    </button>
                    <button
                        onClick={() => setActiveTab('admins')}
                        className={`py-2 px-4 text-sm font-medium ${activeTab === 'admins' ? 'border-b-2 border-blue-600 text-blue-600' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        Administrateurs
                    </button>
                </div>
            </div>

            <div className="flex justify-between items-center mb-4">
                <input
                    type="text"
                    placeholder="Rechercher/Filtrer les utilisateurs"
                    className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 flex-grow mr-4"
                />
                <button
                    onClick={() => openModal()}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                >
                    Ajouter un Nouvel Utilisateur
                </button>
            </div>

            {activeTab === 'students' && renderUserTable(users.students)}
            {activeTab === 'teachers' && renderUserTable(users.teachers)}
            {activeTab === 'admins' && renderUserTable(users.admins)}

            {isModalOpen && (
                <UserFormModal
                    user={editingUser}
                    onSave={handleSaveUser}
                    onClose={closeModal}
                    currentRole={activeTab.slice(0, -1)} // 'student', 'teacher', 'admin'
                />
            )}
        </div>
    );
};

const UserFormModal = ({ user, onSave, onClose, currentRole }) => {
    const [name, setName] = useState(user?.name || '');
    const [email, setEmail] = useState(user?.email || '');
    const [id, setId] = useState(user?.id || '');
    const [role, setRole] = useState(user?.role || (currentRole === 'student' ? 'Étudiant' : currentRole === 'teacher' ? 'Enseignant' : 'Administrateur'));
    const [password, setPassword] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave({ id, name, email, role, password: password || undefined });
    };

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-2xl p-8 w-full max-w-lg relative">
                <h3 className="text-2xl font-bold text-gray-800 mb-6">{user ? 'Modifier l\'Utilisateur' : 'Ajouter un Nouvel Utilisateur'}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Nom</label>
                        <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Email</label>
                        <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Identifiant</label>
                        <input type="text" value={id} onChange={(e) => setId(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Rôle</label>
                        <select value={role} onChange={(e) => setRole(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2">
                            <option value="Étudiant">Étudiant</option>
                            <option value="Enseignant">Enseignant</option>
                            <option value="Administrateur">Administrateur</option>
                        </select>
                    </div>
                    {!user && ( // Only show password field for new users
                        <div>
                            <label className="block text-sm font-medium text-gray-700">Mot de Passe Initial</label>
                            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required={!user} />
                        </div>
                    )}
                    <div className="flex justify-end space-x-3 mt-6">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400 transition-colors duration-200">
                            Annuler
                        </button>
                        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-200">
                            {user ? 'Mettre à Jour' : 'Ajouter'}
                        </button>
                    </div>
                </form>
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-xl font-bold">&times;</button>
            </div>
        </div>
    );
};

const AdminSubjectManagement = () => {
    const [subjects, setSubjects] = useState(dummySubjects);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingSubject, setEditingSubject] = useState(null);

    const openModal = (subject = null) => {
        setEditingSubject(subject);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingSubject(null);
    };

    const handleSaveSubject = (subjectData) => {
        if (editingSubject) {
            setSubjects(subjects.map(s => s.id === subjectData.id ? subjectData : s));
        } else {
            setSubjects([...subjects, { ...subjectData, id: `NEW${subjects.length + 1}` }]); // Simple ID generation
        }
        closeModal();
    };

    const handleDeleteSubject = (id) => {
        if (window.confirm('Êtes-vous sûr de vouloir supprimer cette matière ?')) {
            setSubjects(subjects.filter(s => s.id !== id));
        }
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Gestion des Matières</h2>
            <div className="flex justify-end mb-4">
                <button
                    onClick={() => openModal()}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                >
                    Ajouter une Nouvelle Matière
                </button>
            </div>

            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Code Matière</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom de la Matière</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {subjects.map((subject) => (
                            <tr key={subject.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{subject.id}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{subject.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <div className="flex space-x-2">
                                        <button onClick={() => openModal(subject)} className="text-blue-600 hover:text-blue-900">Modifier</button>
                                        <button onClick={() => handleDeleteSubject(subject.id)} className="text-red-600 hover:text-red-900">Supprimer</button>
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {isModalOpen && (
                <SubjectFormModal
                    subject={editingSubject}
                    onSave={handleSaveSubject}
                    onClose={closeModal}
                />
            )}
        </div>
    );
};

const SubjectFormModal = ({ subject, onSave, onClose }) => {
    const [code, setCode] = useState(subject?.id || '');
    const [name, setName] = useState(subject?.name || '');
    const [description, setDescription] = useState(''); // Wireframe mentions description field

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave({ id: code, name, description });
    };

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-2xl p-8 w-full max-w-lg relative">
                <h3 className="text-2xl font-bold text-gray-800 mb-6">{subject ? 'Modifier la Matière' : 'Ajouter une Nouvelle Matière'}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Code Matière</label>
                        <input type="text" value={code} onChange={(e) => setCode(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Nom de la Matière</label>
                        <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Description (Optionnel)</label>
                        <textarea value={description} onChange={(e) => setDescription(e.target.value)} rows="3" className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"></textarea>
                    </div>
                    <div className="flex justify-end space-x-3 mt-6">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400 transition-colors duration-200">
                            Annuler
                        </button>
                        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-200">
                            {subject ? 'Mettre à Jour' : 'Ajouter'}
                        </button>
                    </div>
                </form>
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-xl font-bold">&times;</button>
            </div>
        </div>
    );
};

const AdminAcademicSessionsManagement = () => {
    const [sessions, setSessions] = useState(dummySessions);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingSession, setEditingSession] = useState(null);

    const openModal = (session = null) => {
        setEditingSession(session);
        setIsModalOpen(true);
    };

    const closeModal = () => {
        setIsModalOpen(false);
        setEditingSession(null);
    };

    const handleSaveSession = (sessionData) => {
        if (editingSession) {
            setSessions(sessions.map(s => s.id === sessionData.id ? sessionData : s));
        } else {
            setSessions([...sessions, { ...sessionData, id: `S${sessions.length + 1}` }]); // Simple ID generation
        }
        closeModal();
    };

    const handleArchiveSession = (id) => {
        setSessions(sessions.map(s => s.id === id ? { ...s, status: 'Archivée' } : s));
        alert('Session archivée !');
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Gestion des Sessions Académiques</h2>
            <div className="flex justify-end mb-4">
                <button
                    onClick={() => openModal()}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                >
                    Ajouter une Nouvelle Session
                </button>
            </div>

            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom de la Session</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date de Début</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date de Fin</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {sessions.map((session) => (
                            <tr key={session.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{session.name}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{session.startDate}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{session.endDate}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm">
                                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${session.status === 'Active' ? 'bg-green-100 text-green-800' : session.status === 'À venir' ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'}`}>
                                        {session.status}
                                    </span>
                                </td>
                                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <div className="flex space-x-2">
                                        <button onClick={() => openModal(session)} className="text-blue-600 hover:text-blue-900">Modifier</button>
                                        {session.status !== 'Archivée' && (
                                            <button onClick={() => handleArchiveSession(session.id)} className="text-orange-600 hover:text-orange-900">Archiver</button>
                                        )}
                                    </div>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>

            {isModalOpen && (
                <SessionFormModal
                    session={editingSession}
                    onSave={handleSaveSession}
                    onClose={closeModal}
                />
            )}
        </div>
    );
};

const SessionFormModal = ({ session, onSave, onClose }) => {
    const [name, setName] = useState(session?.name || '');
    const [startDate, setStartDate] = useState(session?.startDate || '');
    const [endDate, setEndDate] = useState(session?.endDate || '');

    const handleSubmit = (e) => {
        e.preventDefault();
        onSave({ id: session?.id, name, startDate, endDate, status: session?.status || 'Active' });
    };

    return (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-75 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-xl shadow-2xl p-8 w-full max-w-lg relative">
                <h3 className="text-2xl font-bold text-gray-800 mb-6">{session ? 'Modifier la Session' : 'Ajouter une Nouvelle Session'}</h3>
                <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Nom de la Session</label>
                        <input type="text" value={name} onChange={(e) => setName(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Date de Début</label>
                        <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-gray-700">Date de Fin</label>
                        <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" required />
                    </div>
                    <div className="flex justify-end space-x-3 mt-6">
                        <button type="button" onClick={onClose} className="px-4 py-2 bg-gray-300 text-gray-800 rounded-md hover:bg-gray-400 transition-colors duration-200">
                            Annuler
                        </button>
                        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors duration-200">
                            {session ? 'Mettre à Jour' : 'Ajouter'}
                        </button>
                    </div>
                </form>
                <button onClick={onClose} className="absolute top-4 right-4 text-gray-500 hover:text-gray-700 text-xl font-bold">&times;</button>
            </div>
        </div>
    );
};

const AdminGradesPVManagement = () => {
    const [filterTeacher, setFilterTeacher] = useState('');
    const [filterStudent, setFilterStudent] = useState('');
    const [filterSubject, setFilterSubject] = useState('');
    const [filterSession, setFilterSession] = useState('');

    const dummyGrades = [
        { id: 1, studentId: 'ETU12345', studentName: 'Jean Dupont', subject: 'Mathématiques', score: '15/20', teacher: 'Mme. Martin', session: '2024-2025 Sem. 1', status: 'Publié' },
        { id: 2, studentId: 'ETU67890', studentName: 'Marie Curie', subject: 'Physique', score: '17/20', teacher: 'M. Leclerc', session: '2024-2025 Sem. 1', status: 'Publié' },
        { id: 3, studentId: 'ETU11223', studentName: 'Pierre Martin', subject: 'Informatique', score: '10/20', teacher: 'Mme. Dubois', session: '2024-2025 Sem. 1', status: 'Brouillon' },
    ];

    const dummyImportLogs = [
        { id: 1, filename: 'notes_math_L1_2024.csv', status: 'Succès', date: '2024-05-15 10:00', teacher: 'Mme. Martin', errors: 'Aucune' },
        { id: 2, filename: 'notes_physique_L2_2024.xlsx', status: 'Échec', date: '2024-05-14 14:20', teacher: 'M. Leclerc', errors: 'Ligne 5: format de note invalide' },
    ];

    const filteredGrades = dummyGrades.filter(grade => {
        return (filterTeacher === '' || grade.teacher.includes(filterTeacher)) &&
               (filterStudent === '' || grade.studentName.includes(filterStudent) || grade.studentId.includes(filterStudent)) &&
               (filterSubject === '' || grade.subject.includes(filterSubject)) &&
               (filterSession === '' || grade.session.includes(filterSession));
    });

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Gestion des Notes et PV</h2>

            <div className="mb-8">
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">Aperçu des Notes</h3>
                <div className="flex flex-wrap gap-4 mb-6">
                    <input type="text" placeholder="Filtrer par Enseignant" value={filterTeacher} onChange={(e) => setFilterTeacher(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 flex-grow" />
                    <input type="text" placeholder="Filtrer par Étudiant" value={filterStudent} onChange={(e) => setFilterStudent(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 flex-grow" />
                    <input type="text" placeholder="Filtrer par Matière" value={filterSubject} onChange={(e) => setFilterSubject(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 flex-grow" />
                    <input type="text" placeholder="Filtrer par Session" value={filterSession} onChange={(e) => setFilterSession(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 flex-grow" />
                </div>
                <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Identifiant Étudiant</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Nom Étudiant</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Matière</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Note</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Enseignant</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Session</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredGrades.map((grade) => (
                                <tr key={grade.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{grade.studentId}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.studentName}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.subject}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.score}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.teacher}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{grade.session}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${grade.status === 'Publié' ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'}`}>
                                            {grade.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <div className="flex space-x-2">
                                            <button onClick={() => alert(`Modifier note de ${grade.studentName}`)} className="text-blue-600 hover:text-blue-900">Modifier</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>

            <div>
                <h3 className="text-2xl font-semibold text-gray-800 mb-4">Aperçu des Importations de PV</h3>
                <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                    <table className="min-w-full divide-y divide-gray-200">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fichier</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Enseignant</th>
                                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Détails des Erreurs</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {dummyImportLogs.map((log) => (
                                <tr key={log.id}>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{log.filename}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${log.status === 'Succès' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                                            {log.status}
                                        </span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.date}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.teacher}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.errors}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

const AdminSystemLogs = () => {
    const [filterDateRange, setFilterDateRange] = useState('');
    const [filterUser, setFilterUser] = useState('');
    const [filterActionType, setFilterActionType] = useState('');

    const dummyLogs = [
        { id: 1, timestamp: '2024-05-30 10:00:00', user: 'ADM001', type: 'Connexion', description: 'Connexion réussie de l\'administrateur' },
        { id: 2, timestamp: '2024-05-30 10:05:15', user: 'T001', type: 'Modification', description: 'Notes publiées pour Mathématiques L1' },
        { id: 3, timestamp: '2024-05-29 16:30:00', user: 'ETU12345', type: 'Consultation', description: 'Consultation du relevé de notes' },
        { id: 4, timestamp: '2024-05-29 09:00:00', user: 'ADM001', type: 'Erreur', description: 'Échec d\'importation de fichier PV' },
    ];

    const filteredLogs = dummyLogs.filter(log => {
        return (filterUser === '' || log.user.includes(filterUser)) &&
               (filterActionType === '' || log.type.includes(filterActionType)) &&
               (filterDateRange === '' || log.timestamp.includes(filterDateRange.split(' ')[0])); // Simple date filter
    });

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Journaux d'Audit Système</h2>
            <div className="flex flex-wrap gap-4 mb-6">
                <input type="date" value={filterDateRange} onChange={(e) => setFilterDateRange(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500" />
                <input type="text" placeholder="Filtrer par Utilisateur" value={filterUser} onChange={(e) => setFilterUser(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500 flex-grow" />
                <select value={filterActionType} onChange={(e) => setFilterActionType(e.target.value)} className="p-2 border border-gray-300 rounded-md focus:ring-blue-500 focus:border-blue-500">
                    <option value="">Tous les types</option>
                    <option value="Connexion">Connexion</option>
                    <option value="Modification">Modification</option>
                    <option value="Consultation">Consultation</option>
                    <option value="Erreur">Erreur</option>
                </select>
            </div>
            <div className="overflow-x-auto rounded-lg border border-gray-200 shadow-sm">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Horodatage</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Utilisateur</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type d'Action</th>
                            <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Description</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {filteredLogs.map((log) => (
                            <tr key={log.id}>
                                <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{log.timestamp}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.user}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.type}</td>
                                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{log.description}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </div>
    );
};

const AdminNotificationManagement = () => {
    const [emailTemplate, setEmailTemplate] = useState('Bonjour {NomUtilisateur},\n\nDe nouvelles notes ont été publiées pour {Matière}.\n\nCordialement,\nL\'équipe académique');
    const [smsTemplate, setSmsTemplate] = useState('Nouvelles notes pour {Matière} publiées. Consultez la plateforme.');
    const [announcementMessage, setAnnouncementMessage] = useState('');
    const [targetGroup, setTargetGroup] = useState('all');

    const handleSaveTemplates = () => {
        alert('Modèles de notification sauvegardés !');
    };

    const handleSendAnnouncement = () => {
        if (announcementMessage.trim()) {
            alert(`Annonce envoyée à "${targetGroup}" : "${announcementMessage}"`);
            setAnnouncementMessage('');
        } else {
            alert('Veuillez saisir un message pour l\'annonce.');
        }
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Gestion des Notifications</h2>

            <div className="mb-8 border border-gray-200 rounded-lg p-6 bg-gray-50">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Configurer les Modèles</h3>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="email-template" className="block text-sm font-medium text-gray-700">Modèle d'Email</label>
                        <textarea
                            id="email-template"
                            rows="6"
                            value={emailTemplate}
                            onChange={(e) => setEmailTemplate(e.target.value)}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                        ></textarea>
                        <p className="text-xs text-gray-500 mt-1">Variables disponibles : {'{NomUtilisateur}'}, {'{Matière}'}</p>
                    </div>
                    <div>
                        <label htmlFor="sms-template" className="block text-sm font-medium text-gray-700">Modèle SMS</label>
                        <textarea
                            id="sms-template"
                            rows="3"
                            value={smsTemplate}
                            onChange={(e) => setSmsTemplate(e.target.value)}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                        ></textarea>
                        <p className="text-xs text-gray-500 mt-1">Variables disponibles : {'{Matière}'}</p>
                    </div>
                    <button
                        onClick={handleSaveTemplates}
                        className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                    >
                        Sauvegarder les Modèles
                    </button>
                </div>
            </div>

            <div className="border border-gray-200 rounded-lg p-6 bg-gray-50">
                <h3 className="text-xl font-semibold text-gray-800 mb-4">Envoyer une Annonce Globale</h3>
                <div className="space-y-4">
                    <div>
                        <label htmlFor="announcement-message" className="block text-sm font-medium text-gray-700">Message de l'Annonce</label>
                        <textarea
                            id="announcement-message"
                            rows="4"
                            value={announcementMessage}
                            onChange={(e) => setAnnouncementMessage(e.target.value)}
                            className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2"
                            placeholder="Saisissez votre annonce ici..."
                        ></textarea>
                    </div>
                    <div>
                        <label htmlFor="target-group" className="block text-sm font-medium text-gray-700">Cible</label>
                        <select
                            id="target-group"
                            value={targetGroup}
                            onChange={(e) => setTargetGroup(e.target.value)}
                            className="mt-1 block w-full md:w-1/2 border border-gray-300 rounded-md shadow-sm p-2"
                        >
                            <option value="all">Tous les utilisateurs</option>
                            <option value="students">Étudiants</option>
                            <option value="teachers">Enseignants</option>
                            <option value="admins">Administrateurs</option>
                        </select>
                    </div>
                    <button
                        onClick={handleSendAnnouncement}
                        className="bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700 transition-colors duration-200 shadow-md"
                    >
                        Envoyer l'Annonce
                    </button>
                </div>
            </div>
        </div>
    );
};

const AdminSystemSettings = () => {
    const [currentAcademicYear, setCurrentAcademicYear] = useState('2024-2025');
    const [passwordPolicy, setPasswordPolicy] = useState('minimum 8 caractères, 1 majuscule, 1 chiffre');
    const [smtpHost, setSmtpHost] = useState('smtp.example.com');

    const handleSaveChanges = () => {
        alert('Paramètres système sauvegardés !');
    };

    return (
        <div className="p-6 bg-white rounded-xl shadow-lg">
            <h2 className="text-3xl font-bold text-gray-800 mb-6">Paramètres Système</h2>

            <div className="space-y-6">
                <div className="border border-gray-200 rounded-lg p-6 bg-gray-50">
                    <h3 className="text-xl font-semibold text-gray-800 mb-4">Configuration Générale</h3>
                    <div className="space-y-3">
                        <div>
                            <label htmlFor="current-year" className="block text-sm font-medium text-gray-700">Année Académique en Cours</label>
                            <input type="text" id="current-year" value={currentAcademicYear} onChange={(e) => setCurrentAcademicYear(e.target.value)} className="mt-1 block w-full md:w-1/2 border border-gray-300 rounded-md shadow-sm p-2" />
                        </div>
                        <div>
                            <label htmlFor="password-policy" className="block text-sm font-medium text-gray-700">Politique de Mot de Passe</label>
                            <input type="text" id="password-policy" value={passwordPolicy} onChange={(e) => setPasswordPolicy(e.target.value)} className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm p-2" />
                        </div>
                    </div>
                </div>

                <div className="border border-gray-200 rounded-lg p-6 bg-gray-50">
                    <h3 className="text-xl font-semibold text-gray-800 mb-4">Paramètres d'Intégration</h3>
                    <div className="space-y-3">
                        <div>
                            <label htmlFor="smtp-host" className="block text-sm font-medium text-gray-700">Hôte SMTP (pour les emails)</label>
                            <input type="text" id="smtp-host" value={smtpHost} onChange={(e) => setSmtpHost(e.target.value)} className="mt-1 block w-full md:w-1/2 border border-gray-300 rounded-md shadow-sm p-2" />
                        </div>
                        {/* Add more integration settings like SMS gateway if needed */}
                    </div>
                </div>

                <button
                    onClick={handleSaveChanges}
                    className="bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700 transition-colors duration-200 shadow-md"
                >
                    Sauvegarder les Changements
                </button>
            </div>
        </div>
    );
};

const AdminProfile = StudentProfile; // Re-use student profile for simplicity

// Main App Component
const App = () => {
    const [userRole, setUserRole] = useState('public'); // 'public', 'student', 'teacher', 'admin'
    const [userName, setUserName] = useState('');
    const [currentPath, setCurrentPath] = useState('/connexion');

    // Effect to handle initial routing and Firebase auth state
    useEffect(() => {
        // This effect runs once on component mount
        // In a real app, you'd check for a persistent login session here
        // For this demo, we start at login page
        setCurrentPath('/connexion');

        // Firebase auth listener
        if (auth) {
            const unsubscribe = onAuthStateChanged(auth, (user) => {
                if (user) {
                    console.log("Firebase user authenticated:", user.uid);
                    // You might fetch user role from Firestore here based on user.uid
                    // For now, we'll rely on the simulated login
                } else {
                    console.log("Firebase user logged out or not authenticated.");
                }
            });
            return () => unsubscribe(); // Cleanup listener on unmount
        }
    }, []);

    const handleLogin = (role, name) => {
        setUserRole(role);
        setUserName(name);
        // Navigate to the appropriate dashboard after login
        switch (role) {
            case 'student': setCurrentPath('/etudiant/tableau-de-bord'); break;
            case 'teacher': setCurrentPath('/enseignant/tableau-de-bord'); break;
            case 'admin': setCurrentPath('/admin/tableau-de-bord'); break;
            default: setCurrentPath('/connexion'); break;
        }
    };

    const handleLogout = async () => {
        try {
            if (auth) {
                await signOut(auth);
                console.log("User signed out from Firebase.");
            }
        } catch (error) {
            console.error("Error signing out from Firebase:", error);
        }
        setUserRole('public');
        setUserName('');
        setCurrentPath('/connexion');
    };

    const navigate = (path) => {
        setCurrentPath(path);
    };

    const renderContent = () => {
        switch (currentPath) {
            case '/connexion':
                return <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/etudiant/tableau-de-bord':
                return userRole === 'student' ? <StudentDashboard userName={userName} navigate={navigate} /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/etudiant/notes':
                return userRole === 'student' ? <StudentGrades /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/etudiant/releves':
                return userRole === 'student' ? <StudentTranscripts /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/etudiant/historique':
                return userRole === 'student' ? <StudentGradeHistory /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/etudiant/notifications':
                return userRole === 'student' ? <StudentNotifications /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/etudiant/profil':
                return userRole === 'student' ? <StudentProfile /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;

            case '/enseignant/tableau-de-bord':
                return userRole === 'teacher' ? <TeacherDashboard userName={userName} navigate={navigate} /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/enseignant/notes/gestion':
                return userRole === 'teacher' ? <TeacherManageGrades /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/enseignant/notes/import':
                return userRole === 'teacher' ? <TeacherImportGrades /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/enseignant/notes/export':
                return userRole === 'teacher' ? <TeacherExportGrades /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/enseignant/resultats/voir':
                return userRole === 'teacher' ? <TeacherViewStudentResults /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/enseignant/notifications':
                return userRole === 'teacher' ? <TeacherNotifications /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/enseignant/profil':
                return userRole === 'teacher' ? <TeacherProfile /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;

            case '/admin/tableau-de-bord':
                return userRole === 'admin' ? <AdminDashboard navigate={navigate} /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/utilisateurs':
                return userRole === 'admin' ? <AdminUserManagement /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/matieres':
                return userRole === 'admin' ? <AdminSubjectManagement /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/sessions':
                return userRole === 'admin' ? <AdminAcademicSessionsManagement /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/notes-pv':
                return userRole === 'admin' ? <AdminGradesPVManagement /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/journaux':
                return userRole === 'admin' ? <AdminSystemLogs /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/notifications-config':
                return userRole === 'admin' ? <AdminNotificationManagement /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/parametres':
                return userRole === 'admin' ? <AdminSystemSettings /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;
            case '/admin/profil':
                return userRole === 'admin' ? <AdminProfile /> : <LoginPage onLogin={handleLogin} navigate={navigate} />;

            default:
                return <LoginPage onLogin={handleLogin} navigate={navigate} />;
        }
    };

    return (
        <div className="min-h-screen flex flex-col font-inter bg-gray-100">
            <style>
                {`
                @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
                body {
                    font-family: 'Inter', sans-serif;
                }
                `}
            </style>
            <Header userName={userName} userRole={userRole} onLogout={handleLogout} currentPath={currentPath} navigate={navigate} />
            <main className="flex-grow flex flex-col md:flex-row p-4">
                {userRole !== 'public' && (
                    <div className="w-full md:w-64 mb-4 md:mb-0 md:mr-4 flex-shrink-0">
                        <SidebarNav userRole={userRole} currentPath={currentPath} navigate={navigate} />
                    </div>
                )}
                <div className="flex-grow bg-white p-6 rounded-xl shadow-lg">
                    {renderContent()}
                    {/* Display currentUserId for debugging/demonstration if needed */}
                    {userRole !== 'public' && <p className="mt-4 text-xs text-gray-500">ID Utilisateur (Firebase): {currentUserId}</p>}
                </div>
            </main>
            <Footer />
        </div>
    );
};

export default App;
