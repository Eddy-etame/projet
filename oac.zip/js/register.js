// register.js
async function handleRegistration(event) {
    event.preventDefault();
    
    const formData = {
        nom_utilisateur: document.querySelector('input[name="nom_utilisateur"]').value,
        prenom: document.querySelector('input[name="prenom"]').value,
        nom: document.querySelector('input[name="nom"]').value,
        email: document.querySelector('input[type="email"]').value,
        mot_de_passe: document.querySelector('input[type="password"]').value,
        id_role: document.querySelector('select[name="id_role"]').value,
        est_actif: true,
        date_creation: new Date().toISOString()
    };

    try {
        const response = await fetch('/api/auth/register', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(formData)
        });

        if (response.ok) {
            // Log the registration action in Journaux_Actions
            await logUserAction('Registration', 'User registration successful');
            window.location.href = '/login';
        } else {
            throw new Error('Registration failed');
        }
    } catch (error) {
        console.error('Registration error:', error);
        // Show error to user
    }
}

// Action logging function
async function logUserAction(type_action, details_action) {
    try {
        await fetch('/api/log-action', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                type_action,
                details_action
            })
        });
    } catch (error) {
        console.error('Error logging action:', error);
    }
}