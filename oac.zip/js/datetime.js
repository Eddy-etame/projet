// js/datetime.js
// Updates the #currentDateTime element with the current date and time using Day.js
function updateDateTime() {
    var el = document.getElementById('currentDateTime');
    if (el && window.dayjs) {
        el.textContent = dayjs().format('dddd, MMMM D, YYYY - HH:mm:ss');
    }
}
setInterval(updateDateTime, 1000);
document.addEventListener('DOMContentLoaded', updateDateTime);
