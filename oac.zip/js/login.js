// login.js
async function handleLogin(event) {
    event.preventDefault();
    
    const email = document.querySelector('input[type="email"]').value;
    const password = document.querySelector('input[type="password"]').value;
    const roleSelect = document.querySelector('select').value;

    try {
        const response = await fetch('/api/auth/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email,
                password,
                role: roleSelect
            })
        });

        if (response.ok) {
            const userData = await response.json();
            // Store user session data
            sessionStorage.setItem('user', JSON.stringify({
                id_utilisateur: userData.id_utilisateur,
                nom_utilisateur: userData.nom_utilisateur,
                id_role: userData.id_role,
                est_actif: userData.est_actif
            }));
            
            // Redirect based on role
            window.location.href = `/${roleSelect}/Dashboard.php`;
        } else {
            throw new Error('Login failed');
        }
    } catch (error) {
        console.error('Authentication error:', error);
        // Show error to user
    }
}