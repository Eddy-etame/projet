<?php
require_once '../includes/db.php';
require_once '../includes/middleware.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$user_role = $_SESSION['role'];

// Get list of potential recipients based on role
try {
    // Teachers can message teachers and students
    // Students can message teachers and fellow students
    $query = "SELECT id_utilisateur, nom, email, role 
              FROM Utilisateurs 
              WHERE id_utilisateur != ? 
              ORDER BY role, nom";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param('i', $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $users = $result->fetch_all(MYSQLI_ASSOC);
} catch (Exception $e) {
    $_SESSION['error'] = $e->getMessage();
    header('Location: ' . ($user_role === 'teacher' ? '../teacher/TDashboard.php' : '../student/SDashboard.php'));
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Envoyer un message - OAC</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">
    <link rel="stylesheet" href="../css/shared-dashboard.css">
    <style>
        .message-container {
            max-width: 1000px;
            margin: 20px auto;
            padding: 20px;
            display: grid;
            grid-template-columns: 300px 1fr;
            gap: 20px;
        }

        .recipients-list {
            background: var(--white);
            border-radius: 12px;
            box-shadow: var(--shadow);
            padding: 20px;
            height: fit-content;
        }

        .message-form {
            background: var(--white);
            border-radius: 12px;
            box-shadow: var(--shadow);
            padding: 20px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: var(--text-dark);
            font-weight: 600;
        }

        .form-group select,
        .form-group input[type="text"],
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            background: var(--white);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 200px;
        }

        .recipient-group {
            margin-bottom: 15px;
        }

        .recipient-group-title {
            font-weight: 600;
            color: var(--text-dark);
            margin-bottom: 10px;
            padding-bottom: 5px;
            border-bottom: 2px solid var(--accent);
        }

        .recipient-list {
            max-height: 300px;
            overflow-y: auto;
        }

        .recipient-item {
            padding: 8px;
            margin-bottom: 5px;
            border-radius: 4px;
            cursor: pointer;
            transition: all 0.2s;
        }

        .recipient-item:hover {
            background: var(--light-bg);
        }

        .recipient-item.selected {
            background: var(--accent);
            color: var(--white);
        }

        .recipient-name {
            font-weight: 500;
        }

        .recipient-email {
            font-size: 0.9em;
            color: inherit;
            opacity: 0.8;
        }

        .btn-send {
            background: var(--accent);
            color: var(--white);
            padding: 12px 24px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-weight: 600;
            transition: background 0.2s;
            width: 100%;
        }

        .btn-send:hover {
            background: var(--secondary);
        }

        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .search-box {
            margin-bottom: 15px;
        }

        .search-input {
            width: 100%;
            padding: 8px;
            border: 1px solid var(--border-color);
            border-radius: 4px;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>
    <div class="message-container">
        <div class="recipients-list">
            <h2>Destinataires</h2>
            <div class="search-box">
                <input type="text" class="search-input" placeholder="Rechercher un utilisateur..." onkeyup="filterRecipients(this.value)">
            </div>

            <?php
            $teachers = array_filter($users, function($user) { return $user['role'] === 'teacher'; });
            $students = array_filter($users, function($user) { return $user['role'] === 'student'; });
            ?>

            <?php if (!empty($teachers)): ?>
            <div class="recipient-group" id="teachers-group">
                <div class="recipient-group-title">Professeurs</div>
                <div class="recipient-list">
                    <?php foreach ($teachers as $teacher): ?>
                        <div class="recipient-item" onclick="selectRecipient(this, <?php echo $teacher['id_utilisateur']; ?>)" data-search="<?php echo strtolower($teacher['nom'] . ' ' . $teacher['email']); ?>">
                            <div class="recipient-name"><?php echo htmlspecialchars($teacher['nom']); ?></div>
                            <div class="recipient-email"><?php echo htmlspecialchars($teacher['email']); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($students)): ?>
            <div class="recipient-group" id="students-group">
                <div class="recipient-group-title">Étudiants</div>
                <div class="recipient-list">
                    <?php foreach ($students as $student): ?>
                        <div class="recipient-item" onclick="selectRecipient(this, <?php echo $student['id_utilisateur']; ?>)" data-search="<?php echo strtolower($student['nom'] . ' ' . $student['email']); ?>">
                            <div class="recipient-name"><?php echo htmlspecialchars($student['nom']); ?></div>
                            <div class="recipient-email"><?php echo htmlspecialchars($student['email']); ?></div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>

        <div class="message-form">
            <h2>Nouveau Message</h2>
            
            <?php if (isset($_SESSION['success'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success'];
                    unset($_SESSION['success']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error'])): ?>
                <div class="alert alert-error">
                    <?php 
                    echo $_SESSION['error'];
                    unset($_SESSION['error']);
                    ?>
                </div>
            <?php endif; ?>

            <form id="messageForm" onsubmit="return sendMessage(event)">
                <input type="hidden" name="recipient_id" id="recipient_id" required>
                
                <div class="form-group">
                    <label for="subject">Sujet</label>
                    <input type="text" name="subject" id="subject" required>
                </div>

                <div class="form-group">
                    <label for="content">Message</label>
                    <textarea name="content" id="content" required></textarea>
                </div>

                <button type="submit" class="btn-send">Envoyer le message</button>
            </form>
        </div>
    </div>

    <script>
    let selectedRecipient = null;

    function selectRecipient(element, recipientId) {
        // Remove previous selection
        const previousSelected = document.querySelector('.recipient-item.selected');
        if (previousSelected) {
            previousSelected.classList.remove('selected');
        }

        // Add selection to clicked element
        element.classList.add('selected');
        selectedRecipient = recipientId;
        document.getElementById('recipient_id').value = recipientId;
    }

    function filterRecipients(searchTerm) {
        searchTerm = searchTerm.toLowerCase();
        const items = document.querySelectorAll('.recipient-item');
        
        items.forEach(item => {
            const searchText = item.getAttribute('data-search');
            if (searchText.includes(searchTerm)) {
                item.style.display = '';
            } else {
                item.style.display = 'none';
            }
        });

        // Show/hide group titles based on visible children
        document.querySelectorAll('.recipient-group').forEach(group => {
            const hasVisibleChildren = Array.from(group.querySelectorAll('.recipient-item'))
                .some(item => item.style.display !== 'none');
            group.style.display = hasVisibleChildren ? '' : 'none';
        });
    }

    async function sendMessage(event) {
        event.preventDefault();
        
        if (!selectedRecipient) {
            showAlert('Veuillez sélectionner un destinataire', 'error');
            return false;
        }

        const form = event.target;
        const formData = new FormData(form);
        
        try {
            const response = await fetch('../teacher/send_message.php', {
                method: 'POST',
                body: formData
            });
            
            const data = await response.json();
            if (data.success) {
                form.reset();
                document.querySelector('.recipient-item.selected')?.classList.remove('selected');
                selectedRecipient = null;
                showAlert('Message envoyé avec succès', 'success');
            } else {
                throw new Error(data.error || 'Erreur lors de l\'envoi du message');
            }
        } catch (error) {
            showAlert(error.message, 'error');
        }
        
        return false;
    }

    function showAlert(message, type) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type}`;
        alert.textContent = message;
        
        const form = document.getElementById('messageForm');
        form.parentNode.insertBefore(alert, form);
        
        setTimeout(() => {
            alert.remove();
        }, 3000);
    }
    </script>
</body>
</html> 