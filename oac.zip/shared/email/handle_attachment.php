<?php
require_once __DIR__ . '/../../auth/middleware.php';
require_once __DIR__ . '/../../shared/error_logger.php';

class AttachmentHandler {
    private $upload_dir;
    private $max_size = 5242880; // 5MB
    private $allowed_types = ['image/jpeg', 'image/png', 'application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'];
    
    public function __construct() {
        $this->upload_dir = __DIR__ . '/../../uploads/email_attachments/';
        if (!file_exists($this->upload_dir)) {
            mkdir($this->upload_dir, 0755, true);
        }
    }
    
    public function handleUpload($file) {
        try {
            $this->validateFile($file);
            
            $filename = $this->generateUniqueFilename($file['name']);
            $filepath = $this->upload_dir . $filename;
            
            if (!move_uploaded_file($file['tmp_name'], $filepath)) {
                throw new Exception('Failed to move uploaded file.');
            }
            
            return [
                'success' => true,
                'filepath' => 'uploads/email_attachments/' . $filename,
                'filename' => $filename
            ];
            
        } catch (Exception $e) {
            logError('Attachment upload error', ['error' => $e->getMessage()]);
            return [
                'success' => false,
                'error' => $e->getMessage()
            ];
        }
    }
    
    private function validateFile($file) {
        if (!isset($file['error']) || is_array($file['error'])) {
            throw new Exception('Invalid parameters.');
        }
        
        switch ($file['error']) {
            case UPLOAD_ERR_OK:
                break;
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                throw new Exception('File too large.');
            case UPLOAD_ERR_PARTIAL:
                throw new Exception('File upload was not completed.');
            case UPLOAD_ERR_NO_FILE:
                throw new Exception('No file was uploaded.');
            default:
                throw new Exception('Unknown upload error.');
        }
        
        if ($file['size'] > $this->max_size) {
            throw new Exception('File too large. Maximum size is 5MB.');
        }
        
        if (!in_array($file['type'], $this->allowed_types)) {
            throw new Exception('File type not allowed.');
        }
    }
    
    private function generateUniqueFilename($original_filename) {
        $info = pathinfo($original_filename);
        $ext = $info['extension'];
        $filename = $info['filename'];
        
        $new_filename = $filename;
        $counter = 1;
        
        while (file_exists($this->upload_dir . $new_filename . '.' . $ext)) {
            $new_filename = $filename . '_' . $counter;
            $counter++;
        }
        
        return $new_filename . '.' . $ext;
    }
    
    public function deleteAttachment($filepath) {
        $full_path = __DIR__ . '/../../' . $filepath;
        if (file_exists($full_path) && is_file($full_path)) {
            return unlink($full_path);
        }
        return false;
    }
} 