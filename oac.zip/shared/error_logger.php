<?php
function logError($message, $data = [], $level = 'ERROR') {
    $log_entry = [
        'timestamp' => date('Y-m-d H:i:s'),
        'level' => $level,
        'message' => $message,
        'data' => $data,
        'user_id' => $_SESSION['user_id'] ?? 'not_logged_in',
        'ip' => $_SERVER['REMOTE_ADDR'] ?? 'unknown',
        'url' => $_SERVER['REQUEST_URI'] ?? 'unknown'
    ];

    $log_file = dirname(__DIR__) . '/logs/' . date('Y-m-d') . '_error.log';
    $log_dir = dirname($log_file);

    // Create logs directory if it doesn't exist
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0755, true);
    }

    // Format log entry
    $formatted_entry = json_encode($log_entry, JSON_PRETTY_PRINT) . "\n---\n";

    // Write to log file
    file_put_contents($log_file, $formatted_entry, FILE_APPEND);

    // If it's a critical error, also use PHP's error_log
    if ($level === 'CRITICAL') {
        error_log("CRITICAL ERROR: $message");
    }
}

function logInfo($message, $data = []) {
    logError($message, $data, 'INFO');
}

function logWarning($message, $data = []) {
    logError($message, $data, 'WARNING');
}

function logCritical($message, $data = []) {
    logError($message, $data, 'CRITICAL');
} 