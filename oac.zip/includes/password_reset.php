<?php
session_start();
require_once '../auth/middleware.php';
require_once '../auth/db.php';

try {
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $error = '';
    $success = '';

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $conn->begin_transaction();
        
        try {
            if (isset($_POST['email'])) {
                // Request password reset
                $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
                
                if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    throw new Exception("Invalid email format");
                }
                
                // Check if email exists
                $stmt = $conn->prepare("SELECT id_utilisateur FROM Utilisateurs WHERE email = ?");
                if (!$stmt) {
                    throw new Exception("Failed to prepare statement: " . $conn->error);
                }
                
                $stmt->bind_param("s", $email);
                if (!$stmt->execute()) {
                    throw new Exception("Failed to check email: " . $stmt->error);
                }
                
                $result = $stmt->get_result();
                if ($result->num_rows === 0) {
                    throw new Exception("No account found with this email address");
                }
                
                $user = $result->fetch_assoc();
                $stmt->close();
                
                // Generate token
                $token = bin2hex(random_bytes(32));
                $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
                
                // Delete any existing reset tokens for this user
                $stmt = $conn->prepare("DELETE FROM password_resets WHERE user_id = ?");
                if (!$stmt) {
                    throw new Exception("Failed to prepare delete statement: " . $conn->error);
                }
                
                $stmt->bind_param("i", $user['id_utilisateur']);
                if (!$stmt->execute()) {
                    throw new Exception("Failed to delete old tokens: " . $stmt->error);
                }
                $stmt->close();
                
                // Insert new token
                $stmt = $conn->prepare("INSERT INTO password_resets (user_id, token, expiry) VALUES (?, ?, ?)");
                if (!$stmt) {
                    throw new Exception("Failed to prepare insert statement: " . $conn->error);
                }
                
                $stmt->bind_param("iss", $user['id_utilisateur'], $token, $expiry);
                if (!$stmt->execute()) {
                    throw new Exception("Failed to create reset token: " . $stmt->error);
                }
                $stmt->close();
                
                // Send reset email
                $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/oac/includes/reset_password.php?token=" . $token;
                $to = $email;
                $subject = "Password Reset Request";
                $message = "Hello,\n\nYou have requested to reset your password. Click the link below to reset your password:\n\n$reset_link\n\nThis link will expire in 1 hour.\n\nIf you did not request this password reset, please ignore this email.\n\nBest regards,\nOAC Team";
                $headers = "From: noreply@oac.com";
                
                if (!mail($to, $subject, $message, $headers)) {
                    throw new Exception("Failed to send reset email");
                }
                
                $conn->commit();
                $success = "Password reset instructions have been sent to your email";
                
            } elseif (isset($_POST['token'], $_POST['new_password'], $_POST['confirm_password'])) {
                // Reset password
                if ($_POST['new_password'] !== $_POST['confirm_password']) {
                    throw new Exception("Passwords do not match");
                }
                
                if (strlen($_POST['new_password']) < 8) {
                    throw new Exception("Password must be at least 8 characters long");
                }
                
                // Verify token
                $stmt = $conn->prepare("SELECT user_id FROM password_resets WHERE token = ? AND expiry > NOW() AND used = 0");
                if (!$stmt) {
                    throw new Exception("Failed to prepare statement: " . $conn->error);
                }
                
                $stmt->bind_param("s", $_POST['token']);
                if (!$stmt->execute()) {
                    throw new Exception("Failed to verify token: " . $stmt->error);
                }
                
                $result = $stmt->get_result();
                if ($result->num_rows === 0) {
                    throw new Exception("Invalid or expired reset token");
                }
                
                $reset = $result->fetch_assoc();
                $stmt->close();
                
                // Update password
                $hashed_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE Utilisateurs SET password = ? WHERE id_utilisateur = ?");
                if (!$stmt) {
                    throw new Exception("Failed to prepare update statement: " . $conn->error);
                }
                
                $stmt->bind_param("si", $hashed_password, $reset['user_id']);
                if (!$stmt->execute()) {
                    throw new Exception("Failed to update password: " . $stmt->error);
                }
                $stmt->close();
                
                // Mark token as used
                $stmt = $conn->prepare("UPDATE password_resets SET used = 1 WHERE token = ?");
                if (!$stmt) {
                    throw new Exception("Failed to prepare token update statement: " . $conn->error);
                }
                
                $stmt->bind_param("s", $_POST['token']);
                if (!$stmt->execute()) {
                    throw new Exception("Failed to mark token as used: " . $stmt->error);
                }
                $stmt->close();
                
                $conn->commit();
                $success = "Password has been reset successfully. You can now login with your new password.";
            }
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error: " . $e->getMessage();
        }
    }
} catch (Exception $e) {
    $error = "System Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset - OAC Grade Management</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/email_system.css">
</head>
<body>
    <div class="reset-container">
        <h2 class="reset-title">Password Reset</h2>
        
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="uil uil-exclamation-triangle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="uil uil-check-circle"></i>
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <?php if (!isset($_GET['token'])): ?>
            <form method="POST" class="email-form">
                <div class="form-group">
                    <label for="email" class="form-label">Email Address</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="uil uil-envelope"></i>
                            </span>
                        </div>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="uil uil-envelope-send"></i>
                    Request Password Reset
                </button>
            </form>
        <?php else: ?>
            <form method="POST" class="email-form">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
                
                <div class="form-group">
                    <label for="new_password" class="form-label">New Password</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="uil uil-lock-alt"></i>
                            </span>
                        </div>
                        <input type="password" class="form-control" id="new_password" name="new_password" required minlength="8">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <div class="input-group">
                        <div class="input-group-prepend">
                            <span class="input-group-text">
                                <i class="uil uil-lock-alt"></i>
                            </span>
                        </div>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required minlength="8">
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary btn-block">
                    <i class="uil uil-lock"></i>
                    Reset Password
                </button>
            </form>
        <?php endif; ?>
        
        <div class="text-center mt-3">
            <a href="../index.php" class="btn btn-link">
                <i class="uil uil-arrow-left"></i>
                Back to Login
            </a>
        </div>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
if (isset($conn)) {
    $conn->close();
}
?> 