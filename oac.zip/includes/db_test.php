<?php
require_once '../auth/db.php';

try {
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    // Test required tables
    $required_tables = [
        'Utilisateurs',
        'emails',
        'password_resets'
    ];
    
    $missing_tables = [];
    
    foreach ($required_tables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result->num_rows === 0) {
            $missing_tables[] = $table;
        }
    }
    
    if (!empty($missing_tables)) {
        throw new Exception("Missing required tables: " . implode(", ", $missing_tables));
    }
    
    // Test table structures
    $table_tests = [
        'Utilisateurs' => [
            'id_utilisateur',
            'nom',
            'prenom',
            'email',
            'password',
            'role'
        ],
        'emails' => [
            'id',
            'sender_id',
            'recipient_id',
            'subject',
            'message',
            'attachment_path',
            'is_read',
            'created_at'
        ],
        'password_resets' => [
            'id',
            'user_id',
            'token',
            'expiry',
            'used',
            'created_at'
        ]
    ];
    
    $missing_columns = [];
    
    foreach ($table_tests as $table => $required_columns) {
        $result = $conn->query("DESCRIBE $table");
        if (!$result) {
            throw new Exception("Failed to describe table $table: " . $conn->error);
        }
        
        $existing_columns = [];
        while ($row = $result->fetch_assoc()) {
            $existing_columns[] = $row['Field'];
        }
        
        foreach ($required_columns as $column) {
            if (!in_array($column, $existing_columns)) {
                if (!isset($missing_columns[$table])) {
                    $missing_columns[$table] = [];
                }
                $missing_columns[$table][] = $column;
            }
        }
    }
    
    if (!empty($missing_columns)) {
        $error_msg = "Missing columns:\n";
        foreach ($missing_columns as $table => $columns) {
            $error_msg .= "$table: " . implode(", ", $columns) . "\n";
        }
        throw new Exception($error_msg);
    }
    
    // Test foreign key constraints
    $required_constraints = [
        'emails' => [
            ['column' => 'sender_id', 'references' => 'Utilisateurs(id_utilisateur)'],
            ['column' => 'recipient_id', 'references' => 'Utilisateurs(id_utilisateur)']
        ],
        'password_resets' => [
            ['column' => 'user_id', 'references' => 'Utilisateurs(id_utilisateur)']
        ]
    ];
    
    $missing_constraints = [];
    
    foreach ($required_constraints as $table => $constraints) {
        $result = $conn->query("SHOW CREATE TABLE $table");
        if (!$result) {
            throw new Exception("Failed to show create table $table: " . $conn->error);
        }
        
        $row = $result->fetch_assoc();
        $create_table = $row['Create Table'];
        
        foreach ($constraints as $constraint) {
            if (strpos($create_table, "FOREIGN KEY (`{$constraint['column']}`) REFERENCES `{$constraint['references']}`") === false) {
                if (!isset($missing_constraints[$table])) {
                    $missing_constraints[$table] = [];
                }
                $missing_constraints[$table][] = "{$constraint['column']} -> {$constraint['references']}";
            }
        }
    }
    
    if (!empty($missing_constraints)) {
        $error_msg = "Missing foreign key constraints:\n";
        foreach ($missing_constraints as $table => $constraints) {
            $error_msg .= "$table: " . implode(", ", $constraints) . "\n";
        }
        throw new Exception($error_msg);
    }
    
    // Test indexes
    $required_indexes = [
        'emails' => ['sender_id', 'recipient_id', 'created_at'],
        'password_resets' => ['token', 'user_id', 'expiry']
    ];
    
    $missing_indexes = [];
    
    foreach ($required_indexes as $table => $indexes) {
        $result = $conn->query("SHOW INDEX FROM $table");
        if (!$result) {
            throw new Exception("Failed to show indexes for table $table: " . $conn->error);
        }
        
        $existing_indexes = [];
        while ($row = $result->fetch_assoc()) {
            $existing_indexes[] = $row['Column_name'];
        }
        
        foreach ($indexes as $index) {
            if (!in_array($index, $existing_indexes)) {
                if (!isset($missing_indexes[$table])) {
                    $missing_indexes[$table] = [];
                }
                $missing_indexes[$table][] = $index;
            }
        }
    }
    
    if (!empty($missing_indexes)) {
        $error_msg = "Missing indexes:\n";
        foreach ($missing_indexes as $table => $indexes) {
            $error_msg .= "$table: " . implode(", ", $indexes) . "\n";
        }
        throw new Exception($error_msg);
    }
    
    echo "Database connection and structure tests passed successfully!";
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?> 