<?php
session_start();
require_once '../auth/middleware.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../index.php');
    exit();
}

$servername = "localhost";
$username = "Eddy";
$password = "Daddiesammy1$";
$bd = "keyce";

$conn = new mysqli($servername, $username, $password, $bd);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Mark email as read
if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
    $stmt = $conn->prepare("UPDATE emails SET is_read = 1 WHERE id = ? AND recipient_id = ?");
    $stmt->bind_param("ii", $_GET['mark_read'], $_SESSION['user_id']);
    $stmt->execute();
    $stmt->close();
}

// Delete email
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $stmt = $conn->prepare("DELETE FROM emails WHERE id = ? AND (recipient_id = ? OR sender_id = ?)");
    $stmt->bind_param("iii", $_GET['delete'], $_SESSION['user_id'], $_SESSION['user_id']);
    $stmt->execute();
    $stmt->close();
}

// Get emails (both sent and received)
$emails_query = "
    SELECT 
        E.*,
        CONCAT(S.nom, ' ', S.prenom) as sender_name,
        CONCAT(R.nom, ' ', R.prenom) as recipient_name,
        S.email as sender_email,
        R.email as recipient_email
    FROM emails E
    INNER JOIN Utilisateurs S ON E.sender_id = S.id_utilisateur
    INNER JOIN Utilisateurs R ON E.recipient_id = R.id_utilisateur
    WHERE E.sender_id = ? OR E.recipient_id = ?
    ORDER BY E.created_at DESC
";

$stmt = $conn->prepare($emails_query);
$stmt->bind_param("ii", $_SESSION['user_id'], $_SESSION['user_id']);
$stmt->execute();
$emails = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Emails</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .container { margin-top: 30px; }
        .email-item {
            border: 1px solid #ddd;
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 5px;
        }
        .email-item.unread {
            background-color: #f8f9fa;
            border-left: 4px solid #007bff;
        }
        .email-header {
            margin-bottom: 10px;
        }
        .email-actions {
            float: right;
        }
        .email-content {
            margin-top: 10px;
            white-space: pre-wrap;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2>My Emails</h2>
            <a href="<?php echo $_SESSION['role'] == 1 ? '../admin/ADashboard.php' : ($_SESSION['role'] == 2 ? '../teacher/TDashboard.php' : '../student/SDashboard.php'); ?>" class="btn btn-secondary">
                Back to Dashboard
            </a>
        </div>
        
        <?php if ($emails->num_rows === 0): ?>
            <div class="alert alert-info">No emails found.</div>
        <?php else: ?>
            <?php while ($email = $emails->fetch_assoc()): ?>
                <div class="email-item <?php echo (!$email['is_read'] && $email['recipient_id'] == $_SESSION['user_id']) ? 'unread' : ''; ?>">
                    <div class="email-header">
                        <div class="email-actions">
                            <?php if (!$email['is_read'] && $email['recipient_id'] == $_SESSION['user_id']): ?>
                                <a href="?mark_read=<?php echo $email['id']; ?>" class="btn btn-sm btn-primary" title="Mark as Read">
                                    <i class="fas fa-envelope-open"></i>
                                </a>
                            <?php endif; ?>
                            <a href="?delete=<?php echo $email['id']; ?>" class="btn btn-sm btn-danger" onclick="return confirm('Are you sure you want to delete this email?')" title="Delete">
                                <i class="fas fa-trash"></i>
                            </a>
                        </div>
                        <strong>Subject:</strong> <?php echo htmlspecialchars($email['subject']); ?><br>
                        <strong>From:</strong> <?php echo htmlspecialchars($email['sender_name'] . ' (' . $email['sender_email'] . ')'); ?><br>
                        <strong>To:</strong> <?php echo htmlspecialchars($email['recipient_name'] . ' (' . $email['recipient_email'] . ')'); ?><br>
                        <strong>Date:</strong> <?php echo date('F j, Y g:i A', strtotime($email['created_at'])); ?>
                    </div>
                    <div class="email-content">
                        <?php echo nl2br(htmlspecialchars($email['message'])); ?>
                    </div>
                    <?php if ($email['attachment_path']): ?>
                        <div class="mt-2">
                            <strong>Attachment:</strong>
                            <a href="<?php echo htmlspecialchars($email['attachment_path']); ?>" target="_blank">
                                <i class="fas fa-paperclip"></i> Download Attachment
                            </a>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html><?php
$conn->close();
?> 