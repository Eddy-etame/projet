<?php
class EmailVerifier {
    private $api_key;
    private $use_api;
    
    public function __construct($api_key = null) {
        $this->api_key = $api_key ?? getenv('ABSTRACT_API_KEY');
        $this->use_api = !empty($this->api_key);
    }
    
    public function verifyEmail($email) {
        try {
            // Basic validation
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                return [
                    'is_valid' => false,
                    'message' => 'Invalid email format'
                ];
            }
            
            if ($this->use_api) {
                return $this->verifyWithAPI($email);
            }
            
            return $this->verifyWithDNS($email);
        } catch (Exception $e) {
            error_log("Email verification error: " . $e->getMessage());
            // Fallback to DNS check on API failure
            return $this->verifyWithDNS($email);
        }
    }
    
    private function verifyWithAPI($email) {
        $url = "https://emailvalidation.abstractapi.com/v1/?api_key=" . urlencode($this->api_key) . "&email=" . urlencode($email);
        
        $ch = curl_init();
        curl_setopt_array($ch, [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 5,
            CURLOPT_SSL_VERIFYPEER => true
        ]);
        
        $response = curl_exec($ch);
        $error = curl_error($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        
        curl_close($ch);
        
        if ($error || $http_code !== 200) {
            throw new Exception("API request failed: $error");
        }
        
        $data = json_decode($response, true);
        if (!$data || !isset($data['deliverability']) || !isset($data['is_valid_format'])) {
            throw new Exception("Invalid API response");
        }
        
        return [
            'is_valid' => $data['deliverability'] === 'DELIVERABLE' && $data['is_valid_format'],
            'message' => $data['deliverability'] === 'DELIVERABLE' ? 'Email is valid' : 'Email may not be deliverable',
            'details' => $data
        ];
    }
    
    private function verifyWithDNS($email) {
        $domain = substr($email, strpos($email, '@') + 1);
        if (checkdnsrr($domain, 'MX')) {
            return [
                'is_valid' => true,
                'message' => 'Email domain has valid MX records'
            ];
        }
        
        return [
            'is_valid' => false,
            'message' => 'Email domain does not have valid MX records'
        ];
    }
} 