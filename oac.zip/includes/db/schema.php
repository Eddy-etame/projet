<?php
require_once '../../auth/db.php';

try {
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }
    
    // Enable foreign key checks
    $conn->query("SET FOREIGN_KEY_CHECKS = 1");
    
    // Start transaction
    $conn->begin_transaction();
    
    try {
        // Create emails table
        $sql = "CREATE TABLE IF NOT EXISTS emails (
            id INT AUTO_INCREMENT PRIMARY KEY,
            sender_id INT NOT NULL,
            recipient_id INT NOT NULL,
            subject VARCHAR(255) NOT NULL,
            message TEXT NOT NULL,
            attachment_path VARCHAR(255),
            is_read TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (sender_id) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE,
            FOREIGN KEY (recipient_id) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE,
            INDEX idx_sender (sender_id),
            INDEX idx_recipient (recipient_id),
            INDEX idx_created_at (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if (!$conn->query($sql)) {
            throw new Exception("Failed to create emails table: " . $conn->error);
        }
        
        // Create password_resets table
        $sql = "CREATE TABLE IF NOT EXISTS password_resets (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            token VARCHAR(64) NOT NULL,
            expiry DATETIME NOT NULL,
            used TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE,
            UNIQUE INDEX idx_token (token),
            INDEX idx_user (user_id),
            INDEX idx_expiry (expiry)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci";
        
        if (!$conn->query($sql)) {
            throw new Exception("Failed to create password_resets table: " . $conn->error);
        }
        
        // Add any missing indexes to Utilisateurs table
        $sql = "SHOW INDEX FROM Utilisateurs";
        $result = $conn->query($sql);
        if (!$result) {
            throw new Exception("Failed to check Utilisateurs indexes: " . $conn->error);
        }
        
        $existing_indexes = [];
        while ($row = $result->fetch_assoc()) {
            $existing_indexes[] = $row['Key_name'];
        }
        
        // Add email index if not exists
        if (!in_array('idx_email', $existing_indexes)) {
            $sql = "CREATE UNIQUE INDEX idx_email ON Utilisateurs(email)";
            if (!$conn->query($sql)) {
                throw new Exception("Failed to create email index: " . $conn->error);
            }
        }
        
        // Add role index if not exists
        if (!in_array('idx_role', $existing_indexes)) {
            $sql = "CREATE INDEX idx_role ON Utilisateurs(role)";
            if (!$conn->query($sql)) {
                throw new Exception("Failed to create role index: " . $conn->error);
            }
        }
        
        // Create uploads directory
        $upload_dir = __DIR__ . '/../../uploads/email_attachments';
        if (!file_exists($upload_dir)) {
            if (!mkdir($upload_dir, 0755, true)) {
                throw new Exception("Failed to create upload directory");
            }
            
            // Create .htaccess to prevent direct access
            $htaccess = $upload_dir . '/.htaccess';
            $content = "Order deny,allow\nDeny from all\n";
            if (file_put_contents($htaccess, $content) === false) {
                throw new Exception("Failed to create .htaccess file");
            }
        }
        
        $conn->commit();
        echo "Database schema created successfully!";
        
    } catch (Exception $e) {
        $conn->rollback();
        throw $e;
    }
    
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
} finally {
    if (isset($conn)) {
        $conn->close();
    }
}
?> 