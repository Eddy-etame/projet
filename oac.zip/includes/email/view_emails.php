<?php
session_start();
require_once '../../auth/middleware.php';
require_once '../../auth/db.php';

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../index.php');
    exit();
}

try {
    if (!isset($conn) || $conn->connect_error) {
        throw new Exception("Connection failed: " . $conn->connect_error);
    }

    $error = '';
    $success = '';

    // Mark email as read
    if (isset($_GET['mark_read']) && is_numeric($_GET['mark_read'])) {
        $conn->begin_transaction();
        
        try {
            $stmt = $conn->prepare("UPDATE emails SET is_read = 1 WHERE id = ? AND recipient_id = ?");
            if (!$stmt) {
                throw new Exception("Failed to prepare statement: " . $conn->error);
            }
            
            $stmt->bind_param("ii", $_GET['mark_read'], $_SESSION['user_id']);
            if (!$stmt->execute()) {
                throw new Exception("Failed to mark email as read: " . $stmt->error);
            }
            
            $stmt->close();
            $conn->commit();
            $success = "Email marked as read";
            
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error: " . $e->getMessage();
        }
    }

    // Delete email
    if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
        $conn->begin_transaction();
        
        try {
            // First, get the email details to check for attachments
            $stmt = $conn->prepare("SELECT attachment_path FROM emails WHERE id = ? AND (recipient_id = ? OR sender_id = ?)");
            if (!$stmt) {
                throw new Exception("Failed to prepare statement: " . $conn->error);
            }
            
            $stmt->bind_param("iii", $_GET['delete'], $_SESSION['user_id'], $_SESSION['user_id']);
            if (!$stmt->execute()) {
                throw new Exception("Failed to fetch email details: " . $stmt->error);
            }
            
            $result = $stmt->get_result();
            $email = $result->fetch_assoc();
            $stmt->close();
            
            // Delete the email
            $stmt = $conn->prepare("DELETE FROM emails WHERE id = ? AND (recipient_id = ? OR sender_id = ?)");
            if (!$stmt) {
                throw new Exception("Failed to prepare delete statement: " . $conn->error);
            }
            
            $stmt->bind_param("iii", $_GET['delete'], $_SESSION['user_id'], $_SESSION['user_id']);
            if (!$stmt->execute()) {
                throw new Exception("Failed to delete email: " . $stmt->error);
            }
            
            $stmt->close();
            
            // If email had an attachment, delete the file
            if ($email && $email['attachment_path'] && file_exists($email['attachment_path'])) {
                if (!unlink($email['attachment_path'])) {
                    throw new Exception("Failed to delete attachment file");
                }
            }
            
            $conn->commit();
            $success = "Email deleted successfully";
            
        } catch (Exception $e) {
            $conn->rollback();
            $error = "Error: " . $e->getMessage();
        }
    }

    // Get emails (both sent and received)
    $emails_query = "
        SELECT 
            E.*,
            CONCAT(S.nom, ' ', S.prenom) as sender_name,
            CONCAT(R.nom, ' ', R.prenom) as recipient_name,
            S.email as sender_email,
            R.email as recipient_email
        FROM emails E
        INNER JOIN Utilisateurs S ON E.sender_id = S.id_utilisateur
        INNER JOIN Utilisateurs R ON E.recipient_id = R.id_utilisateur
        WHERE E.sender_id = ? OR E.recipient_id = ?
        ORDER BY E.created_at DESC
    ";

    $stmt = $conn->prepare($emails_query);
    if (!$stmt) {
        throw new Exception("Failed to prepare emails query: " . $conn->error);
    }

    $stmt->bind_param("ii", $_SESSION['user_id'], $_SESSION['user_id']);
    if (!$stmt->execute()) {
        throw new Exception("Failed to fetch emails: " . $stmt->error);
    }

    $emails = $stmt->get_result();
    $stmt->close();

} catch (Exception $e) {
    $error = "System Error: " . $e->getMessage();
    $emails = null;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Emails - OAC Grade Management</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../css/email_system.css">
</head>
<body>
    <div class="email-container">
        <div class="email-header">
            <h2 class="email-title">My Emails</h2>
            <div class="email-actions">
                <a href="compose_email.php" class="btn btn-primary">
                    <i class="uil uil-plus"></i> Compose New Email
                </a>
                <a href="<?php echo $_SESSION['role'] == 1 ? '../../admin/ADashboard.php' : ($_SESSION['role'] == 2 ? '../../teacher/TDashboard.php' : '../../student/SDashboard.php'); ?>" class="btn btn-secondary">
                    <i class="uil uil-estate"></i> Back to Dashboard
                </a>
            </div>
        </div>
        
        <?php if ($error): ?>
            <div class="alert alert-danger">
                <i class="uil uil-exclamation-triangle"></i>
                <?php echo htmlspecialchars($error); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="alert alert-success">
                <i class="uil uil-check-circle"></i>
                <?php echo htmlspecialchars($success); ?>
            </div>
        <?php endif; ?>
        
        <?php if ($emails && $emails->num_rows === 0): ?>
            <div class="alert alert-info">
                <i class="uil uil-envelope"></i>
                No emails found.
            </div>
        <?php elseif ($emails): ?>
            <?php while ($email = $emails->fetch_assoc()): ?>
                <div class="email-item <?php echo (!$email['is_read'] && $email['recipient_id'] == $_SESSION['user_id']) ? 'unread' : ''; ?>">
                    <div class="email-meta">
                        <div>
                            <strong>From:</strong> <?php echo htmlspecialchars($email['sender_name'] . ' (' . $email['sender_email'] . ')'); ?>
                        </div>
                        <div>
                            <?php echo date('F j, Y g:i A', strtotime($email['created_at'])); ?>
                        </div>
                    </div>
                    
                    <div class="email-subject">
                        <?php echo htmlspecialchars($email['subject']); ?>
                    </div>
                    
                    <div class="email-content">
                        <?php echo nl2br(htmlspecialchars($email['message'])); ?>
                    </div>
                    
                    <?php if ($email['attachment_path']): ?>
                        <div class="attachment-section">
                            <a href="<?php echo htmlspecialchars($email['attachment_path']); ?>" class="attachment-link" target="_blank">
                                <i class="uil uil-paperclip"></i>
                                Download Attachment
                            </a>
                        </div>
                    <?php endif; ?>
                    
                    <div class="email-actions">
                        <?php if (!$email['is_read'] && $email['recipient_id'] == $_SESSION['user_id']): ?>
                            <a href="?mark_read=<?php echo $email['id']; ?>" class="btn btn-primary" title="Mark as Read">
                                <i class="uil uil-envelope-open"></i>
                            </a>
                        <?php endif; ?>
                        <a href="?delete=<?php echo $email['id']; ?>" class="btn btn-danger" onclick="return confirm('Are you sure you want to delete this email? This action cannot be undone.')" title="Delete">
                            <i class="uil uil-trash-alt"></i>
                        </a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php endif; ?>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php
if (isset($conn)) {
    $conn->close();
}
?> 