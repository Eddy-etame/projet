<?php
class EmailValidator {
    private $abstract_api_key;
    private $use_api_validation;
    
    public function __construct($abstract_api_key = null) {
        $this->abstract_api_key = $abstract_api_key;
        $this->use_api_validation = !empty($abstract_api_key);
    }
    
    public function validateEmail($email) {
        // Basic validation
        if (!$this->basicValidation($email)) {
            throw new Exception("Invalid email format");
        }
        
        // API validation if enabled
        if ($this->use_api_validation) {
            return $this->apiValidation($email);
        }
        
        return true;
    }
    
    private function basicValidation($email) {
        // Remove whitespace
        $email = trim($email);
        
        // Check basic format
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return false;
        }
        
        // Check length
        if (strlen($email) > 254) {
            return false;
        }
        
        // Check for valid domain
        $domain = substr(strrchr($email, "@"), 1);
        if (!checkdnsrr($domain, 'MX') && !checkdnsrr($domain, 'A')) {
            return false;
        }
        
        return true;
    }
    
    private function apiValidation($email) {
        try {
            // API endpoint
            $url = "https://emailvalidation.abstractapi.com/v1/?api_key=" . urlencode($this->abstract_api_key) . "&email=" . urlencode($email);
            
            // Initialize curl
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            
            // Set timeout
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 10);
            curl_setopt($ch, CURLOPT_TIMEOUT, 30);
            
            // Execute request
            $response = curl_exec($ch);
            
            // Check for errors
            if (curl_errno($ch)) {
                throw new Exception("API request failed: " . curl_error($ch));
            }
            
            // Get HTTP status code
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($http_code !== 200) {
                throw new Exception("API request failed with status code: " . $http_code);
            }
            
            // Parse response
            $data = json_decode($response, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                throw new Exception("Failed to parse API response");
            }
            
            // Check validation results
            if (!isset($data['is_valid_format'])) {
                throw new Exception("Invalid API response format");
            }
            
            if (!$data['is_valid_format']) {
                throw new Exception("Invalid email format");
            }
            
            // Check deliverability
            if (isset($data['deliverability']) && $data['deliverability'] === "UNDELIVERABLE") {
                throw new Exception("Email address appears to be undeliverable");
            }
            
            // Check disposable email
            if (isset($data['is_disposable_email']) && $data['is_disposable_email']) {
                throw new Exception("Disposable email addresses are not allowed");
            }
            
            // Check free email
            if (isset($data['is_free_email']) && $data['is_free_email']) {
                // You might want to log this or handle it differently
                // For now, we'll allow free email providers
            }
            
            return true;
            
        } catch (Exception $e) {
            // Log the error for debugging
            error_log("Email validation API error: " . $e->getMessage());
            
            // Fall back to basic validation
            return $this->basicValidation($email);
        }
    }
}

// Example usage:
/*
try {
    $validator = new EmailValidator('your_abstract_api_key'); // Or new EmailValidator() for basic validation only
    $is_valid = $validator->validateEmail('test@example.com');
    echo "Email is valid!";
} catch (Exception $e) {
    echo "Email validation failed: " . $e->getMessage();
}
*/
?> 