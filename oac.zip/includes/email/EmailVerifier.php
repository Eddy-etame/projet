<?php
class EmailVerifier {
    private $api_key;
    
    public function __construct($api_key = null) {
        $this->api_key = $api_key ?? getenv('ABSTRACT_API_KEY');
    }
    
    public function verifyEmail($email) {
        // Basic validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return [
                'is_valid' => false,
                'message' => 'Invalid email format'
            ];
        }
        
        if ($this->api_key) {
            // Use Abstract API for advanced validation
            $url = "https://emailvalidation.abstractapi.com/v1/?api_key=" . $this->api_key . "&email=" . urlencode($email);
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
            
            $response = curl_exec($ch);
            $data = json_decode($response, true);
            
            curl_close($ch);
            
            if (isset($data['deliverability']) && isset($data['is_valid_format'])) {
                return [
                    'is_valid' => $data['deliverability'] === 'DELIVERABLE' && $data['is_valid_format'],
                    'message' => $data['deliverability'] === 'DELIVERABLE' ? 'Email is valid' : 'Email may not be deliverable',
                    'details' => $data
                ];
            }
        }
        
        // Fallback to basic DNS check if API is not available
        $domain = substr($email, strpos($email, '@') + 1);
        if (checkdnsrr($domain, 'MX')) {
            return [
                'is_valid' => true,
                'message' => 'Email domain has valid MX records'
            ];
        }
        
        return [
            'is_valid' => false,
            'message' => 'Email domain does not have valid MX records'
        ];
    }
} 