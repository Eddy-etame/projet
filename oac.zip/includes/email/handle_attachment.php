<?php
function handleEmailAttachment($file) {
    // Validate file upload
    if (!isset($file) || $file['error'] !== UPLOAD_ERR_OK) {
        switch ($file['error']) {
            case UPLOAD_ERR_INI_SIZE:
            case UPLOAD_ERR_FORM_SIZE:
                throw new Exception("File size exceeds limit");
            case UPLOAD_ERR_PARTIAL:
                throw new Exception("File was only partially uploaded");
            case UPLOAD_ERR_NO_FILE:
                throw new Exception("No file was uploaded");
            case UPLOAD_ERR_NO_TMP_DIR:
                throw new Exception("Missing temporary folder");
            case UPLOAD_ERR_CANT_WRITE:
                throw new Exception("Failed to write file to disk");
            case UPLOAD_ERR_EXTENSION:
                throw new Exception("File upload stopped by extension");
            default:
                throw new Exception("Unknown upload error");
        }
    }

    // Validate file size (max 10MB)
    if ($file['size'] > 10 * 1024 * 1024) {
        throw new Exception("File size must be less than 10MB");
    }

    // Validate file type
    $allowed_types = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'application/vnd.ms-powerpoint',
        'application/vnd.openxmlformats-officedocument.presentationml.presentation',
        'text/plain',
        'image/jpeg',
        'image/png',
        'image/gif'
    ];

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime_type = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    if (!in_array($mime_type, $allowed_types)) {
        throw new Exception("Invalid file type. Allowed types: PDF, Word, Excel, PowerPoint, Text, and Images");
    }

    // Generate safe filename
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $filename = bin2hex(random_bytes(16)) . '.' . $extension;
    
    // Create upload directory if it doesn't exist
    $upload_dir = __DIR__ . '/../../uploads/email_attachments';
    if (!file_exists($upload_dir)) {
        if (!mkdir($upload_dir, 0755, true)) {
            throw new Exception("Failed to create upload directory");
        }
    }

    // Ensure upload directory is writable
    if (!is_writable($upload_dir)) {
        throw new Exception("Upload directory is not writable");
    }

    $filepath = $upload_dir . '/' . $filename;

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $filepath)) {
        throw new Exception("Failed to save uploaded file");
    }

    // Return relative path for database storage
    return 'uploads/email_attachments/' . $filename;
}

function deleteEmailAttachment($filepath) {
    if (empty($filepath)) {
        return;
    }

    // Convert relative path to absolute
    $absolute_path = __DIR__ . '/../../' . $filepath;

    // Validate path is within uploads directory
    $real_path = realpath($absolute_path);
    $uploads_dir = realpath(__DIR__ . '/../../uploads/email_attachments');

    if ($real_path === false || strpos($real_path, $uploads_dir) !== 0) {
        throw new Exception("Invalid file path");
    }

    // Delete file
    if (file_exists($absolute_path) && !unlink($absolute_path)) {
        throw new Exception("Failed to delete attachment file");
    }
}
?> 