-- Create Notifications table if it doesn't exist
CREATE TABLE IF NOT EXISTS Notifications (
    id_notification INT PRIMARY KEY AUTO_INCREMENT,
    type ENUM('email', 'news', 'message') NOT NULL,
    sender_id INT NOT NULL,
    recipient_id INT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES Utilisateurs(id_utilisateur),
    FOREIGN KEY (recipient_id) REFERENCES Utilisateurs(id_utilisateur)
);

-- Create News table if it doesn't exist
CREATE TABLE IF NOT EXISTS News (
    id_news INT PRIMARY KEY AUTO_INCREMENT,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    author_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (author_id) REFERENCES Utilisateurs(id_utilisateur)
);

-- Create Messages table if it doesn't exist
CREATE TABLE IF NOT EXISTS Messages (
    id_message INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT NOT NULL,
    recipient_id INT NOT NULL,
    subject VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    parent_message_id INT DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (sender_id) REFERENCES Utilisateurs(id_utilisateur),
    FOREIGN KEY (recipient_id) REFERENCES Utilisateurs(id_utilisateur),
    FOREIGN KEY (parent_message_id) REFERENCES Messages(id_message)
);

-- Sample data insertion
-- Insert sample news
INSERT INTO News (title, content, author_id) VALUES
('Bienvenue à la nouvelle année scolaire', 'Nous sommes ravis de commencer cette nouvelle année scolaire avec vous tous.', 1),
('Réunion des parents', 'Une réunion des parents est prévue pour le 15 du mois prochain.', 1),
('Examens de fin de trimestre', 'Les examens de fin de trimestre commenceront la semaine prochaine.', 1);

-- Insert sample notifications (emails)
INSERT INTO Notifications (type, sender_id, recipient_id, subject, content, is_read) VALUES
('email', 1, 2, 'Rappel: Soumission des notes', 'N''oubliez pas de soumettre les notes avant vendredi.', FALSE),
('email', 1, 2, 'Réunion du personnel', 'Réunion importante du personnel ce jeudi à 14h.', FALSE),
('email', 1, 2, 'Formation continue', 'Nouvelle formation disponible sur la plateforme.', TRUE);

-- Insert sample messages
INSERT INTO Messages (sender_id, recipient_id, subject, content, is_read) VALUES
(3, 2, 'Question sur le devoir', 'Bonjour professeur, j''ai une question sur le dernier devoir...', FALSE),
(4, 2, 'Absence justifiée', 'Je serai absent demain pour raison médicale.', FALSE),
(2, 3, 'RE: Question sur le devoir', 'Bien sûr, je peux vous aider...', TRUE);

-- Create view for unread counts
CREATE OR REPLACE VIEW UnreadCounts AS
SELECT 
    recipient_id,
    SUM(CASE WHEN type = 'email' AND is_read = FALSE THEN 1 ELSE 0 END) as unread_emails,
    SUM(CASE WHEN type = 'message' AND is_read = FALSE THEN 1 ELSE 0 END) as unread_messages
FROM Notifications
GROUP BY recipient_id;

-- Useful SELECT queries
-- Get all unread notifications for a user
SELECT * FROM Notifications WHERE recipient_id = [USER_ID] AND is_read = FALSE ORDER BY created_at DESC;

-- Get all news items from last 30 days
SELECT n.*, u.nom as author_name 
FROM News n 
JOIN Utilisateurs u ON n.author_id = u.id_utilisateur 
WHERE n.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY) 
ORDER BY n.created_at DESC;

-- Get message thread
SELECT m.*, u.nom as sender_name 
FROM Messages m 
JOIN Utilisateurs u ON m.sender_id = u.id_utilisateur 
WHERE m.id_message = [MESSAGE_ID] OR m.parent_message_id = [MESSAGE_ID] 
ORDER BY m.created_at;

-- Update queries
-- Mark notification as read
UPDATE Notifications SET is_read = TRUE WHERE id_notification = [NOTIFICATION_ID];

-- Mark all notifications of a type as read
UPDATE Notifications 
SET is_read = TRUE 
WHERE recipient_id = [USER_ID] AND type = '[TYPE]' AND is_read = FALSE;

-- Delete queries
-- Delete old notifications (older than 6 months)
DELETE FROM Notifications 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH) AND is_read = TRUE;

-- Delete old news (older than 1 year)
DELETE FROM News 
WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR);

-- Alter table queries
-- Add index for faster notification retrieval
ALTER TABLE Notifications ADD INDEX idx_recipient_type (recipient_id, type);
ALTER TABLE Messages ADD INDEX idx_recipient (recipient_id);
ALTER TABLE News ADD INDEX idx_created_at (created_at);

-- Add cascade delete for messages
ALTER TABLE Messages 
DROP FOREIGN KEY messages_ibfk_3,
ADD FOREIGN KEY (parent_message_id) 
REFERENCES Messages(id_message) 
ON DELETE CASCADE;

-- Trigger to update message thread when parent is deleted
DELIMITER //
CREATE TRIGGER before_message_delete 
BEFORE DELETE ON Messages
FOR EACH ROW
BEGIN
    UPDATE Messages 
    SET parent_message_id = NULL 
    WHERE parent_message_id = OLD.id_message;
END;
//
DELIMITER ;

-- Procedure to clean up old data
DELIMITER //
CREATE PROCEDURE CleanupOldData()
BEGIN
    -- Delete old read notifications
    DELETE FROM Notifications 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 6 MONTH) 
    AND is_read = TRUE;
    
    -- Delete old news
    DELETE FROM News 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR);
    
    -- Delete old read messages
    DELETE FROM Messages 
    WHERE created_at < DATE_SUB(NOW(), INTERVAL 1 YEAR) 
    AND is_read = TRUE 
    AND parent_message_id IS NULL;
END;
//
DELIMITER ;

-- Schedule cleanup procedure (if your MySQL version supports EVENT)
CREATE EVENT IF NOT EXISTS cleanup_old_data
ON SCHEDULE EVERY 1 WEEK
DO CALL CleanupOldData(); 