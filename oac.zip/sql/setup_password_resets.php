<?php
$servername = "localhost";
$username = "Eddy";
$password = "Daddiesammy1$";
$bd = "keyce";

// Create connection
$conn = new mysqli($servername, $username, $password, $bd);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read and execute the SQL file
$sql = file_get_contents(__DIR__ . '/password_resets.sql');

if ($conn->multi_query($sql)) {
    do {
        // Store first result set
        if ($result = $conn->store_result()) {
            $result->free();
        }
        // Prepare next result set
    } while ($conn->more_results() && $conn->next_result());
    
    echo "Password resets table created successfully!\n";
} else {
    echo "Error creating password resets table: " . $conn->error . "\n";
}

$conn->close();
?> 