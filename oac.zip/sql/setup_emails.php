<?php
$servername = "localhost";
$username = "Eddy";
$password = "Daddiesammy1$";
$bd = "keyce";

// Create connection
$conn = new mysqli($servername, $username, $password, $bd);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Read and execute the SQL file
$sql = file_get_contents(__DIR__ . '/emails.sql');

if ($conn->multi_query($sql)) {
    do {
        // Store first result set
        if ($result = $conn->store_result()) {
            $result->free();
        }
        // Prepare next result set
    } while ($conn->more_results() && $conn->next_result());
    
    echo "Emails table created successfully!\n";
    
    // Create uploads directory if it doesn't exist
    $upload_dir = __DIR__ . '/../uploads';
    if (!file_exists($upload_dir)) {
        if (mkdir($upload_dir, 0777, true)) {
            echo "Uploads directory created successfully!\n";
        } else {
            echo "Failed to create uploads directory.\n";
        }
    }
} else {
    echo "Error creating emails table: " . $conn->error . "\n";
}

$conn->close();
?> 