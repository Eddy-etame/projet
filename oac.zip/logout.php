<?php
require_once 'auth/auth.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Check if admin is logging out
if (isset($_SESSION['role']) && $_SESSION['role'] == 1) {
    $redirect = 'admin/ADDashboard.php'; // Admin login page
} else {
    $redirect = 'index.php'; // General user login
}

session_unset();
session_destroy();
// Optionally, clear the session cookie
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}
header('Location: ' . $redirect);
exit();
?>