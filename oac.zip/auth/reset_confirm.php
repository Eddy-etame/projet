<?php
require_once __DIR__ . '/Login.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = '';
$success = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['token'], $_POST['password'], $_POST['confirm_password'])) {
    $token = $_POST['token'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Validate password
    if (strlen($password) < 6) {
        $error = "Password must be at least 6 characters long";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match";
    } else {
        // Check if token exists and is valid
        $stmt = $conn->prepare("
            SELECT user_id, expiry 
            FROM password_resets 
            WHERE token = ? AND expiry > NOW()
        ");
        
        if (!$stmt) {
            logError("Token verification query failed", ['error' => $conn->error]);
            $error = "System error occurred";
        } else {
            $stmt->bind_param("s", $token);
            
            if (!$stmt->execute()) {
                logError("Token verification failed", ['error' => $stmt->error]);
                $error = "System error occurred";
            } else {
                $result = $stmt->get_result();
                
                if ($result->num_rows === 0) {
                    $error = "Invalid or expired reset token";
                } else {
                    $reset = $result->fetch_assoc();
                    $user_id = $reset['user_id'];
                    
                    // Update password
                    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                    $update_stmt = $conn->prepare("
                        UPDATE Utilisateurs 
                        SET mot_de_passe_hash = ? 
                        WHERE id_utilisateur = ?
                    ");
                    
                    if (!$update_stmt) {
                        logError("Password update query failed", ['error' => $conn->error]);
                        $error = "System error occurred";
                    } else {
                        $update_stmt->bind_param("si", $hashed_password, $user_id);
                        
                        if (!$update_stmt->execute()) {
                            logError("Password update failed", ['error' => $update_stmt->error]);
                            $error = "Failed to update password";
                        } else {
                            // Delete used token
                            $delete_stmt = $conn->prepare("DELETE FROM password_resets WHERE token = ?");
                            $delete_stmt->bind_param("s", $token);
                            $delete_stmt->execute();
                            
                            $success = "Password has been successfully reset. You can now login with your new password.";
                            logError("Password reset successful", ['user_id' => $user_id]);
                        }
                    }
                }
            }
        }
    }
}

// Check if token is provided in URL
$token = isset($_GET['token']) ? $_GET['token'] : '';
if (empty($token) && empty($success)) {
    header("Location: ../index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password - OAC Grade Management</title>
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v2.1.9/css/unicons.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="../css/index.css">
    <style>
        .reset-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        .alert {
            margin-bottom: 20px;
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <h2 class="text-center mb-4">Reset Password</h2>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success">
                <?php echo htmlspecialchars($success); ?>
                <div class="text-center mt-3">
                    <a href="../index.php" class="btn btn-primary">Return to Login</a>
                </div>
            </div>
        <?php else: ?>
            <form method="POST" action="reset_confirm.php">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                
                <div class="form-group">
                    <input type="password" class="form-style" name="password" placeholder="New Password" required minlength="6">
                    <i class="input-icon uil uil-lock-alt"></i>
                </div>
                
                <div class="form-group">
                    <input type="password" class="form-style" name="confirm_password" placeholder="Confirm New Password" required minlength="6">
                    <i class="input-icon uil uil-lock-alt"></i>
                </div>
                
                <div class="text-center">
                    <button type="submit" class="btn mt-4 login-btn">Reset Password</button>
                </div>
            </form>
        <?php endif; ?>
    </div>
</body>
</html> 