-- FULL DATABASE SCHEMA AND SAMPLE DATA FOR THE WHOLE SYSTEM
-- Drop tables if they exist (for a clean setup)
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS UserSettings, AdminActions, Notes, Enseignant_Matiere, Matieres, Etudiants, Enseignants, Promotions, Utilisateurs, Roles, ImportNotes, Notifications;
SET FOREIGN_KEY_CHECKS = 1;

-- Roles Table
CREATE TABLE Roles (
    id_role INT PRIMARY KEY AUTO_INCREMENT,
    nom_role VARCHAR(50) NOT NULL
);

-- Users Table (Utilisateurs)
CREATE TABLE Utilisateurs (
    id_utilisateur INT PRIMARY KEY AUTO_INCREMENT,
    id_role INT NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    mot_de_passe_hash VARCHAR(255) NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    nom_utilisateur VARCHAR(100) NOT NULL UNIQUE,
    must_change_password BOOLEAN DEFAULT 1,
    est_actif BOOLEAN DEFAULT 1,
    date_creation TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_role) REFERENCES Roles(id_role)
);

-- Promotions Table
CREATE TABLE Promotions (
    id_promotion INT PRIMARY KEY AUTO_INCREMENT,
    nom_promotion VARCHAR(100) NOT NULL
);

-- Students Table (Etudiants)
CREATE TABLE Etudiants (
    id_etudiant INT PRIMARY KEY AUTO_INCREMENT,
    id_utilisateur INT NOT NULL,
    code_etudiant VARCHAR(50) NOT NULL UNIQUE,
    id_promotion INT NOT NULL,
    date_de_naissance DATE NOT NULL,
    adresse VARCHAR(255) NOT NULL,
    telephone VARCHAR(30) NOT NULL,
    annee INT NOT NULL,
    FOREIGN KEY (id_utilisateur) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE,
    FOREIGN KEY (id_promotion) REFERENCES Promotions(id_promotion)
);

-- Teachers Table (Enseignants)
CREATE TABLE Enseignants (
    id_enseignant INT PRIMARY KEY AUTO_INCREMENT,
    id_utilisateur INT NOT NULL,
    nom VARCHAR(100) NOT NULL,
    prenom VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    nom_utilisateur VARCHAR(100) NOT NULL,
    FOREIGN KEY (id_utilisateur) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE
);

-- Subjects Table (Matieres)
CREATE TABLE Matieres (
    id_matiere INT PRIMARY KEY AUTO_INCREMENT,
    nom_matiere VARCHAR(100) NOT NULL,
    code_matiere VARCHAR(50) NOT NULL UNIQUE
);

-- Teacher-Subject Assignment Table
CREATE TABLE Enseignant_Matiere (
    id_enseignant INT NOT NULL,
    id_matiere INT NOT NULL,
    PRIMARY KEY (id_enseignant, id_matiere),
    FOREIGN KEY (id_enseignant) REFERENCES Enseignants(id_enseignant) ON DELETE CASCADE,
    FOREIGN KEY (id_matiere) REFERENCES Matieres(id_matiere) ON DELETE CASCADE
);

-- Grades Table (Notes)
CREATE TABLE Notes (
    id_note INT PRIMARY KEY AUTO_INCREMENT,
    id_etudiant INT NOT NULL,
    id_matiere INT NOT NULL,
    id_enseignant INT,
    id_enseignant_saisie INT NOT NULL,
    valeur_note DECIMAL(5,2) NOT NULL,
    type_evaluation VARCHAR(50),
    statut_validation VARCHAR(30) DEFAULT 'Brouillon',
    date_saisie TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    date_ajout TIMESTAMP NULL,
    date_modification TIMESTAMP NULL,
    est_publie BOOLEAN DEFAULT 0,
    commentaire TEXT,
    CONSTRAINT unique_note UNIQUE (id_etudiant, id_matiere, type_evaluation),
    FOREIGN KEY (id_etudiant) REFERENCES Etudiants(id_etudiant) ON DELETE CASCADE,
    FOREIGN KEY (id_matiere) REFERENCES Matieres(id_matiere),
    FOREIGN KEY (id_enseignant) REFERENCES Enseignants(id_enseignant),
    FOREIGN KEY (id_enseignant_saisie) REFERENCES Enseignants(id_enseignant)
);

-- Admin Actions Table (optional)
CREATE TABLE AdminActions (
    id_action INT PRIMARY KEY AUTO_INCREMENT,
    id_admin INT NOT NULL,
    action_type VARCHAR(100) NOT NULL,
    action_details TEXT,
    action_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_admin) REFERENCES Utilisateurs(id_utilisateur)
);

-- User Settings Table (optional)
CREATE TABLE UserSettings (
    id_setting INT PRIMARY KEY AUTO_INCREMENT,
    id_utilisateur INT NOT NULL,
    setting_key VARCHAR(100) NOT NULL,
    setting_value VARCHAR(255) NOT NULL,
    FOREIGN KEY (id_utilisateur) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE
);

-- Table to track bulk note imports by teachers
CREATE TABLE ImportNotes (
    id_import INT PRIMARY KEY AUTO_INCREMENT,
    id_enseignant INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    import_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    notes_imported INT NOT NULL,
    FOREIGN KEY (id_enseignant) REFERENCES Enseignants(id_enseignant) ON DELETE CASCADE
);

-- Notifications Table
CREATE TABLE Notifications (
    id_notification INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT NOT NULL, -- admin or teacher (Utilisateurs)
    recipient_id INT,       -- Utilisateurs.id_utilisateur (nullable for subject-wide)
    id_matiere INT,         -- Matieres.id_matiere (nullable for global/admin)
    role_target VARCHAR(20),-- 'student', 'teacher', 'all' (for admin broadcast)
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    date_sent TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_read BOOLEAN DEFAULT 0,
    FOREIGN KEY (sender_id) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE,
    FOREIGN KEY (recipient_id) REFERENCES Utilisateurs(id_utilisateur) ON DELETE CASCADE,
    FOREIGN KEY (id_matiere) REFERENCES Matieres(id_matiere) ON DELETE SET NULL
);

-- Insert Roles
INSERT INTO Roles (id_role, nom_role) VALUES
  (1, 'admin'),
  (2, 'teacher'),
  (3, 'student');

-- Insert Promotions
INSERT INTO Promotions (id_promotion, nom_promotion) VALUES
  (1, 'B1 Informatique'),
  (2, 'B2 Informatique'),
  (3, 'B3 Informatique');

-- Insert Admin User (password: p@ssw0rd)
INSERT INTO Utilisateurs (id_utilisateur, id_role, email, mot_de_passe_hash, nom, prenom, nom_utilisateur, must_change_password, est_actif)
VALUES (1, 1, 'etame.eddy01@gmail.com', '$2y$10$eImiTXuWVxfM37uY4JANjQ==', 'Admin', 'Super', 'admin', 0, 1);

-- Insert Teacher User (password: password)
INSERT INTO Utilisateurs (id_utilisateur, id_role, email, mot_de_passe_hash, nom, prenom, nom_utilisateur, must_change_password, est_actif)
VALUES (2, 2, 'eddy@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Eddy', 'Ed', 'eddy', 1, 1);

INSERT INTO Enseignants (id_enseignant, id_utilisateur, nom, prenom, email, nom_utilisateur)
VALUES (1, 2, 'Eddy', 'Ed', 'eddy@example.com', 'eddy');

-- Insert Student User (password: password)
INSERT INTO Utilisateurs (id_utilisateur, id_role, email, mot_de_passe_hash, nom, prenom, nom_utilisateur, must_change_password, est_actif)
VALUES (3, 3, 'etame@example.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Etame', 'Et', 'etame', 1, 1);

INSERT INTO Etudiants (id_etudiant, id_utilisateur, code_etudiant, id_promotion, date_de_naissance, adresse, telephone, annee)
VALUES (1, 3, 'ETU3', 1, '2000-01-01', '123 Main St', '0123456789', 1);

-- Insert Sample Subject
INSERT INTO Matieres (id_matiere, nom_matiere, code_matiere) VALUES (1, 'Mathématiques', 'MATH101');
INSERT INTO Matieres (id_matiere, nom_matiere, code_matiere) VALUES (2, 'Physique', 'PHY101');

-- Insert Teacher-Subject Assignment
INSERT INTO Enseignant_Matiere (id_enseignant, id_matiere) VALUES (1, 1);
INSERT INTO Enseignant_Matiere (id_enseignant, id_matiere) VALUES (1, 2);

-- Insert Sample Grades (Notes)
-- Teacher 1 gives notes to student 1 for both subjects
INSERT INTO Notes (id_note, id_etudiant, id_matiere, id_enseignant, id_enseignant_saisie, valeur_note, type_evaluation, statut_validation, date_saisie, est_publie, commentaire)
VALUES (1, 1, 1, 1, 1, 16.5, 'Examen', 'Publié', NOW(), 1, 'Excellent travail en Mathématiques');
INSERT INTO Notes (id_note, id_etudiant, id_matiere, id_enseignant, id_enseignant_saisie, valeur_note, type_evaluation, statut_validation, date_saisie, est_publie, commentaire)
VALUES (2, 1, 2, 1, 1, 14.0, 'Examen', 'Publié', NOW(), 1, 'Bon effort en Physique');
