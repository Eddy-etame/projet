<?php
if (session_status() === PHP_SESSION_NONE) {
    // Force session cookie settings for localhost
    if (in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1'])) {
        ini_set('session.cookie_secure', 0);
        ini_set('session.cookie_samesite', 'Lax');
    }
    session_start();
    // Debug: Log session state
    if (file_exists(__DIR__ . '/../logs/error_log.txt')) {
        file_put_contents(
            __DIR__ . '/../logs/error_log.txt',
            date('Y-m-d H:i:s') . ' [middleware.php] SESSION: ' . json_encode($_SESSION) . "\n",
            FILE_APPEND
        );
    }
}

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../shared/error_logger.php';

class AuthMiddleware {
    private static $instance = null;
    private $sessionTimeout = 3600; // 1 hour
    private $csrfTokenExpiry = 1800; // 30 minutes

    private function __construct() {
        // Set secure session parameters
        ini_set('session.cookie_httponly', 1);
        ini_set('session.use_only_cookies', 1);
        // Set cookie_secure based on HTTPS or localhost
        $is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
        $is_localhost = in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1']);
        ini_set('session.cookie_secure', ($is_https || $is_localhost) ? 0 : 1);
        ini_set('session.cookie_samesite', 'Strict');
        ini_set('session.gc_maxlifetime', $this->sessionTimeout);
        ini_set('session.use_strict_mode', 1);
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function requireAuth() {
        if (!$this->isAuthenticated()) {
            $this->clearSession();
            header('Location: /oac/index.php');
            exit();
        }

        // Check session expiry
        if ($this->isSessionExpired()) {
            $this->clearSession();
            header('Location: /oac/index.php?error=session_expired');
            exit();
        }

        // Regenerate session ID periodically
        $this->regenerateSessionIfNeeded();

        // Update last activity time
        $_SESSION['last_activity'] = time();
    }
    
    public function requireRole($allowed_roles) {
        $this->requireAuth();
        
        if (!is_array($allowed_roles)) {
            $allowed_roles = [$allowed_roles];
        }
        
        // Convert role names to IDs if needed
        $role_map = [
            'admin' => 1,
            'teacher' => 2,
            'student' => 3
        ];
        
        $allowed_role_ids = array_map(function($role) use ($role_map) {
            return is_numeric($role) ? intval($role) : $role_map[$role];
        }, $allowed_roles);
        
        if (!in_array($_SESSION['role'], $allowed_role_ids)) {
            $this->clearSession();
            http_response_code(403);
            header('Location: /oac/index.php?error=unauthorized');
            exit();
        }
    }
    
    public function isAuthenticated() {
        return isset($_SESSION['user_id']) && isset($_SESSION['role']);
    }
    
    public function hasRole($role) {
        if (!$this->isAuthenticated()) {
            return false;
        }
        
        // Convert role name to ID if needed
        if (!is_numeric($role)) {
            $role_map = [
                'admin' => 1,
                'teacher' => 2,
                'student' => 3
            ];
            $role = $role_map[$role];
        }
        
        return $_SESSION['role'] === intval($role);
    }

    public function clearSession() {
        session_unset();
        session_destroy();
        setcookie(session_name(), '', time() - 3600, '/', '', true, true);
        session_write_close();
    }

    private function isSessionExpired() {
        if (!isset($_SESSION['last_activity'])) {
            return true;
        }
        return (time() - $_SESSION['last_activity']) > $this->sessionTimeout;
    }

    private function regenerateSessionIfNeeded() {
        if (!isset($_SESSION['last_regeneration']) || 
            (time() - $_SESSION['last_regeneration']) > 300) { // 5 minutes
            session_regenerate_id(true);
            $_SESSION['last_regeneration'] = time();
        }
    }

    // CSRF Protection
    public function generateCSRFToken() {
        if (!isset($_SESSION['csrf_token']) || 
            !isset($_SESSION['csrf_token_time']) || 
            (time() - $_SESSION['csrf_token_time']) > $this->csrfTokenExpiry) {
            $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
            $_SESSION['csrf_token_time'] = time();
        }
        return $_SESSION['csrf_token'];
    }

    public function validateCSRFToken($token) {
        if (!isset($_SESSION['csrf_token']) || 
            !isset($_SESSION['csrf_token_time']) || 
            empty($token) || 
            $token !== $_SESSION['csrf_token'] || 
            (time() - $_SESSION['csrf_token_time']) > $this->csrfTokenExpiry) {
            return false;
        }
        return true;
    }

    // Rate Limiting
    public function checkRateLimit($action, $limit = 5, $timeframe = 300) {
        $key = "rate_limit_{$action}_" . ($_SESSION['user_id'] ?? 'anonymous');
        
        if (!isset($_SESSION[$key])) {
            $_SESSION[$key] = [
                'count' => 0,
                'first_attempt' => time()
            ];
        }

        // Reset if timeframe has passed
        if ((time() - $_SESSION[$key]['first_attempt']) > $timeframe) {
            $_SESSION[$key]['count'] = 0;
            $_SESSION[$key]['first_attempt'] = time();
        }

        // Check if limit exceeded
        if ($_SESSION[$key]['count'] >= $limit) {
            $wait_time = $timeframe - (time() - $_SESSION[$key]['first_attempt']);
            throw new Exception("Rate limit exceeded. Please try again in {$wait_time} seconds.");
        }

        $_SESSION[$key]['count']++;
        return true;
    }

    // IP-based security
    public function checkIPSecurity() {
        $ip = $_SERVER['REMOTE_ADDR'];
        $conn = getDBConnection();
        
        try {
            // Check if IP is blacklisted
            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM ip_blacklist WHERE ip = ? AND expires > NOW()");
            $stmt->bind_param("s", $ip);
            $stmt->execute();
            $result = $stmt->get_result();
            $row = $result->fetch_assoc();
            
            if ($row['count'] > 0) {
                throw new Exception("Access denied from your IP address.");
            }

            // Log IP access
            $stmt = $conn->prepare("INSERT INTO ip_access_log (ip, access_time) VALUES (?, NOW())");
            $stmt->bind_param("s", $ip);
            $stmt->execute();

        } catch (Exception $e) {
            error_log("IP Security check failed: " . $e->getMessage());
            throw $e;
        }
    }
}

// Create SQL tables for IP security if they don't exist
$conn = getDBConnection();
try {
    $conn->query("
        CREATE TABLE IF NOT EXISTS ip_blacklist (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ip VARCHAR(45) NOT NULL,
            reason TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            expires TIMESTAMP NOT NULL,
            INDEX (ip),
            INDEX (expires)
        )
    ");

    $conn->query("
        CREATE TABLE IF NOT EXISTS ip_access_log (
            id INT AUTO_INCREMENT PRIMARY KEY,
            ip VARCHAR(45) NOT NULL,
            access_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX (ip),
            INDEX (access_time)
        )
    ");
} catch (Exception $e) {
    error_log("Failed to create IP security tables: " . $e->getMessage());
}
?>