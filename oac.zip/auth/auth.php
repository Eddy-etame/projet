<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/db.php';

class Auth {
    private $conn;

    public function __construct($conn) {
        $this->conn = $conn;
    }

    public function login($email, $password, $role) {
        try {
            // Sanitize inputs
            $email = filter_var($email, FILTER_SANITIZE_EMAIL);
            
            // Prepare statement to prevent SQL injection
            $stmt = $this->conn->prepare("
                SELECT u.*, r.id_role 
                FROM Utilisateurs u 
                JOIN Roles r ON u.id_role = r.id_role 
                WHERE u.email = ? AND u.est_actif = 1
            ");
            
            if (!$stmt) {
                throw new Exception("Database error: " . $this->conn->error);
            }
            
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                
                // Verify password and role
                if (password_verify($password, $user['mot_de_passe_hash'])) {
                    if ($user['id_role'] === intval($role)) {
                        // Set session variables
                        $_SESSION['user_id'] = $user['id_utilisateur'];
                        $_SESSION['role'] = $user['id_role'];
                        $_SESSION['user_name'] = $user['prenom'] . ' ' . $user['nom'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['last_activity'] = time();
                        
                        // Update last login
                        $update = $this->conn->prepare("
                            UPDATE Utilisateurs 
                            SET derniere_connexion = NOW() 
                            WHERE id_utilisateur = ?
                        ");
                        $update->bind_param("i", $user['id_utilisateur']);
                        $update->execute();
                        
                        // Log successful login
                        $this->logAction($user['id_utilisateur'], 'login_success', 'User logged in successfully');
                        
                        return true;
                    }
                }
            }
            
            // Log failed login attempt
            $this->logAction(0, 'login_failed', "Failed login attempt for email: $email");
            return false;
            
        } catch (Exception $e) {
            error_log("Login error: " . $e->getMessage());
            throw $e;
        }
    }

    public function register($userData) {
        $hash = password_hash($userData['password'], PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO Utilisateurs (nom_utilisateur, mot_de_passe_hash, email, id_role, 
                prenom, nom, date_creation, est_actif) 
                VALUES (?, ?, ?, ?, ?, ?, NOW(), 1)";
        
        $stmt = $this->conn->prepare($sql);
        $stmt->bind_param("ssssss", 
            $userData['username'],
            $hash,
            $userData['email'],
            $userData['role'],
            $userData['firstname'],
            $userData['lastname']
        );
        
        if ($stmt->execute()) {
            $user_id = $stmt->insert_id;
            $this->logAction($user_id, 'Registration', 'New user registration');
            return true;
        }
        return false;
    }

    public function logAction($user_id, $action, $details) {
        try {
            $stmt = $this->conn->prepare("
                INSERT INTO Journaux_Actions (
                    id_utilisateur, 
                    type_action, 
                    details_action, 
                    adresse_ip, 
                    date_action
                ) VALUES (?, ?, ?, ?, NOW())
            ");
            
            $ip = $_SERVER['REMOTE_ADDR'];
            $stmt->bind_param("isss", $user_id, $action, $details, $ip);
            return $stmt->execute();
            
        } catch (Exception $e) {
            error_log("Failed to log action: " . $e->getMessage());
            // Don't throw the exception as this is a non-critical operation
            return false;
        }
    }

    public function isLoggedIn() {
        return isset($_SESSION['user_id']) && isset($_SESSION['role']);
    }

    public function logout() {
        if ($this->isLoggedIn()) {
            $this->logAction($_SESSION['user_id'], 'logout', 'User logged out');
            session_destroy();
            return true;
        }
        return false;
    }
}

$auth = new Auth($conn);
?>