<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../shared/error_logger.php';
require_once __DIR__ . '/../shared/email/EmailVerifier.php';
require_once __DIR__ . '/middleware.php';

session_start();
$auth = AuthMiddleware::getInstance();

class PasswordReset {
    private $conn;
    private $auth;
    private $maxAttempts = 3;
    private $lockoutDuration = 1800; // 30 minutes
    private $tokenLength = 64;
    private $passwordMinLength = 8;
    private $passwordRequirements = [
        'uppercase' => true,
        'lowercase' => true,
        'number' => true,
        'special' => true,
        'min_length' => 8
    ];

    public function __construct($conn, $auth) {
        $this->conn = $conn;
        $this->auth = $auth;
    }

    private function generateResetToken() {
        return bin2hex(random_bytes($this->tokenLength / 2));
    }

    private function isValidToken($token) {
        if (strlen($token) !== $this->tokenLength) return false;
        return ctype_xdigit($token);
    }

    private function validatePassword($password) {
        $errors = [];
        
        if (strlen($password) < $this->passwordRequirements['min_length']) {
            $errors[] = "Password must be at least {$this->passwordRequirements['min_length']} characters long";
        }
        
        if ($this->passwordRequirements['uppercase'] && !preg_match('/[A-Z]/', $password)) {
            $errors[] = "Password must contain at least one uppercase letter";
        }
        
        if ($this->passwordRequirements['lowercase'] && !preg_match('/[a-z]/', $password)) {
            $errors[] = "Password must contain at least one lowercase letter";
        }
        
        if ($this->passwordRequirements['number'] && !preg_match('/[0-9]/', $password)) {
            $errors[] = "Password must contain at least one number";
        }
        
        if ($this->passwordRequirements['special'] && !preg_match('/[!@#$%^&*()\-_=+{};:,<.>]/', $password)) {
            $errors[] = "Password must contain at least one special character";
        }
        
        return empty($errors) ? true : $errors;
    }

    private function sendResetEmail($email, $token, $name) {
        $reset_link = "https://" . $_SERVER['HTTP_HOST'] . "/oac/auth/reset_confirm.php?token=" . urlencode($token);
        
        $to = $email;
        $subject = "Réinitialisation de mot de passe - OAC";
        $message = "
        <html>
        <head>
            <title>Réinitialisation de mot de passe</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .button { display: inline-block; padding: 10px 20px; background-color: #007bff; color: white; text-decoration: none; border-radius: 5px; }
                .warning { color: #dc3545; margin-top: 20px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <h2>Réinitialisation de mot de passe</h2>
                <p>Cher(e) {$name},</p>
                <p>Nous avons reçu une demande de réinitialisation de votre mot de passe.</p>
                <p>Pour réinitialiser votre mot de passe, cliquez sur le bouton ci-dessous :</p>
                <p><a href='{$reset_link}' class='button'>Réinitialiser mon mot de passe</a></p>
                <p>Ou copiez ce lien dans votre navigateur :</p>
                <p>{$reset_link}</p>
                <p>Ce lien expirera dans 1 heure.</p>
                <div class='warning'>
                    <p><strong>Important :</strong></p>
                    <p>Si vous n'avez pas demandé cette réinitialisation, veuillez :</p>
                    <ol>
                        <li>Ignorer cet email</li>
                        <li>Sécuriser votre compte en changeant votre mot de passe</li>
                        <li>Contacter notre support si vous pensez que votre compte est compromis</li>
                    </ol>
                </div>
                <p>Cordialement,<br>L'équipe OAC</p>
            </div>
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: OAC Grade Management <noreply@oac.com>\r\n";
        $headers .= "X-Priority: 1\r\n";

        return mail($to, $subject, $message, $headers);
    }

    public function handleResetRequest($email, $role) {
        try {
            // Check rate limiting
            $this->auth->checkRateLimit('password_reset', 3, 1800);

            // Validate email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception("Invalid email format");
            }

            // Get user information
            $table = ($role == 2) ? 'Enseignants' : 'Etudiants';
            $stmt = $this->conn->prepare("
                SELECT U.id_utilisateur, U.nom, U.prenom, U.email
                FROM Utilisateurs U 
                INNER JOIN $table T ON U.id_utilisateur = T.id_utilisateur 
                WHERE U.email = ? AND U.id_role = ? AND U.est_actif = 1
            ");
            
            $stmt->bind_param("si", $email, $role);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 0) {
                // Return success even if user not found to prevent email enumeration
                return ['success' => true, 'message' => "Si un compte existe avec cet email, vous recevrez les instructions de réinitialisation."];
            }
            
            $user = $result->fetch_assoc();
            $token = $this->generateResetToken();
            $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));
            
            // Delete existing tokens
            $delete_stmt = $this->conn->prepare("DELETE FROM password_resets WHERE user_id = ?");
            $delete_stmt->bind_param("i", $user['id_utilisateur']);
            $delete_stmt->execute();
            
            // Insert new token
            $insert_stmt = $this->conn->prepare("
                INSERT INTO password_resets (user_id, token, expiry, ip_address) 
                VALUES (?, ?, ?, ?)
            ");
            
            $ip = $_SERVER['REMOTE_ADDR'];
            $insert_stmt->bind_param("isss", $user['id_utilisateur'], $token, $expiry, $ip);
            
            if (!$insert_stmt->execute()) {
                throw new Exception("Failed to generate reset token");
            }
            
            // Send email
            $full_name = $user['prenom'] . ' ' . $user['nom'];
            if (!$this->sendResetEmail($email, $token, $full_name)) {
                throw new Exception("Failed to send reset email");
            }
            
            // Log the reset request
            error_log("Password reset requested for user ID: " . $user['id_utilisateur']);
            
            return ['success' => true, 'message' => "Si un compte existe avec cet email, vous recevrez les instructions de réinitialisation."];
            
        } catch (Exception $e) {
            error_log("Password reset error: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    public function handlePasswordReset($token, $new_password, $confirm_password) {
        try {
            // Validate token
            if (!$this->isValidToken($token)) {
                throw new Exception("Invalid reset token");
            }

            // Validate passwords match
            if ($new_password !== $confirm_password) {
                throw new Exception("Les mots de passe ne correspondent pas");
            }

            // Validate password strength
            $password_validation = $this->validatePassword($new_password);
            if ($password_validation !== true) {
                throw new Exception(implode(", ", $password_validation));
            }

            // Get reset token info
            $stmt = $this->conn->prepare("
                SELECT pr.user_id, pr.attempts, u.email
                FROM password_resets pr
                JOIN Utilisateurs u ON pr.user_id = u.id_utilisateur
                WHERE pr.token = ? AND pr.expiry > NOW() AND pr.used = 0
            ");
            
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result->num_rows === 0) {
                throw new Exception("Invalid or expired reset token");
            }

            $reset = $result->fetch_assoc();

            // Check attempts
            if ($reset['attempts'] >= $this->maxAttempts) {
                throw new Exception("Too many reset attempts. Please request a new reset link.");
            }

            // Update attempts
            $update_attempts = $this->conn->prepare("
                UPDATE password_resets 
                SET attempts = attempts + 1 
                WHERE token = ?
            ");
            $update_attempts->bind_param("s", $token);
            $update_attempts->execute();

            // Hash new password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            // Update password
            $update_stmt = $this->conn->prepare("
                UPDATE Utilisateurs 
                SET mot_de_passe_hash = ?, 
                    date_modification = NOW(),
                    must_change_password = 0
                WHERE id_utilisateur = ?
            ");
            
            $update_stmt->bind_param("si", $hashed_password, $reset['user_id']);
            
            if (!$update_stmt->execute()) {
                throw new Exception("Failed to update password");
            }

            // Mark token as used
            $mark_used = $this->conn->prepare("
                UPDATE password_resets 
                SET used = 1, 
                    used_at = NOW() 
                WHERE token = ?
            ");
            $mark_used->bind_param("s", $token);
            $mark_used->execute();

            // Send confirmation email
            $this->sendPasswordChangeConfirmation($reset['email']);

            return ['success' => true, 'message' => "Votre mot de passe a été réinitialisé avec succès."];

        } catch (Exception $e) {
            error_log("Password reset error: " . $e->getMessage());
            return ['success' => false, 'message' => $e->getMessage()];
        }
    }

    private function sendPasswordChangeConfirmation($email) {
        $subject = "Confirmation de changement de mot de passe - OAC";
        $message = "
        <html>
        <head>
            <title>Confirmation de changement de mot de passe</title>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .warning { color: #dc3545; margin-top: 20px; }
            </style>
        </head>
        <body>
            <div class='container'>
                <h2>Confirmation de changement de mot de passe</h2>
                <p>Votre mot de passe a été changé avec succès.</p>
                <p>Si vous n'avez pas effectué ce changement, veuillez contacter immédiatement notre support.</p>
                <div class='warning'>
                    <p><strong>Mesures de sécurité recommandées :</strong></p>
                    <ol>
                        <li>Changez les mots de passe de vos autres comptes si vous les réutilisez</li>
                        <li>Activez l'authentification à deux facteurs si disponible</li>
                        <li>Vérifiez les activités récentes de votre compte</li>
                    </ol>
                </div>
                <p>Cordialement,<br>L'équipe OAC</p>
            </div>
        </body>
        </html>
        ";

        $headers = "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
        $headers .= "From: OAC Grade Management <noreply@oac.com>\r\n";

        return mail($email, $subject, $message, $headers);
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = getDBConnection();
    $passwordReset = new PasswordReset($conn, $auth);
    
    header('Content-Type: application/json');
    
    if (isset($_POST['request_reset'])) {
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $role = filter_var($_POST['role'], FILTER_SANITIZE_NUMBER_INT);
        
        $result = $passwordReset->handleResetRequest($email, $role);
        echo json_encode($result);
        
    } elseif (isset($_POST['reset_password'])) {
        $token = $_POST['token'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        $result = $passwordReset->handlePasswordReset($token, $new_password, $confirm_password);
        echo json_encode($result);
    }
    
    releaseDBConnection($conn);
    exit();
}

// Display form
$token = $_GET['token'] ?? '';
$show_reset_form = !empty($token);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation de mot de passe - OAC</title>
    <link rel="stylesheet" href="../css/auth.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Password strength meter
            function checkPasswordStrength(password) {
                let strength = 0;
                const feedback = [];

                // Length check
                if (password.length < 8) {
                    feedback.push("Au moins 8 caractères");
                } else {
                    strength += 25;
                }

                // Uppercase check
                if (!/[A-Z]/.test(password)) {
                    feedback.push("Au moins une majuscule");
                } else {
                    strength += 25;
                }

                // Lowercase check
                if (!/[a-z]/.test(password)) {
                    feedback.push("Au moins une minuscule");
                } else {
                    strength += 25;
                }

                // Number check
                if (!/[0-9]/.test(password)) {
                    feedback.push("Au moins un chiffre");
                } else {
                    strength += 25;
                }

                // Special character check
                if (!/[!@#$%^&*()\-_=+{};:,<.>]/.test(password)) {
                    feedback.push("Au moins un caractère spécial");
                } else {
                    strength += 25;
                }

                return {
                    strength: strength,
                    feedback: feedback
                };
            }

            // Update password strength meter
            $('#new_password').on('input', function() {
                const result = checkPasswordStrength($(this).val());
                const meter = $('#password-strength-meter');
                const feedback = $('#password-feedback');

                meter.val(result.strength);
                feedback.html(result.feedback.join('<br>'));
                
                // Update meter color
                if (result.strength <= 25) {
                    meter.css('background-color', '#ff4444');
                } else if (result.strength <= 50) {
                    meter.css('background-color', '#ffa700');
                } else if (result.strength <= 75) {
                    meter.css('background-color', '#ffff00');
                } else {
                    meter.css('background-color', '#00ff00');
                }
            });

            // Form submission
            $('form').on('submit', function(e) {
                e.preventDefault();
                const form = $(this);
                const submitButton = form.find('button[type="submit"]');
                
                submitButton.prop('disabled', true);
                
                $.ajax({
                    url: form.attr('action'),
                    method: 'POST',
                    data: form.serialize(),
                    dataType: 'json',
                    success: function(response) {
                        if (response.success) {
                            $('#message').removeClass('error').addClass('success').text(response.message);
                            if (form.find('input[name="reset_password"]').length) {
                                setTimeout(() => window.location.href = '../index.php', 3000);
                            }
                        } else {
                            $('#message').removeClass('success').addClass('error').text(response.message);
                        }
                    },
                    error: function() {
                        $('#message').removeClass('success').addClass('error')
                            .text("Une erreur est survenue. Veuillez réessayer.");
                    },
                    complete: function() {
                        submitButton.prop('disabled', false);
                    }
                });
            });
        });
    </script>
    <style>
        .password-strength {
            margin: 10px 0;
        }
        #password-strength-meter {
            width: 100%;
            height: 10px;
        }
        #password-feedback {
            font-size: 0.8em;
            color: #666;
            margin-top: 5px;
        }
        .success {
            color: #28a745;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #28a745;
            border-radius: 4px;
        }
        .error {
            color: #dc3545;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #dc3545;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div id="message"></div>
        
        <?php if ($show_reset_form): ?>
            <h2>Réinitialiser votre mot de passe</h2>
            <form method="post" class="auth-form">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                
                <div class="form-group">
                    <label for="new_password">Nouveau mot de passe</label>
                    <input type="password" id="new_password" name="new_password" required minlength="8">
                    <div class="password-strength">
                        <meter id="password-strength-meter" min="0" max="100" low="25" high="75" optimum="100"></meter>
                        <div id="password-feedback"></div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirmer le mot de passe</label>
                    <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                </div>
                
                <button type="submit" name="reset_password" class="btn btn-primary">Réinitialiser</button>
            </form>
        <?php else: ?>
            <h2>Demander une réinitialisation</h2>
            <form method="post" class="auth-form">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                
                <div class="form-group">
                    <label for="role">Rôle</label>
                    <select id="role" name="role" required>
                        <option value="2">Enseignant</option>
                        <option value="3">Étudiant</option>
                    </select>
                </div>
                
                <button type="submit" name="request_reset" class="btn btn-primary">Envoyer</button>
            </form>
        <?php endif; ?>
        
        <div class="auth-links">
            <a href="../index.php">Retour à la connexion</a>
        </div>
    </div>
</body>
</html> 