<?php
// Database configuration
if (!defined('DB_HOST')) {
    define('DB_HOST', 'localhost');
    define('DB_USER', 'Eddy');
    define('DB_PASS', 'Daddiesammy1$');
    define('DB_NAME', 'keyce');
}

// Debug mode for development
if (!defined('DEBUG_MODE')) {
    define('DEBUG_MODE', true);
}

// Connection timeout in seconds
if (!defined('CONNECTION_TIMEOUT')) {
    define('CONNECTION_TIMEOUT', 30);
}

/**
 * Get a new database connection
 * @return mysqli A new database connection
 * @throws Exception if connection fails
 */
function getDBConnection() {
    static $conn = null;
    
    if ($conn === null) {
        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
        
        try {
            $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
            $conn->set_charset('utf8mb4');
            
            // Set connection timeout
            $conn->options(MYSQLI_OPT_CONNECT_TIMEOUT, CONNECTION_TIMEOUT);
            
        } catch (mysqli_sql_exception $e) {
            error_log("Database connection failed: " . $e->getMessage());
            throw new Exception("Database connection failed. Please try again later.");
        }
    }
    
    return $conn;
}

// Test the connection immediately to catch any configuration errors
try {
    $test_conn = getDBConnection();
} catch (Exception $e) {
    if (DEBUG_MODE) {
        die("Database connection error: " . $e->getMessage());
    } else {
        die("Service temporarily unavailable. Please try again later.");
    }
}
?> 