<?php
// filepath: c:\wamp64\www\oac\auth\login.php

// Set secure session parameters
ini_set('session.cookie_httponly', 1);
ini_set('session.use_only_cookies', 1);
// Set cookie_secure based on HTTPS or localhost
$is_https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || $_SERVER['SERVER_PORT'] == 443;
$is_localhost = in_array($_SERVER['SERVER_NAME'], ['localhost', '127.0.0.1']);
ini_set('session.cookie_secure', ($is_https || $is_localhost) ? 0 : 1);
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.gc_maxlifetime', 3600); // 1 hour
ini_set('session.use_strict_mode', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
session_regenerate_id(true);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/../shared/error_logger.php';

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Redirect to index if accessed directly
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /oac/index.php');
    exit();
}

function logError($message, $data = []) {
    if (defined('DEBUG_MODE') && DEBUG_MODE) {
        $log_entry = [
            'timestamp' => date('Y-m-d H:i:s'),
            'message' => $message,
            'data' => $data,
            'server' => $_SERVER['REQUEST_URI'] ?? 'Unknown URI'
        ];
        file_put_contents(
            __DIR__ . '/error_log.txt', 
            json_encode($log_entry, JSON_PRETTY_PRINT) . "\n---\n", 
            FILE_APPEND
        );
    }
}

$conn = getDBConnection();

// DEBUG: Log POST data to a file for verification
file_put_contents(__DIR__ . '/login_debug.log', date('Y-m-d H:i:s') . ' ' . json_encode($_POST) . PHP_EOL, FILE_APPEND);

// Log session state
logError("Session state", [
    'has_session' => isset($_SESSION['user_id']),
    'session_id' => session_id(),
    'session_data' => $_SESSION
]);

// Check if already logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    logError("Already logged in", ['user_id' => $_SESSION['user_id'], 'role' => $_SESSION['role']]);
    // Redirect to dashboard based on role
    $dashboard_map = [
        1 => 'oac/admin/ADDashboard.php',
        2 => 'oac/teacher/TDashboard.php',
        3 => 'oac/student/SDashboard.php'
    ];
    $role = $_SESSION['role'];
    if (isset($dashboard_map[$role])) {
        header("Location: " . $dashboard_map[$role]);
        exit();
    }
    // Default fallback
    header("Location: oac/index.php");
    exit();
}

// Login logic
if (
    $_SERVER['REQUEST_METHOD'] === 'POST' &&
    isset($_POST['email'], $_POST['password'], $_POST['id_role']) &&
    !isset($_POST['nom_utilisateur'])
) {
    try {
        // Validate CSRF token
        if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
            throw new Exception("Invalid CSRF token");
        }

        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        $password = $_POST['password'];
        $role_id = filter_var($_POST['id_role'], FILTER_SANITIZE_NUMBER_INT);

        // Validate inputs
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            throw new Exception("Invalid email format");
        }

        if (empty($password)) {
            throw new Exception("Password is required");
        }

        if (!in_array($role_id, ['1', '2', '3'])) {
            throw new Exception("Invalid role");
        }

        $auth = new Auth(getDBConnection());
        
        if ($auth->login($email, $password, $role_id)) {
            // Map roles to their respective dashboards
            $dashboard_map = [
                1 => '/oac/admin/ADDashboard.php',
                2 => '/oac/teacher/TDashboard.php',
                3 => '/oac/student/SDashboard.php'
            ];

            header("Location: " . $dashboard_map[$role_id]);
            exit();
        } else {
            // Redirect based on role to show error on correct login page
            $redirect_url = '/oac/index.php'; // default redirect
            if (isset($_POST['id_role'])) {
                switch ($_POST['id_role']) {
                    case '1':
                        $redirect_url = 'oac/admin/index.php';
                        break;
                    case '2':
                    case '3':
                    default:
                        $redirect_url = 'oac/index.php';
                        break;
                }
            }
            throw new Exception("Invalid credentials");
        }
        } catch (Exception $e) {
            $_SESSION['error'] = $e->getMessage();
            // Redirect based on role to show error on correct login page
            $redirect_url = '/oac/index.php'; // default redirect
            if (isset($_POST['id_role'])) {
                switch ($_POST['id_role']) {
                    case '1':
                        $redirect_url = 'oac/admin/index.php';
                        break;
                    case '2':
                    case '3':
                    default:
                        $redirect_url = 'oac/index.php';
                        break;
                }
            }
            header("Location: " . $redirect_url);
            exit();
        }
}

// Registration logic REMOVED: Registration is admin-only and not allowed via Login.php

$conn->close();
?>