<?php
require_once 'login.php';

function checkTeacherAccount($email) {
    global $conn;
    
    $stmt = $conn->prepare("
        SELECT 
            U.id_utilisateur,
            U.email,
            U.nom,
            U.prenom,
            U.date_creation,
            U.derniere_connexion,
            T.specialite
        FROM Utilisateurs U 
        INNER JOIN Enseignants T ON U.id_utilisateur = T.id_utilisateur 
        WHERE U.email = ? AND U.id_role = 2
    ");

    if (!$stmt) {
        return ['error' => 'Query preparation failed: ' . $conn->error];
    }

    $stmt->bind_param("s", $email);
    
    if (!$stmt->execute()) {
        return ['error' => 'Query execution failed: ' . $stmt->error];
    }

    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return ['exists' => false, 'message' => 'No teacher account found with this email.'];
    }

    $teacher = $result->fetch_assoc();
    return [
        'exists' => true,
        'data' => [
            'id' => $teacher['id_utilisateur'],
            'email' => $teacher['email'],
            'name' => $teacher['nom'] . ' ' . $teacher['prenom'],
            'specialty' => $teacher['specialite'],
            'created' => $teacher['date_creation'],
            'last_login' => $teacher['derniere_connexion']
        ]
    ];
}

// If this script is called directly
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['check_email'])) {
    header('Content-Type: application/json');
    $result = checkTeacherAccount($_POST['check_email']);
    echo json_encode($result);
    exit();
}
?> 