<?php
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/../shared/error_logger.php';
require_once __DIR__ . '/../shared/email/EmailVerifier.php';

session_start();

function generateResetToken() {
    return bin2hex(random_bytes(32));
}

function isValidToken($token) {
    if (strlen($token) !== 64) return false;
    return ctype_xdigit($token);
}

function sendResetEmail($email, $token) {
    $reset_link = "http://" . $_SERVER['HTTP_HOST'] . "/oac/auth/reset_password.php?token=" . $token;
    $to = $email;
    $subject = "Réinitialisation de mot de passe - OAC";
    $message = "
    <html>
    <head>
        <title>Réinitialisation de mot de passe</title>
    </head>
    <body>
        <p>Vous avez demandé la réinitialisation de votre mot de passe.</p>
        <p>Cliquez sur le lien ci-dessous pour réinitialiser votre mot de passe :</p>
        <p><a href='{$reset_link}'>{$reset_link}</a></p>
        <p>Ce lien expirera dans 1 heure.</p>
        <p>Si vous n'avez pas demandé cette réinitialisation, ignorez cet email.</p>
    </body>
    </html>
    ";

    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";
    $headers .= "From: OAC <noreply@oac.com>\r\n";

    return mail($to, $subject, $message, $headers);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $token = $_POST['token'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    try {
        $conn = getDBConnection();

        if (isset($_POST['request_reset'])) {
            // Step 1: Handle reset request
            $stmt = $conn->prepare("SELECT id_utilisateur FROM Utilisateurs WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $user_id = $row['id_utilisateur'];
                $token = generateResetToken();
                $expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

                // Delete any existing tokens for this user
                $delete_stmt = $conn->prepare("DELETE FROM PasswordResets WHERE user_id = ?");
                $delete_stmt->bind_param("i", $user_id);
                $delete_stmt->execute();

                // Insert new token
                $insert_stmt = $conn->prepare("INSERT INTO PasswordResets (user_id, token, expiry) VALUES (?, ?, ?)");
                $insert_stmt->bind_param("iss", $user_id, $token, $expiry);
                $insert_stmt->execute();

                if (sendResetEmail($email, $token)) {
                    $_SESSION['reset_message'] = "Un email de réinitialisation a été envoyé à votre adresse email.";
                    logInfo("Password reset requested", ['email' => $email]);
                } else {
                    throw new Exception("Erreur lors de l'envoi de l'email");
                }
            } else {
                $_SESSION['reset_error'] = "Aucun compte trouvé avec cette adresse email.";
                logWarning("Password reset requested for non-existent email", ['email' => $email]);
            }

        } elseif (isset($_POST['reset_password'])) {
            // Step 2: Handle password reset
            if (!isValidToken($token)) {
                throw new Exception("Token invalide");
            }

            if ($new_password !== $confirm_password) {
                throw new Exception("Les mots de passe ne correspondent pas");
            }

            if (strlen($new_password) < 8) {
                throw new Exception("Le mot de passe doit contenir au moins 8 caractères");
            }

            $stmt = $conn->prepare("
                SELECT pr.user_id 
                FROM PasswordResets pr
                WHERE pr.token = ? AND pr.expiry > NOW() AND pr.used = 0
            ");
            $stmt->bind_param("s", $token);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($row = $result->fetch_assoc()) {
                $user_id = $row['user_id'];
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

                // Update password
                $update_stmt = $conn->prepare("UPDATE Utilisateurs SET mot_de_passe_hash = ? WHERE id_utilisateur = ?");
                $update_stmt->bind_param("si", $hashed_password, $user_id);
                $update_stmt->execute();

                // Mark token as used
                $mark_used_stmt = $conn->prepare("UPDATE PasswordResets SET used = 1 WHERE token = ?");
                $mark_used_stmt->bind_param("s", $token);
                $mark_used_stmt->execute();

                $_SESSION['reset_message'] = "Votre mot de passe a été réinitialisé avec succès.";
                logInfo("Password reset successful", ['user_id' => $user_id]);
                header("Location: ../index.php");
                exit();
            } else {
                throw new Exception("Token invalide ou expiré");
            }
        }

    } catch (Exception $e) {
        $_SESSION['reset_error'] = $e->getMessage();
        logError("Password reset error", ['error' => $e->getMessage()]);
    }

    $conn->close();
    header("Location: " . $_SERVER['PHP_SELF'] . ($token ? "?token=$token" : ""));
    exit();
}

// Display form
$token = $_GET['token'] ?? '';
$show_reset_form = isValidToken($token);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation de mot de passe</title>
    <link rel="stylesheet" href="../css/auth.css">
</head>
<body>
    <div class="container">
        <?php if (isset($_SESSION['reset_error'])): ?>
            <div class="alert alert-error">
                <?= htmlspecialchars($_SESSION['reset_error']) ?>
            </div>
            <?php unset($_SESSION['reset_error']); ?>
        <?php endif; ?>

        <?php if (isset($_SESSION['reset_message'])): ?>
            <div class="alert alert-success">
                <?= htmlspecialchars($_SESSION['reset_message']) ?>
            </div>
            <?php unset($_SESSION['reset_message']); ?>
        <?php endif; ?>

        <?php if ($show_reset_form): ?>
            <h2>Réinitialiser votre mot de passe</h2>
            <form method="post" class="auth-form">
                <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
                <div class="form-group">
                    <label for="new_password">Nouveau mot de passe</label>
                    <input type="password" id="new_password" name="new_password" required minlength="8">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirmer le mot de passe</label>
                    <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                </div>
                <button type="submit" name="reset_password" class="btn btn-primary">Réinitialiser</button>
            </form>
        <?php else: ?>
            <h2>Demander une réinitialisation</h2>
            <form method="post" class="auth-form">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" required>
                </div>
                <button type="submit" name="request_reset" class="btn btn-primary">Envoyer</button>
            </form>
        <?php endif; ?>
        
        <div class="auth-links">
            <a href="../index.php">Retour à la connexion</a>
        </div>
    </div>
</body>
</html> 